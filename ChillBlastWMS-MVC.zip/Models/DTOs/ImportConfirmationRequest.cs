using ChillBlastWMS_MVC.Models.ViewModels;

namespace ChillBlastWMS_MVC.Models.DTOs
{
    public class ImportConfirmationRequest
    {
        public string EntityType { get; set; } = string.Empty;
    }
}