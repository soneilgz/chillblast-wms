using CsvHelper.Configuration.Attributes;
using System.ComponentModel.DataAnnotations;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using ChillBlastWMS_MVC.Utilities;

namespace ChillBlastWMS_MVC.Models.DTOs
{
    public class ProductImportDto
    {
        [Name("Sku")]
        [Index(0)]
        [TypeConverter(typeof(SkuConverter))]
        public string? SKU { get; set; }

        [Name("Name")]
        [Index(1)]
        [TypeConverter(typeof(ProductNameConverter))]
        public string? Name { get; set; }

        [Name("ManufacturersCode")]
        [Index(2)]
        public string? ManufacturersCode { get; set; }

        [Name("DateCreated")]
        [Index(3)]
        [TypeConverter(typeof(UkDateTimeConverter))]
        public DateTime DateCreated { get; set; }

        [Name("DateUpdated")]
        [Index(4)]
        [TypeConverter(typeof(UkDateTimeConverter))]
        public DateTime DateUpdated { get; set; }

        [Name("IsActive")]
        [Index(5)]
        public bool IsActive { get; set; } = true;

        [Name("Summary")]
        [Index(6)]
        [TypeConverter(typeof(DescriptionConverter))]
        public string? Summary { get; set; }

        [Name("Weight")]
        [Index(7)]
        [TypeConverter(typeof(CurrencyDecimalConverter))]
        public decimal Weight { get; set; }

        [Name("WeightUnit")]
        [Index(8)]
        public string? WeightUnit { get; set; }

        [Name("CategoryID")]
        [Index(9)]
        [TypeConverter(typeof(FlexibleIntegerConverter))]
        public int CategoryID { get; set; }

        [Name("Category")]
        [Index(10)]
        [TypeConverter(typeof(CategoryConverter))]
        public string? Category { get; set; }

        [Name("ManufacturerID")]
        [Index(11)]
        [TypeConverter(typeof(FlexibleIntegerConverter))]
        public int ManufacturerID { get; set; }

        [Name("Manufacturer")]
        [Index(12)]
        [TypeConverter(typeof(ManufacturerConverter))]
        public string? Manufacturer { get; set; }

        [Name("CostPrice")]
        [Index(13)]
        [TypeConverter(typeof(CurrencyDecimalConverter))]
        public decimal CostPrice { get; set; }

        [Name("SellPrice")]
        [Index(14)]
        [TypeConverter(typeof(CurrencyDecimalConverter))]
        public decimal Price { get; set; }

        [Name("Qty")]
        [Index(15)]
        [TypeConverter(typeof(FlexibleIntegerConverter))]
        public int Quantity { get; set; }

        // Optional fields (for backward compatibility)
        [Name("Description")]
        [Optional]
        [TypeConverter(typeof(DescriptionConverter))]
        public string? Description { get; set; }

        [Name("Location")]
        [Optional]
        public string? Location { get; set; }

        [Name("ReorderPoint")]
        [Optional]
        [TypeConverter(typeof(FlexibleIntegerConverter))]
        public int? ReorderPoint { get; set; }

        [Name("ReorderQuantity")]
        [Optional]
        [TypeConverter(typeof(FlexibleIntegerConverter))]
        public int? ReorderQuantity { get; set; }

        [Name("Supplier")]
        [Optional]
        public string? Supplier { get; set; }

        public List<string> ValidationErrors { get; set; } = new List<string>();

        public bool IsValid()
        {
            ValidationErrors.Clear();

            // Required field validations
            if (string.IsNullOrWhiteSpace(SKU))
                ValidationErrors.Add("Sku is required");

            if (string.IsNullOrWhiteSpace(Name))
                ValidationErrors.Add("Name is required");

            if (string.IsNullOrWhiteSpace(ManufacturersCode))
                ValidationErrors.Add("ManufacturersCode is required");

            if (string.IsNullOrWhiteSpace(Summary))
                ValidationErrors.Add("Summary is required");

            if (string.IsNullOrWhiteSpace(WeightUnit))
                ValidationErrors.Add("WeightUnit is required");

            if (string.IsNullOrWhiteSpace(Category))
                ValidationErrors.Add("Category is required");

            if (string.IsNullOrWhiteSpace(Manufacturer))
                ValidationErrors.Add("Manufacturer is required");

            // Numeric validations
            if (Weight < 0)
                ValidationErrors.Add("Weight cannot be negative");

            if (CategoryID <= 0)
                ValidationErrors.Add("CategoryID must be a positive integer");

            if (ManufacturerID <= 0)
                ValidationErrors.Add("ManufacturerID must be a positive integer");

            if (CostPrice < 0)
                ValidationErrors.Add("CostPrice cannot be negative");

            if (Price < 0)
                ValidationErrors.Add("SellPrice cannot be negative");

            if (Quantity < 0)
                ValidationErrors.Add("Qty cannot be negative");

            // Date validations
            if (DateCreated == default)
                ValidationErrors.Add("DateCreated is required");

            if (DateUpdated == default)
                ValidationErrors.Add("DateUpdated is required");

            // Optional field validations
            if (ReorderPoint.HasValue && ReorderPoint < 0)
                ValidationErrors.Add("Reorder Point cannot be negative");

            if (ReorderQuantity.HasValue && ReorderQuantity < 0)
                ValidationErrors.Add("Reorder Quantity cannot be negative");

            // Business logic validations
            if (Price > 0 && CostPrice > Price)
                ValidationErrors.Add("CostPrice cannot be higher than SellPrice");

            return ValidationErrors.Count == 0;
        }
    }
}