namespace ChillBlastWMS_MVC.Models
{
    public class ImportEntityConfig
    {
        public string DisplayName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string[] RequiredFields { get; set; } = Array.Empty<string>();
        public string[] OptionalFields { get; set; } = Array.Empty<string>();
        public long MaxFileSize { get; set; }
        public string[] SupportedFormats { get; set; } = Array.Empty<string>();
        public string TemplateAction { get; set; } = string.Empty;
    }
}