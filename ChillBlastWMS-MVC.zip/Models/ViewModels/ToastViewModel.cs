namespace ChillBlastWMS_MVC.Models.ViewModels
{
    public class ToastViewModel
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Title { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public string Type { get; set; } = "info";
        public DateTime Timestamp { get; set; } = DateTime.Now;
        public Dictionary<string, string> Actions { get; set; } = new Dictionary<string, string>();
    }
}