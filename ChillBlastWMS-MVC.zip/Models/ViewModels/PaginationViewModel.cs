namespace ChillBlastWMS_MVC.Models.ViewModels
{
    public class PaginationViewModel
    {
        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
        public int PageSize { get; set; }
        public int TotalItems { get; set; }
        public Dictionary<string, object> RouteValues { get; set; } = new Dictionary<string, object>();
    }
}