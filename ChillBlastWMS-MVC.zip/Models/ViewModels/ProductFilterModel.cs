namespace ChillBlastWMS_MVC.Models.ViewModels
{
    public class ProductFilterModel
    {
        public string? SearchTerm { get; set; }
        public string? Category { get; set; }
        public string SortBy { get; set; } = "Name";
        public string SortOrder { get; set; } = "asc";
        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }
        public string StockStatus { get; set; } = "all";
        public int Page { get; set; } = 1;
        public int PageSize { get; set; } = 20;
        
    }

    public class BulkUpdateModel
    {
        public int[] ProductIds { get; set; } = Array.Empty<int>();
        public string? Operation { get; set; }
        public string? NewCategory { get; set; }
        public decimal? PriceAdjustment { get; set; }
        public int? NewReorderPoint { get; set; }
    }
}