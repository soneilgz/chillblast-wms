using System.ComponentModel.DataAnnotations;

namespace ChillBlastWMS_MVC.Models.ViewModels
{
    public class ProductViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "SKU is required")]
        [Display(Name = "SKU")]
        [StringLength(50, ErrorMessage = "SKU cannot exceed 50 characters")]
        public string SKU { get; set; } = string.Empty;

        [Required(ErrorMessage = "Product name is required")]
        [Display(Name = "Product Name")]
        [StringLength(200, ErrorMessage = "Product name cannot exceed 200 characters")]
        public string Name { get; set; } = string.Empty;

        [Display(Name = "Description")]
        [StringLength(1000, ErrorMessage = "Description cannot exceed 1000 characters")]
        public string? Description { get; set; }

        [Display(Name = "Category")]
        [StringLength(100, ErrorMessage = "Category cannot exceed 100 characters")]
        public string? Category { get; set; }

        [Required(ErrorMessage = "Cost price is required")]
        [Display(Name = "Cost Price")]
        [Range(0, double.MaxValue, ErrorMessage = "Cost price must be a positive value")]
        [DataType(DataType.Currency)]
        public decimal Cost { get; set; }

        [Required(ErrorMessage = "Sell price is required")]
        [Display(Name = "Sell Price")]
        [Range(0, double.MaxValue, ErrorMessage = "Sell price must be a positive value")]
        [DataType(DataType.Currency)]
        public decimal Price { get; set; }

        [Required(ErrorMessage = "Quantity is required")]
        [Display(Name = "Quantity in Stock")]
        [Range(0, int.MaxValue, ErrorMessage = "Quantity must be a positive value")]
        public int Quantity { get; set; }

        [Display(Name = "Warehouse Location")]
        [StringLength(50, ErrorMessage = "Location cannot exceed 50 characters")]
        public string? Location { get; set; }

        [Display(Name = "Reorder Point")]
        [Range(0, int.MaxValue, ErrorMessage = "Reorder Point must be a positive value")]
        public int ReorderPoint { get; set; }

        [Display(Name = "Reorder Quantity")]
        [Range(0, int.MaxValue, ErrorMessage = "Reorder Quantity must be a positive value")]
        public int ReorderQuantity { get; set; }

        [Display(Name = "Supplier")]
        [StringLength(100, ErrorMessage = "Supplier name cannot exceed 100 characters")]
        public string? Supplier { get; set; }

        [Display(Name = "Active")]
        public bool IsActive { get; set; } = true;

        [Display(Name = "Created Date")]
        [DataType(DataType.DateTime)]
        public DateTime CreatedAt { get; set; }

        [Display(Name = "Last Updated")]
        [DataType(DataType.DateTime)]
        public DateTime? UpdatedAt { get; set; }

        [Display(Name = "Stock Status")]
        public string StockStatus
        {
            get
            {
                if (Quantity == 0)
                    return "Out of Stock";
                else if (Quantity <= ReorderPoint)
                    return "Low Stock";
                else
                    return "In Stock";
            }
        }

        [Display(Name = "Stock Level")]
        public string StockLevel
        {
            get
            {
                if (Quantity == 0)
                    return "danger";
                else if (Quantity <= ReorderPoint)
                    return "warning";
                else
                    return "success";
            }
        }

        [Display(Name = "Price Margin")]
        public decimal PriceMargin
        {
            get
            {
                if (Price == 0) return 0;
                return ((Price - Cost) / Price) * 100;
            }
        }

        [Display(Name = "Margin Status")]
        public string MarginStatus
        {
            get
            {
                var margin = PriceMargin;
                if (margin < 0)
                    return "danger";
                else if (margin < 15)
                    return "warning";
                else if (margin < 30)
                    return "info";
                else
                    return "success";
            }
        }
    }
}