using System.ComponentModel.DataAnnotations;
using ChillBlastWMS_MVC.Services.Business;

namespace ChillBlastWMS_MVC.Models.ViewModels
{
    public class ImportViewModel
    {
        [Required(ErrorMessage = "Please select a CSV file to import")]
        [Display(Name = "CSV File")]
        public IFormFile? CsvFile { get; set; }

        [Display(Name = "Update Existing Products")]
        public bool UpdateExisting { get; set; } = false;

        [Display(Name = "Skip Invalid Records")]
        public bool SkipInvalidRecords { get; set; } = true;

        [Display(Name = "Import Type")]
        public string ImportType { get; set; } = "Product";
    }

    public class ImportResultViewModel
    {
        public bool Success { get; set; }
        public string FileName { get; set; } = string.Empty;
        public int TotalRecords { get; set; }
        public int SuccessfulRecords { get; set; }
        public int FailedRecords { get; set; }
        public int UpdatedRecords { get; set; }
        public int SkippedRecords { get; set; }
        public List<ImportErrorDetail> Errors { get; set; } = new List<ImportErrorDetail>();
        public TimeSpan ProcessingTime { get; set; }
        public string Message { get; set; } = string.Empty;
    }

    public class ImportErrorDetail
    {
        public int RowNumber { get; set; }
        public int Row { get; set; }
        public string SKU { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public string ErrorMessage { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public string Field { get; set; } = string.Empty;
        public string Value { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty; // SKIP, FLAG, WARNING, ERROR
        public string Severity { get; set; } = string.Empty; // Critical, High, Medium, Low
        public string Resolution { get; set; } = string.Empty; // Suggested action
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;

        public string CategoryBadgeClass
        {
            get
            {
                return Category?.ToUpper() switch
                {
                    "SKIP" => "badge bg-danger",
                    "FLAG" => "badge bg-warning", 
                    "WARNING" => "badge bg-warning",
                    "INFO" => "badge bg-info",
                    "ERROR" => "badge bg-danger",
                    _ => "badge bg-secondary"
                };
            }
        }

        public string SeverityBadgeClass
        {
            get
            {
                return Severity?.ToLower() switch
                {
                    "critical" => "badge bg-danger",
                    "high" => "badge bg-warning",
                    "medium" => "badge bg-info", 
                    "low" => "badge bg-light text-dark",
                    _ => "badge bg-secondary"
                };
            }
        }
    }

    public class ImportDashboardViewModel
    {
        public IEnumerable<ImportHistoryViewModel> ImportHistory { get; set; } = Enumerable.Empty<ImportHistoryViewModel>();
        public ImportStatisticsViewModel Statistics { get; set; } = new ImportStatisticsViewModel();
        public Dictionary<string, object> SupportedEntities { get; set; } = new Dictionary<string, object>();
        public int CurrentPage { get; set; } = 1;
        public int PageSize { get; set; } = 20;
        public int TotalRecords { get; set; }
        public int TotalPages => (int)Math.Ceiling((double)TotalRecords / PageSize);
        public string? EntityTypeFilter { get; set; }
        public string? StatusFilter { get; set; }
        public DateTime? FromDateFilter { get; set; }
        public DateTime? ToDateFilter { get; set; }
        
        // Legacy properties for backward compatibility
        public List<ImportHistoryViewModel> RecentImports => ImportHistory?.ToList() ?? new List<ImportHistoryViewModel>();
        public Dictionary<string, int> ImportsByType { get; set; } = new Dictionary<string, int>();
        public Dictionary<string, int> ImportsByStatus { get; set; } = new Dictionary<string, int>();
    }

    public class ImportStatisticsViewModel
    {
        public int TotalImports { get; set; }
        public int SuccessfulImports { get; set; }
        public int FailedImports { get; set; }
        public double SuccessRate { get; set; }
        public int TotalRecordsProcessed { get; set; }
        public int TotalRecordsSuccessful { get; set; }
        public int TotalRecordsFailed { get; set; }
        public double AverageProcessingTime { get; set; }
        public int ImportsLast30Days { get; set; }
        public Dictionary<string, int> ImportsByEntityType { get; set; } = new Dictionary<string, int>();
        
        // Legacy properties for backward compatibility
        public int ImportsThisMonth => ImportsLast30Days;
        public DateTime? LastImportDate { get; set; }
        public string MostUsedImportType { get; set; } = string.Empty;
        public int AverageRecordsPerImport { get; set; }
        public int FailedRecords => TotalRecordsFailed;
        public int ActiveImports { get; set; }
    }

    public class ImportHistoryViewModel
    {
        public int Id { get; set; }

        [Display(Name = "File Name")]
        public string FileName { get; set; } = string.Empty;

        [Display(Name = "Import Date")]
        [DataType(DataType.DateTime)]
        public DateTime ImportDate { get; set; }

        [Display(Name = "Status")]
        public string Status { get; set; } = string.Empty;

        [Display(Name = "Total Records")]
        public int TotalRecords { get; set; }

        [Display(Name = "Successful")]
        public int SuccessfulRecords { get; set; }

        [Display(Name = "Failed")]
        public int FailedRecords { get; set; }

        [Display(Name = "Imported By")]
        public string? ImportedBy { get; set; }

        [Display(Name = "Import Type")]
        public string ImportType { get; set; } = string.Empty;

        [Display(Name = "File Size")]
        public long FileSize { get; set; }

        [Display(Name = "Success Count")]
        public int SuccessCount { get; set; }

        [Display(Name = "Update Count")]
        public int UpdateCount { get; set; }

        [Display(Name = "Error Count")]
        public int ErrorCount { get; set; }

        [Display(Name = "Processing Time")]
        public string ProcessingTimeDisplay
        {
            get
            {
                if (ProcessingTime.HasValue)
                {
                    if (ProcessingTime.Value.TotalSeconds < 60)
                        return $"{ProcessingTime.Value.TotalSeconds:F1} seconds";
                    else
                        return $"{ProcessingTime.Value.TotalMinutes:F1} minutes";
                }
                return "N/A";
            }
        }

        public TimeSpan? ProcessingTime { get; set; }

        [Display(Name = "File Size")]
        public string FileSizeDisplay
        {
            get
            {
                if (FileSizeBytes.HasValue)
                {
                    if (FileSizeBytes < 1024)
                        return $"{FileSizeBytes} bytes";
                    else if (FileSizeBytes < 1024 * 1024)
                        return $"{FileSizeBytes / 1024.0:F1} KB";
                    else
                        return $"{FileSizeBytes / (1024.0 * 1024.0):F1} MB";
                }
                return "N/A";
            }
        }

        public long? FileSizeBytes { get; set; }

        public string StatusBadgeClass
        {
            get
            {
                return Status?.ToLower() switch
                {
                    "completed" => "badge-success",
                    "failed" => "badge-danger",
                    "partial" => "badge-warning",
                    "pending" => "badge-info",
                    _ => "badge-secondary"
                };
            }
        }
    }

    public class ImportResultPageViewModel
    {
        public ImportResultModel ImportResult { get; set; } = new ImportResultModel();
        public List<ImportErrorDetail> ErrorDetails { get; set; } = new List<ImportErrorDetail>();
        public bool HasErrors { get; set; }
        public string ImportId { get; set; } = string.Empty;
        public ErrorSummary? ErrorSummary { get; set; }
        public bool CanRetry { get; set; }

        // Categorized errors for display
        public List<ImportErrorDetail> CriticalErrors => ErrorDetails.Where(e => e.Severity == "Critical").ToList();
        public List<ImportErrorDetail> HighErrors => ErrorDetails.Where(e => e.Severity == "High").ToList();
        public List<ImportErrorDetail> MediumErrors => ErrorDetails.Where(e => e.Severity == "Medium").ToList();
        public List<ImportErrorDetail> LowErrors => ErrorDetails.Where(e => e.Severity == "Low").ToList();
        
        public List<ImportErrorDetail> SkippedRows => ErrorDetails.Where(e => e.Category == "SKIP").ToList();
        public List<ImportErrorDetail> FlaggedRows => ErrorDetails.Where(e => e.Category == "FLAG").ToList();
        public List<ImportErrorDetail> WarningRows => ErrorDetails.Where(e => e.Category == "WARNING").ToList();
        public List<ImportErrorDetail> InfoRows => ErrorDetails.Where(e => e.Category == "INFO").ToList();
    }

    public class ErrorSummary
    {
        public int TotalErrors { get; set; }
        public int CriticalErrors { get; set; }
        public int WarningErrors { get; set; }
    }

    public class ImportUploadViewModel
    {
        public string EntityType { get; set; } = "Products";
        public ImportEntityConfig? EntityConfig { get; set; }
        public Dictionary<string, ImportEntityConfig> SupportedEntities { get; set; } = new Dictionary<string, ImportEntityConfig>();
        
        [Required(ErrorMessage = "Please select a file to upload")]
        public IFormFile? ImportFile { get; set; }
        
        public ImportOptionsViewModel ImportOptions { get; set; } = new ImportOptionsViewModel();
    }

    public class ImportOptionsViewModel
    {
        public bool UpdateExisting { get; set; }
        public bool SkipInvalidRecords { get; set; } = true;
        public bool SkipErrors { get; set; } = true;
        public bool ValidateOnly { get; set; }
        public int BatchSize { get; set; } = 500;
        public bool BackupBeforeImport { get; set; } = true;
        public bool CreateMissingReferences { get; set; }
        public bool CreateMissingCategories { get; set; }
        public string? DefaultCategory { get; set; }
        public string? DefaultSupplier { get; set; }
        public string? DefaultLocation { get; set; }
        public bool EnableDataTransformation { get; set; } = true;
        public bool EnableAnomalyDetection { get; set; } = true;
    }

    public class ImportPreviewViewModel
    {
        public string ImportId { get; set; } = string.Empty;
        public string EntityType { get; set; } = string.Empty;
        public string FileName { get; set; } = string.Empty;
        public string FileType { get; set; } = string.Empty;
        public long FileSizeBytes { get; set; }
        public long FileSize { get; set; }
        public int TotalRows { get; set; }
        public int TotalRecords { get; set; }
        public int ValidRows { get; set; }
        public int ValidRecords { get; set; }
        public int InvalidRows { get; set; }
        public string ImportType { get; set; } = string.Empty;
        public int IssueCount { get; set; }
        public int ErrorCount { get; set; }
        public int WarningCount { get; set; }
        public int DuplicateCount { get; set; }
        public List<string> Headers { get; set; } = new List<string>();
        public List<string> Columns { get; set; } = new List<string>();
        public List<Dictionary<string, object>> PreviewData { get; set; } = new List<Dictionary<string, object>>();
        public Dictionary<string, string> ColumnMappings { get; set; } = new Dictionary<string, string>();
        public bool HasErrors { get; set; }
        public bool HasWarnings { get; set; }
        public List<string> ValidationErrors { get; set; } = new List<string>();
        public List<string> ValidationWarnings { get; set; } = new List<string>();
        public List<ImportErrorDetail> Errors { get; set; } = new List<ImportErrorDetail>();
        public List<ImportErrorDetail> Warnings { get; set; } = new List<ImportErrorDetail>();
        public List<DuplicateRecord> Duplicates { get; set; } = new List<DuplicateRecord>();
        public ImportOptionsViewModel Options { get; set; } = new ImportOptionsViewModel();
        public ImportOptionsViewModel ImportOptions { get; set; } = new ImportOptionsViewModel();
        public string SessionId { get; set; } = string.Empty;
        public ImportValidationResult ValidationResult { get; set; } = new ImportValidationResult();
        public Dictionary<string, string> SuggestedMappings { get; set; } = new Dictionary<string, string>();
    }

    public class ImportErrorViewModel
    {
        public string ImportId { get; set; } = string.Empty;
        public string FileName { get; set; } = string.Empty;
        public ImportErrorCollection ErrorCollection { get; set; } = new ImportErrorCollection();
        public ImportErrorReport ErrorReport { get; set; } = new ImportErrorReport();
        public ImportResultModel? ImportResult { get; set; }
    }

    public class DuplicateRecord
    {
        public int RowNumber { get; set; }
        public string SKU { get; set; } = string.Empty;
        public string Key { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public List<int> DuplicateRows { get; set; } = new List<int>();
        public string Reason { get; set; } = string.Empty;
    }
}