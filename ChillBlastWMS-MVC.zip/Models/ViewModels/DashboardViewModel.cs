namespace ChillBlastWMS_MVC.Models.ViewModels
{
    public class DashboardViewModel
    {
        public string UserName { get; set; } = string.Empty;
        public string UserEmail { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
        
        // Welcome message based on time of day
        public string WelcomeMessage
        {
            get
            {
                var hour = DateTime.Now.Hour;
                return hour switch
                {
                    < 12 => "Good morning",
                    < 17 => "Good afternoon", 
                    _ => "Good evening"
                };
            }
        }
    }
}