using ChillBlastWMS_MVC.Models.Common;

namespace ChillBlastWMS_MVC.Models.ViewModels
{
    public class SearchFiltersViewModel
    {
        public string SortBy { get; set; } = string.Empty;
        
        // Additional properties for _SearchFilters.cshtml view
        public int ActiveFilterCount { get; set; }
        public string SearchQuery { get; set; } = string.Empty;
        public bool InStock { get; set; }
        public bool LowStock { get; set; }
        public bool OutOfStock { get; set; }
        public bool ActiveOnly { get; set; }
        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }
        public DateTime? DateFrom { get; set; }
        public DateTime? DateTo { get; set; }
        public string SkuContains { get; set; } = string.Empty;
        public string Barcode { get; set; } = string.Empty;
        public string Tags { get; set; } = string.Empty;
        public decimal? MinMargin { get; set; }
        public decimal? MinWeight { get; set; }
        public decimal? MaxWeight { get; set; }
        public bool HasImages { get; set; }
        public List<ActiveFilter> ActiveFilters { get; set; } = new List<ActiveFilter>();
        public int TotalResults { get; set; }
        
        // Dropdown filter properties
        public string Category { get; set; } = string.Empty;
        public string Manufacturer { get; set; } = string.Empty;
        public string Supplier { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public int PageSize { get; set; } = 25;
    }
}