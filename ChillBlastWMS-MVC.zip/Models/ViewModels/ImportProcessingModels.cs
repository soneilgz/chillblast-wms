using ChillBlastWMS_MVC.Utilities;

namespace ChillBlastWMS_MVC.Models.ViewModels
{
    public class ImportProcessingReport
    {
        public int TotalRecords { get; set; }
        public int SkippedDuplicates { get; set; }
        public List<DuplicateGroup> DuplicateGroups { get; set; } = new List<DuplicateGroup>();
        public List<Anomaly> Anomalies { get; set; } = new List<Anomaly>();
        public List<BusinessRuleViolation> BusinessRuleViolations { get; set; } = new List<BusinessRuleViolation>();
    }

    public class BusinessRuleValidationResult
    {
        public bool IsValid { get; set; }
        public List<BusinessRuleViolation> Violations { get; set; } = new List<BusinessRuleViolation>();
    }

    public class BusinessRuleViolation
    {
        public string SKU { get; set; } = string.Empty;
        public string Rule { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
    }

    public class ImportReport
    {
        public string Summary { get; set; } = string.Empty;
        public ImportProcessingReport Details { get; set; } = new ImportProcessingReport();
    }
}