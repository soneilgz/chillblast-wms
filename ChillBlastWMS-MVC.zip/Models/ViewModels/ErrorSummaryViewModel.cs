using ChillBlastWMS_MVC.Models.Common;

namespace ChillBlastWMS_MVC.Models.ViewModels
{
    public class ErrorSummaryViewModel
    {
        public string Title { get; set; } = "Errors Found";
        public string Message { get; set; } = string.Empty;
        public List<ErrorDetail> Errors { get; set; } = new List<ErrorDetail>();
        public int TotalErrors { get; set; }
        public int ErrorsShown { get; set; }
        public bool HasMore { get; set; }
        public string ErrorType { get; set; } = "Validation";
        public bool CanRetry { get; set; }
        public string RetryAction { get; set; } = string.Empty;
        public string RetryController { get; set; } = string.Empty;
        public object? RetryRouteValues { get; set; }
    }
}