using System.Text;

namespace ChillBlastWMS_MVC.Models.ViewModels
{
    public class ImportErrorModel
    {
        public string ErrorId { get; set; } = Guid.NewGuid().ToString();
        public ErrorCategory Category { get; set; }
        public ErrorSeverity Severity { get; set; }
        public int? RowNumber { get; set; }
        public string? ColumnName { get; set; }
        public string? SKU { get; set; }
        public string? ProductName { get; set; }
        public string ErrorMessage { get; set; } = string.Empty;
        public string? DetailedMessage { get; set; }
        public string? OriginalValue { get; set; }
        public string? SuggestedFix { get; set; }
        public bool IsResolved { get; set; }
    }

    public enum ErrorCategory
    {
        FileFormat,
        DataValidation,
        BusinessRule,
        Duplicate,
        DataType,
        RequiredField,
        RangeViolation,
        FormatViolation,
        ReferentialIntegrity,
        SystemError,
        DatabaseError,
        NetworkError,
        PermissionError,
        Unknown
    }

    public enum ErrorSeverity
    {
        Critical,   // Import cannot continue
        High,       // Record will be skipped
        Medium,     // Data will be modified
        Low,        // Warning only
        Info        // Informational
    }

    public class ImportErrorCollection
    {
        public string ImportId { get; set; } = string.Empty;
        public List<ImportErrorModel> Errors { get; set; } = new List<ImportErrorModel>();
        public int TotalErrors => Errors.Count;
        public int CriticalErrors => Errors.Count(e => e.Severity == ErrorSeverity.Critical);
        public int HighErrors => Errors.Count(e => e.Severity == ErrorSeverity.High);
        public int MediumErrors => Errors.Count(e => e.Severity == ErrorSeverity.Medium);
        public int LowErrors => Errors.Count(e => e.Severity == ErrorSeverity.Low);
        public int InfoMessages => Errors.Count(e => e.Severity == ErrorSeverity.Info);
        
        public Dictionary<ErrorCategory, int> ErrorsByCategory => 
            Errors.GroupBy(e => e.Category)
                  .ToDictionary(g => g.Key, g => g.Count());
        
        public Dictionary<string, int> ErrorsByColumn => 
            Errors.Where(e => !string.IsNullOrEmpty(e.ColumnName))
                  .GroupBy(e => e.ColumnName!)
                  .ToDictionary(g => g.Key, g => g.Count());
    }


    public class ImportErrorReport
    {
        public string ImportId { get; set; } = string.Empty;
        public List<ErrorPattern> DetectedPatterns { get; set; } = new List<ErrorPattern>();
        public List<ErrorRecommendation> Recommendations { get; set; } = new List<ErrorRecommendation>();
    }

    public class ErrorPattern
    {
        public string PatternId { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int Occurrences { get; set; }
        public List<int> AffectedRows { get; set; } = new List<int>();
        public string? CommonCause { get; set; }
        public string? SuggestedResolution { get; set; }
    }

    public class ErrorRecommendation
    {
        public RecommendationPriority Priority { get; set; }
        public string Recommendation { get; set; } = string.Empty;
        public string Explanation { get; set; } = string.Empty;
        public int AffectedRecords { get; set; }
        public string? AutoFixAvailable { get; set; }
    }

    public enum RecommendationPriority
    {
        Critical,
        High,
        Medium,
        Low
    }
}