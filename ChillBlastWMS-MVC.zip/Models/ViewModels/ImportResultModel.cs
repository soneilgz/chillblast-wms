using ChillBlastWMS_MVC.Utilities;

namespace ChillBlastWMS_MVC.Models.ViewModels
{
    public class ImportResultModel
    {
        public string ImportId { get; set; } = string.Empty;
        public string FileName { get; set; } = string.Empty;
        public DateTime ImportStartTime { get; set; }
        public DateTime ImportEndTime { get; set; }
        public TimeSpan TotalDuration => ImportEndTime - ImportStartTime;
        public string DurationDisplay => FormatDuration(TotalDuration);
        public bool IsSuccess { get; set; }
        public ImportCompletionStatus CompletionStatus { get; set; }
        
        // Record counts
        public int TotalRecordsInFile { get; set; }
        public int RecordsProcessed { get; set; }
        public int RecordsCreated { get; set; }
        public int RecordsUpdated { get; set; }
        public int RecordsSkipped { get; set; }
        public int RecordsFailed { get; set; }
        
        // Performance metrics
        public double SuccessRate => RecordsProcessed > 0 ? ((RecordsCreated + RecordsUpdated) * 100.0 / RecordsProcessed) : 0;
        
        // Error summary
        public List<ErrorSummaryItem> ErrorSummary { get; set; } = new List<ErrorSummaryItem>();
        
        // Detailed messages
        public List<ImportResultMessage> Messages { get; set; } = new List<ImportResultMessage>();

        private static string FormatDuration(TimeSpan duration)
        {
            if (duration.TotalSeconds < 60)
                return $"{duration.TotalSeconds:F1} seconds";
            if (duration.TotalMinutes < 60)
                return $"{duration.TotalMinutes:F1} minutes";
            return $"{duration.TotalHours:F1} hours";
        }
    }

    public class ErrorSummaryItem
    {
        public string ErrorType { get; set; } = string.Empty;
        public int Count { get; set; }
    }

    public class ImportResultMessage
    {
        public string Message { get; set; } = string.Empty;
    }

    public enum ImportCompletionStatus
    {
        Success,
        PartialSuccess,
        Failed,
        Cancelled,
        ValidationFailed
    }

}