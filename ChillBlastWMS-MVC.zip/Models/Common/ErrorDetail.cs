namespace ChillBlastWMS_MVC.Models.Common
{
    public class ErrorDetail
    {
        public string Field { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public string Code { get; set; } = string.Empty;
        public string Severity { get; set; } = "Error";
        public int? LineNumber { get; set; }
    }
}