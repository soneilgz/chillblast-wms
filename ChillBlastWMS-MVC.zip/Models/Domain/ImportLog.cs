using System.ComponentModel.DataAnnotations;

namespace ChillBlastWMS_MVC.Models.Domain
{
    public class ImportLog
    {
        public int Id { get; set; }

        [Required]
        [StringLength(255)]
        public string FileName { get; set; } = string.Empty;

        [Required]
        public DateTime ImportDate { get; set; } = DateTime.UtcNow;

        [Required]
        [StringLength(50)]
        public string Status { get; set; } = "Pending";

        public int TotalRecords { get; set; }

        public int SuccessfulRecords { get; set; }

        public int FailedRecords { get; set; }

        public string? ErrorDetails { get; set; }

        [StringLength(450)]
        public string? ImportedBy { get; set; }

        public TimeSpan? ProcessingTime { get; set; }

        [StringLength(50)]
        public string ImportType { get; set; } = "Product";

        public long? FileSizeBytes { get; set; }

        public DateTime? CompletedAt { get; set; }
    }
}