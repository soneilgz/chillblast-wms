using ChillBlastWMS_MVC.Models.Domain;

namespace ChillBlastWMS_MVC.Services.Repositories
{
    public interface IProductRepository : IRepository<Product>
    {
        Task<Product?> GetBySkuAsync(string sku);
        Task<IEnumerable<Product>> SearchAsync(string searchTerm, string? category = null, bool? isActive = null);
        Task<IEnumerable<Product>> GetLowStockProductsAsync(int? threshold = null);
        Task<IEnumerable<Product>> GetOutOfStockProductsAsync();
        Task<IEnumerable<Product>> GetByCategoryAsync(string category, bool activeOnly = true);
        Task<IEnumerable<string>> GetCategoriesAsync();
        Task<Dictionary<string, int>> GetStockSummaryAsync();
        Task<bool> SkuExistsAsync(string sku, int? excludeId = null);
        Task BulkInsertAsync(IEnumerable<Product> products);
        Task<int> BulkUpdateAsync(IEnumerable<Product> products);
        Task<(int TotalProducts, decimal TotalValue, int LowStockCount, int OutOfStockCount)> GetInventoryStatisticsAsync();
        Task<IEnumerable<Product>> GetRecentlyAddedAsync(int count = 10);
        Task<IEnumerable<Product>> GetRecentlyUpdatedAsync(int count = 10);
    }
}