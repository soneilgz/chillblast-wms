using ChillBlastWMS_MVC.Models.Domain;

namespace ChillBlastWMS_MVC.Services.Repositories
{
    public interface IImportLogRepository : IRepository<ImportLog>
    {
        Task<IEnumerable<ImportLog>> GetRecentImportsAsync(int count = 10);
        Task<IEnumerable<ImportLog>> GetImportsByUserAsync(string userId);
        Task<IEnumerable<ImportLog>> GetImportsByStatusAsync(string status);
        Task<IEnumerable<ImportLog>> GetImportsByDateRangeAsync(DateTime startDate, DateTime endDate);
        Task<ImportLog?> GetLatestImportAsync();
        Task<Dictionary<string, int>> GetImportStatisticsAsync();
        Task<(int TotalImports, int SuccessfulImports, int FailedImports, int TotalRecordsProcessed)> GetImportSummaryAsync(DateTime? since = null);
        Task<IEnumerable<ImportLog>> GetFailedImportsAsync(int? limit = null);
        Task<double> GetAverageProcessingTimeAsync(string? importType = null);
        Task UpdateImportStatusAsync(int importId, string status, string? errorDetails = null);
        Task CompleteImportAsync(int importId, int successCount, int failedCount, TimeSpan processingTime);
    }
}