using ChillBlastWMS_MVC.Data;
using ChillBlastWMS_MVC.Models.Domain;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace ChillBlastWMS_MVC.Services.Repositories
{
    public class ProductRepository : Repository<Product>, IProductRepository
    {
        public ProductRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<Product?> GetBySkuAsync(string sku)
        {
            return await _dbSet.FirstOrDefaultAsync(p => p.SKU == sku);
        }

        public async Task<IEnumerable<Product>> SearchAsync(string searchTerm, string? category = null, bool? isActive = null)
        {
            var query = _dbSet.AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                searchTerm = searchTerm.ToLower();
                query = query.Where(p => 
                    p.SKU.ToLower().Contains(searchTerm) ||
                    p.Name.ToLower().Contains(searchTerm) ||
                    (p.Description != null && p.Description.ToLower().Contains(searchTerm)) ||
                    (p.Supplier != null && p.Supplier.ToLower().Contains(searchTerm)));
            }

            if (!string.IsNullOrWhiteSpace(category))
            {
                query = query.Where(p => p.Category == category);
            }

            if (isActive.HasValue)
            {
                query = query.Where(p => p.IsActive == isActive.Value);
            }

            return await query.OrderBy(p => p.Name).ToListAsync();
        }

        public async Task<IEnumerable<Product>> GetLowStockProductsAsync(int? threshold = null)
        {
            var reorderThreshold = threshold ?? 0;
            
            return await _dbSet
                .Where(p => p.IsActive && 
                           (p.Quantity <= p.ReorderPoint || 
                            (reorderThreshold > 0 && p.Quantity <= reorderThreshold)))
                .OrderBy(p => p.Quantity)
                .ThenBy(p => p.Name)
                .ToListAsync();
        }

        public async Task<IEnumerable<Product>> GetOutOfStockProductsAsync()
        {
            return await _dbSet
                .Where(p => p.IsActive && p.Quantity == 0)
                .OrderBy(p => p.Name)
                .ToListAsync();
        }

        public async Task<IEnumerable<Product>> GetByCategoryAsync(string category, bool activeOnly = true)
        {
            var query = _dbSet.Where(p => p.Category == category);
            
            if (activeOnly)
            {
                query = query.Where(p => p.IsActive);
            }

            return await query.OrderBy(p => p.Name).ToListAsync();
        }

        public async Task<IEnumerable<string>> GetCategoriesAsync()
        {
            return await _dbSet
                .Where(p => p.Category != null)
                .Select(p => p.Category!)
                .Distinct()
                .OrderBy(c => c)
                .ToListAsync();
        }

        public async Task<Dictionary<string, int>> GetStockSummaryAsync()
        {
            var summary = new Dictionary<string, int>();

            summary["TotalProducts"] = await _dbSet.CountAsync(p => p.IsActive);
            summary["InStock"] = await _dbSet.CountAsync(p => p.IsActive && p.Quantity > p.ReorderPoint);
            summary["LowStock"] = await _dbSet.CountAsync(p => p.IsActive && p.Quantity > 0 && p.Quantity <= p.ReorderPoint);
            summary["OutOfStock"] = await _dbSet.CountAsync(p => p.IsActive && p.Quantity == 0);
            summary["Inactive"] = await _dbSet.CountAsync(p => !p.IsActive);

            return summary;
        }

        public async Task<bool> SkuExistsAsync(string sku, int? excludeId = null)
        {
            var query = _dbSet.Where(p => p.SKU == sku);
            
            if (excludeId.HasValue)
            {
                query = query.Where(p => p.Id != excludeId.Value);
            }

            return await query.AnyAsync();
        }

        public async Task BulkInsertAsync(IEnumerable<Product> products)
        {
            if (!products.Any())
                return;

            await _context.Products.AddRangeAsync(products);
            await _context.SaveChangesAsync();
        }

        public async Task<int> BulkUpdateAsync(IEnumerable<Product> products)
        {
            if (!products.Any())
                return 0;

            var productList = products.ToList();
            _dbSet.UpdateRange(productList);
            return await _context.SaveChangesAsync();
        }

        public async Task<(int TotalProducts, decimal TotalValue, int LowStockCount, int OutOfStockCount)> GetInventoryStatisticsAsync()
        {
            var stats = await _dbSet
                .Where(p => p.IsActive)
                .GroupBy(p => 1)
                .Select(g => new
                {
                    TotalProducts = g.Count(),
                    TotalValue = g.Sum(p => p.Price * p.Quantity),
                    LowStockCount = g.Count(p => p.Quantity > 0 && p.Quantity <= p.ReorderPoint),
                    OutOfStockCount = g.Count(p => p.Quantity == 0)
                })
                .FirstOrDefaultAsync();

            if (stats == null)
                return (0, 0, 0, 0);

            return (stats.TotalProducts, stats.TotalValue, stats.LowStockCount, stats.OutOfStockCount);
        }

        public async Task<IEnumerable<Product>> GetRecentlyAddedAsync(int count = 10)
        {
            return await _dbSet
                .Where(p => p.IsActive)
                .OrderByDescending(p => p.CreatedAt)
                .Take(count)
                .ToListAsync();
        }

        public async Task<IEnumerable<Product>> GetRecentlyUpdatedAsync(int count = 10)
        {
            return await _dbSet
                .Where(p => p.IsActive && p.UpdatedAt != null)
                .OrderByDescending(p => p.UpdatedAt)
                .Take(count)
                .ToListAsync();
        }
    }
}