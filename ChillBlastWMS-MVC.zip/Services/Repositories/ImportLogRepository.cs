using ChillBlastWMS_MVC.Data;
using ChillBlastWMS_MVC.Models.Domain;
using Microsoft.EntityFrameworkCore;

namespace ChillBlastWMS_MVC.Services.Repositories
{
    public class ImportLogRepository : Repository<ImportLog>, IImportLogRepository
    {
        public ImportLogRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<IEnumerable<ImportLog>> GetRecentImportsAsync(int count = 10)
        {
            return await _dbSet
                .OrderByDescending(i => i.ImportDate)
                .Take(count)
                .ToListAsync();
        }

        public async Task<IEnumerable<ImportLog>> GetImportsByUserAsync(string userId)
        {
            return await _dbSet
                .Where(i => i.ImportedBy == userId)
                .OrderByDescending(i => i.ImportDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<ImportLog>> GetImportsByStatusAsync(string status)
        {
            return await _dbSet
                .Where(i => i.Status == status)
                .OrderByDescending(i => i.ImportDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<ImportLog>> GetImportsByDateRangeAsync(DateTime startDate, DateTime endDate)
        {
            return await _dbSet
                .Where(i => i.ImportDate >= startDate && i.ImportDate <= endDate)
                .OrderByDescending(i => i.ImportDate)
                .ToListAsync();
        }

        public async Task<ImportLog?> GetLatestImportAsync()
        {
            return await _dbSet
                .OrderByDescending(i => i.ImportDate)
                .FirstOrDefaultAsync();
        }

        public async Task<Dictionary<string, int>> GetImportStatisticsAsync()
        {
            var stats = new Dictionary<string, int>();

            stats["Total"] = await _dbSet.CountAsync();
            stats["Completed"] = await _dbSet.CountAsync(i => i.Status == "Completed");
            stats["Failed"] = await _dbSet.CountAsync(i => i.Status == "Failed");
            stats["Partial"] = await _dbSet.CountAsync(i => i.Status == "Partial");
            stats["Pending"] = await _dbSet.CountAsync(i => i.Status == "Pending");

            return stats;
        }

        public async Task<(int TotalImports, int SuccessfulImports, int FailedImports, int TotalRecordsProcessed)> GetImportSummaryAsync(DateTime? since = null)
        {
            var query = _dbSet.AsQueryable();

            if (since.HasValue)
            {
                query = query.Where(i => i.ImportDate >= since.Value);
            }

            var summary = await query
                .GroupBy(i => 1)
                .Select(g => new
                {
                    TotalImports = g.Count(),
                    SuccessfulImports = g.Count(i => i.Status == "Completed"),
                    FailedImports = g.Count(i => i.Status == "Failed"),
                    TotalRecordsProcessed = g.Sum(i => i.TotalRecords)
                })
                .FirstOrDefaultAsync();

            if (summary == null)
                return (0, 0, 0, 0);

            return (summary.TotalImports, summary.SuccessfulImports, summary.FailedImports, summary.TotalRecordsProcessed);
        }

        public async Task<IEnumerable<ImportLog>> GetFailedImportsAsync(int? limit = null)
        {
            var query = _dbSet
                .Where(i => i.Status == "Failed" || i.FailedRecords > 0)
                .OrderByDescending(i => i.ImportDate);

            if (limit.HasValue)
            {
                return await query.Take(limit.Value).ToListAsync();
            }

            return await query.ToListAsync();
        }

        public async Task<double> GetAverageProcessingTimeAsync(string? importType = null)
        {
            var query = _dbSet.Where(i => i.ProcessingTime != null);

            if (!string.IsNullOrWhiteSpace(importType))
            {
                query = query.Where(i => i.ImportType == importType);
            }

            var processingTimes = await query
                .Select(i => i.ProcessingTime!.Value.TotalSeconds)
                .ToListAsync();

            return processingTimes.Any() ? processingTimes.Average() : 0;
        }

        public async Task UpdateImportStatusAsync(int importId, string status, string? errorDetails = null)
        {
            var import = await _dbSet.FindAsync(importId);
            
            if (import != null)
            {
                import.Status = status;
                
                if (!string.IsNullOrWhiteSpace(errorDetails))
                {
                    import.ErrorDetails = errorDetails;
                }

                if (status == "Completed" || status == "Failed")
                {
                    import.CompletedAt = DateTime.UtcNow;
                }

                await _context.SaveChangesAsync();
            }
        }

        public async Task CompleteImportAsync(int importId, int successCount, int failedCount, TimeSpan processingTime)
        {
            var import = await _dbSet.FindAsync(importId);
            
            if (import != null)
            {
                import.SuccessfulRecords = successCount;
                import.FailedRecords = failedCount;
                import.ProcessingTime = processingTime;
                import.CompletedAt = DateTime.UtcNow;
                
                if (failedCount == 0)
                {
                    import.Status = "Completed";
                }
                else if (successCount == 0)
                {
                    import.Status = "Failed";
                }
                else
                {
                    import.Status = "Partial";
                }

                await _context.SaveChangesAsync();
            }
        }
    }
}