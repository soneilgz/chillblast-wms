using ChillBlastWMS_MVC.Models.DTOs;
using ChillBlastWMS_MVC.Models.ViewModels;
using ChillBlastWMS_MVC.Utilities;
using Microsoft.AspNetCore.Http;

namespace ChillBlastWMS_MVC.Services.Business
{
    public interface IImportService
    {
        Task<ImportResultViewModel> ProcessCsvImportAsync(IFormFile file, ImportOptions options);
        Task<(bool IsValid, List<string> Errors)> ValidateCsvFileAsync(IFormFile file);
        Task<List<ProductImportDto>> ParseCsvFileAsync(IFormFile file);
        Task<ImportResultViewModel> ImportProductsAsync(List<ProductImportDto> products, ImportOptions options);
        Task<byte[]> GenerateImportTemplateAsync();
        Task<byte[]> GenerateErrorReportAsync(List<ImportErrorDetail> errors);
        Task<IEnumerable<ImportHistoryViewModel>> GetImportHistoryAsync(int? limit = null);
        Task<ImportHistoryViewModel?> GetImportDetailsAsync(int importId);
        Task<byte[]> ExportProductsToCsvAsync(ExportOptions options);
        Task<ImportValidationResult> ValidateImportDataAsync(List<ProductImportDto> products);
        Task<(bool Success, string Message)> RollbackImportAsync(int importId);
        
        // New pipeline methods
        Task<CsvValidationResult> ValidateFileAsync(IFormFile file);
        Task<List<ProductImportDto>> ParseCsvAsync(IFormFile file);
        Task<List<ProductImportDto>> TransformDataAsync(List<ProductImportDto> products);
        Task<List<DuplicateGroup>> DetectDuplicatesAsync(List<ProductImportDto> products);
        Task<List<Anomaly>> DetectAnomaliesAsync(List<ProductImportDto> products);
        Task<BusinessRuleValidationResult> ValidateBusinessRulesAsync(List<ProductImportDto> products, List<Anomaly> anomalies);
        Task<ImportResultViewModel> ProcessImportAsync(List<ProductImportDto> products, ImportOptions options, ImportProcessingReport report);
        Task<ImportReport> GenerateImportReportAsync(ImportProcessingReport processingReport, ImportResultViewModel result);
    }

    public class ImportOptions
    {
        public bool UpdateExisting { get; set; } = false;
        public bool SkipInvalidRecords { get; set; } = true;
        public bool ValidateOnly { get; set; } = false;
        public string? DefaultCategory { get; set; }
        public string? DefaultSupplier { get; set; }
        public bool CreateCategories { get; set; } = false;
        public bool BackupBeforeImport { get; set; } = true;
    }

    public class ExportOptions
    {
        public bool ActiveOnly { get; set; } = true;
        public string? Category { get; set; }
        public string? Supplier { get; set; }
        public bool IncludeStockInfo { get; set; } = true;
        public bool IncludePricing { get; set; } = true;
        public List<string>? SelectedFields { get; set; }
    }

    public class ImportValidationResult
    {
        public bool IsValid { get; set; }
        public int TotalRecords { get; set; }
        public int ValidRecords { get; set; }
        public int InvalidRecords { get; set; }
        public List<ImportValidationError> Errors { get; set; } = new List<ImportValidationError>();
        public List<ImportValidationWarning> Warnings { get; set; } = new List<ImportValidationWarning>();
    }

    public class ImportValidationError
    {
        public int RowNumber { get; set; }
        public string FieldName { get; set; } = string.Empty;
        public string Value { get; set; } = string.Empty;
        public string ErrorMessage { get; set; } = string.Empty;
    }

    public class ImportValidationWarning
    {
        public int RowNumber { get; set; }
        public string WarningMessage { get; set; } = string.Empty;
    }
}