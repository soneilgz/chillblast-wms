using ChillBlastWMS_MVC.Models.Domain;

namespace ChillBlastWMS_MVC.Services.Business
{
    public interface IPriceCalculationService
    {
        Task<MarginCalculationResult> CalculateMarginAsync(decimal costPrice, decimal sellingPrice);
        Task<ProfitabilityAnalysis> AnalyzeProfitabilityAsync(int productId);
        Task<IEnumerable<ProfitabilityAnalysis>> AnalyzeCategoryProfitabilityAsync(string category);
        Task<decimal> CalculateTotalInventoryValueAsync();
        Task<Dictionary<string, decimal>> GetInventoryValueByCategoryAsync();
        Task<(bool Success, string Message)> UpdateProductPriceAsync(int productId, decimal newPrice, string reason);
        Task<BulkPriceUpdateResult> BulkUpdatePricesAsync(Dictionary<int, decimal> priceUpdates, string reason);
        Task<IEnumerable<PriceAlert>> GetPriceAlertsAsync();
        Task<CompetitivePriceAnalysis> AnalyzeCompetitivePricingAsync(int productId, decimal? competitorPrice = null);
        Task<IEnumerable<Product>> GetProductsWithNoProfitAsync();
        Task<IEnumerable<Product>> GetHighMarginProductsAsync(decimal marginThreshold = 50);
        Task<IEnumerable<Product>> GetLowMarginProductsAsync(decimal marginThreshold = 20);
    }

    public class MarginCalculationResult
    {
        public decimal CostPrice { get; set; }
        public decimal SellingPrice { get; set; }
        public decimal GrossMargin { get; set; }
        public decimal GrossMarginPercentage { get; set; }
        public decimal Markup { get; set; }
        public decimal MarkupPercentage { get; set; }
        public bool IsProfitable { get; set; }
    }

    public class ProfitabilityAnalysis
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public decimal CostPrice { get; set; }
        public decimal SellingPrice { get; set; }
        public int QuantityInStock { get; set; }
        public decimal TotalCostValue { get; set; }
        public decimal TotalSellingValue { get; set; }
        public decimal PotentialProfit { get; set; }
        public decimal MarginPercentage { get; set; }
        public string ProfitabilityStatus { get; set; } = string.Empty;
    }

    public class BulkPriceUpdateResult
    {
        public int TotalProducts { get; set; }
        public int SuccessfulUpdates { get; set; }
        public int FailedUpdates { get; set; }
        public decimal TotalValueChange { get; set; }
        public List<string> Errors { get; set; } = new List<string>();
        public Dictionary<int, decimal> UpdatedProducts { get; set; } = new Dictionary<int, decimal>();
    }

    public class PriceAlert
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public string AlertType { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public decimal CurrentPrice { get; set; }
        public decimal? SuggestedPrice { get; set; }
        public string Severity { get; set; } = "Low";
    }

    public class CompetitivePriceAnalysis
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = string.Empty;
        public decimal OurPrice { get; set; }
        public decimal? CompetitorPrice { get; set; }
        public decimal? PriceDifference { get; set; }
        public decimal? PriceDifferencePercentage { get; set; }
        public string CompetitivePosition { get; set; } = string.Empty;
        public string Recommendation { get; set; } = string.Empty;
    }

}