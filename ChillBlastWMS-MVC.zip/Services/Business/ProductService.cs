using ChillBlastWMS_MVC.Models.Domain;
using ChillBlastWMS_MVC.Models.ViewModels;
using ChillBlastWMS_MVC.Services.Repositories;
using Microsoft.Extensions.Logging;

namespace ChillBlastWMS_MVC.Services.Business
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;
        private readonly ILogger<ProductService> _logger;

        public ProductService(IProductRepository productRepository, ILogger<ProductService> logger)
        {
            _productRepository = productRepository;
            _logger = logger;
        }

        public async Task<(bool Success, string Message, Product? Product)> CreateProductAsync(ProductViewModel model)
        {
            try
            {
                var validation = await ValidateProductDataAsync(model);
                if (!validation.IsValid)
                {
                    return (false, string.Join(", ", validation.Errors), null);
                }

                if (await _productRepository.SkuExistsAsync(model.SKU))
                {
                    return (false, $"Product with SKU '{model.SKU}' already exists", null);
                }

                var product = MapViewModelToEntity(model);
                await _productRepository.AddAsync(product);
                await _productRepository.SaveChangesAsync();

                _logger.LogInformation($"Product created successfully: SKU={product.SKU}, ID={product.Id}");
                return (true, "Product created successfully", product);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating product");
                return (false, "An error occurred while creating the product", null);
            }
        }

        public async Task<(bool Success, string Message)> UpdateProductAsync(int id, ProductViewModel model)
        {
            try
            {
                var product = await _productRepository.GetByIdAsync(id);
                if (product == null)
                {
                    return (false, "Product not found");
                }

                var validation = await ValidateProductDataAsync(model, true);
                if (!validation.IsValid)
                {
                    return (false, string.Join(", ", validation.Errors));
                }

                if (product.SKU != model.SKU && await _productRepository.SkuExistsAsync(model.SKU, id))
                {
                    return (false, $"Product with SKU '{model.SKU}' already exists");
                }

                UpdateEntityFromViewModel(product, model);
                _productRepository.Update(product);
                await _productRepository.SaveChangesAsync();

                _logger.LogInformation($"Product updated successfully: SKU={product.SKU}, ID={product.Id}");
                return (true, "Product updated successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating product ID={id}");
                return (false, "An error occurred while updating the product");
            }
        }

        public async Task<(bool Success, string Message)> DeleteProductAsync(int id)
        {
            try
            {
                var product = await _productRepository.GetByIdAsync(id);
                if (product == null)
                {
                    return (false, "Product not found");
                }

                _productRepository.Remove(product);
                await _productRepository.SaveChangesAsync();

                _logger.LogInformation($"Product deleted: SKU={product.SKU}, ID={id}");
                return (true, "Product deleted successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting product ID={id}");
                return (false, "An error occurred while deleting the product");
            }
        }

        public async Task<Product?> GetProductByIdAsync(int id)
        {
            return await _productRepository.GetByIdAsync(id);
        }

        public async Task<Product?> GetProductBySkuAsync(string sku)
        {
            return await _productRepository.GetBySkuAsync(sku);
        }

        public async Task<ProductViewModel?> GetProductViewModelAsync(int id)
        {
            var product = await _productRepository.GetByIdAsync(id);
            return product != null ? MapEntityToViewModel(product) : null;
        }

        public async Task<IEnumerable<ProductViewModel>> GetAllProductsAsync(bool activeOnly = true)
        {
            var products = activeOnly 
                ? await _productRepository.GetAllAsync(p => p.IsActive)
                : await _productRepository.GetAllAsync();

            return products.Select(MapEntityToViewModel);
        }

        public async Task<(IEnumerable<ProductViewModel> Products, int TotalCount)> GetPagedProductsAsync(
            int pageNumber, 
            int pageSize, 
            string? searchTerm = null, 
            string? category = null, 
            bool? isActive = null)
        {
            var result = await _productRepository.SearchAsync(searchTerm ?? string.Empty, category, isActive);
            var totalCount = result.Count();
            
            var pagedProducts = result
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .Select(MapEntityToViewModel);

            return (pagedProducts, totalCount);
        }

        public async Task<IEnumerable<ProductViewModel>> SearchProductsAsync(string searchTerm, string? category = null)
        {
            var products = await _productRepository.SearchAsync(searchTerm, category, true);
            return products.Select(MapEntityToViewModel);
        }

        public async Task<IEnumerable<ProductViewModel>> GetLowStockProductsAsync(int? threshold = null)
        {
            var products = await _productRepository.GetLowStockProductsAsync(threshold);
            return products.Select(MapEntityToViewModel);
        }

        public async Task<IEnumerable<ProductViewModel>> GetOutOfStockProductsAsync()
        {
            var products = await _productRepository.GetOutOfStockProductsAsync();
            return products.Select(MapEntityToViewModel);
        }

        public async Task<Dictionary<string, int>> GetStockSummaryAsync()
        {
            return await _productRepository.GetStockSummaryAsync();
        }

        public async Task<(int TotalProducts, decimal TotalValue, int LowStockCount, int OutOfStockCount)> GetInventoryStatisticsAsync()
        {
            return await _productRepository.GetInventoryStatisticsAsync();
        }

        public async Task<IEnumerable<string>> GetCategoriesAsync()
        {
            return await _productRepository.GetCategoriesAsync();
        }

        public async Task<(bool Success, string Message)> AdjustStockAsync(int productId, int adjustment, string reason)
        {
            try
            {
                var product = await _productRepository.GetByIdAsync(productId);
                if (product == null)
                {
                    return (false, "Product not found");
                }

                var newQuantity = product.Quantity + adjustment;
                if (newQuantity < 0)
                {
                    return (false, "Insufficient stock for this adjustment");
                }

                product.Quantity = newQuantity;
                _productRepository.Update(product);
                await _productRepository.SaveChangesAsync();

                _logger.LogInformation($"Stock adjusted for product ID={productId}: {adjustment:+#;-#;0} units. Reason: {reason}");
                return (true, $"Stock adjusted successfully. New quantity: {newQuantity}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error adjusting stock for product ID={productId}");
                return (false, "An error occurred while adjusting stock");
            }
        }

        public async Task<(bool Success, string Message)> UpdateStockLevelsAsync(Dictionary<int, int> stockUpdates)
        {
            try
            {
                var productIds = stockUpdates.Keys.ToList();
                var products = await _productRepository.GetAllAsync(p => productIds.Contains(p.Id));

                foreach (var product in products)
                {
                    if (stockUpdates.TryGetValue(product.Id, out int newQuantity))
                    {
                        product.Quantity = newQuantity;
                    }
                }

                _productRepository.UpdateRange(products);
                await _productRepository.SaveChangesAsync();

                return (true, $"Successfully updated {products.Count()} product stock levels");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating stock levels");
                return (false, "An error occurred while updating stock levels");
            }
        }

        public async Task<ValidationResult> ValidateProductDataAsync(ProductViewModel model, bool isUpdate = false)
        {
            var result = new ValidationResult { IsValid = true };

            if (string.IsNullOrWhiteSpace(model.SKU))
            {
                result.Errors.Add("SKU is required");
                result.IsValid = false;
            }

            if (string.IsNullOrWhiteSpace(model.Name))
            {
                result.Errors.Add("Product name is required");
                result.IsValid = false;
            }

            if (model.Price < 0)
            {
                result.Errors.Add("Price cannot be negative");
                result.IsValid = false;
            }

            if (model.Quantity < 0)
            {
                result.Errors.Add("Quantity cannot be negative");
                result.IsValid = false;
            }

            if (model.ReorderPoint < 0)
            {
                result.Errors.Add("Reorder point cannot be negative");
                result.IsValid = false;
            }

            if (model.ReorderQuantity < 0)
            {
                result.Errors.Add("Reorder quantity cannot be negative");
                result.IsValid = false;
            }

            if (model.Price == 0)
            {
                result.Warnings.Add("Product has zero price");
            }

            if (model.Quantity <= model.ReorderPoint)
            {
                result.Warnings.Add("Current stock is at or below reorder point");
            }

            return await Task.FromResult(result);
        }

        public async Task<IEnumerable<DataAnomalyResult>> DetectAnomaliesAsync()
        {
            var anomalies = new List<DataAnomalyResult>();
            var products = await _productRepository.GetAllAsync();

            foreach (var product in products)
            {
                // Check for missing critical data
                if (string.IsNullOrWhiteSpace(product.Category))
                {
                    anomalies.Add(new DataAnomalyResult
                    {
                        ProductId = product.Id,
                        SKU = product.SKU,
                        ProductName = product.Name,
                        AnomalyType = "Missing Data",
                        Description = "Product has no category assigned",
                        Severity = "Medium"
                    });
                }

                // Check for price anomalies
                if (product.Price == 0 && product.IsActive)
                {
                    anomalies.Add(new DataAnomalyResult
                    {
                        ProductId = product.Id,
                        SKU = product.SKU,
                        ProductName = product.Name,
                        AnomalyType = "Price Anomaly",
                        Description = "Active product has zero price",
                        Severity = "High"
                    });
                }

                // Check for stock anomalies
                if (product.Quantity < 0)
                {
                    anomalies.Add(new DataAnomalyResult
                    {
                        ProductId = product.Id,
                        SKU = product.SKU,
                        ProductName = product.Name,
                        AnomalyType = "Stock Anomaly",
                        Description = "Product has negative stock quantity",
                        Severity = "Critical",
                        Details = { ["Quantity"] = product.Quantity }
                    });
                }

                // Check for reorder point anomalies
                if (product.ReorderPoint > 0 && product.ReorderQuantity == 0)
                {
                    anomalies.Add(new DataAnomalyResult
                    {
                        ProductId = product.Id,
                        SKU = product.SKU,
                        ProductName = product.Name,
                        AnomalyType = "Configuration Anomaly",
                        Description = "Reorder point set but reorder quantity is zero",
                        Severity = "Low"
                    });
                }

                // Check for duplicate SKUs (case-insensitive)
                var duplicates = products.Where(p => 
                    p.Id != product.Id && 
                    string.Equals(p.SKU, product.SKU, StringComparison.OrdinalIgnoreCase));
                
                if (duplicates.Any())
                {
                    anomalies.Add(new DataAnomalyResult
                    {
                        ProductId = product.Id,
                        SKU = product.SKU,
                        ProductName = product.Name,
                        AnomalyType = "Data Integrity",
                        Description = "Potential duplicate SKU detected",
                        Severity = "High",
                        Details = { ["DuplicateIds"] = string.Join(", ", duplicates.Select(d => d.Id)) }
                    });
                }
            }

            return anomalies;
        }

        public async Task<(bool Success, string Message)> DeactivateProductAsync(int id)
        {
            try
            {
                var product = await _productRepository.GetByIdAsync(id);
                if (product == null)
                {
                    return (false, "Product not found");
                }

                if (!product.IsActive)
                {
                    return (false, "Product is already inactive");
                }

                product.IsActive = false;
                _productRepository.Update(product);
                await _productRepository.SaveChangesAsync();

                _logger.LogInformation($"Product deactivated: SKU={product.SKU}, ID={id}");
                return (true, "Product deactivated successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deactivating product ID={id}");
                return (false, "An error occurred while deactivating the product");
            }
        }

        public async Task<(bool Success, string Message)> ReactivateProductAsync(int id)
        {
            try
            {
                var product = await _productRepository.GetByIdAsync(id);
                if (product == null)
                {
                    return (false, "Product not found");
                }

                if (product.IsActive)
                {
                    return (false, "Product is already active");
                }

                product.IsActive = true;
                _productRepository.Update(product);
                await _productRepository.SaveChangesAsync();

                _logger.LogInformation($"Product reactivated: SKU={product.SKU}, ID={id}");
                return (true, "Product reactivated successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error reactivating product ID={id}");
                return (false, "An error occurred while reactivating the product");
            }
        }

        public async Task<IEnumerable<ProductViewModel>> GetRecentlyAddedProductsAsync(int count = 10)
        {
            var products = await _productRepository.GetRecentlyAddedAsync(count);
            return products.Select(MapEntityToViewModel);
        }

        public async Task<IEnumerable<ProductViewModel>> GetRecentlyUpdatedProductsAsync(int count = 10)
        {
            var products = await _productRepository.GetRecentlyUpdatedAsync(count);
            return products.Select(MapEntityToViewModel);
        }

        private Product MapViewModelToEntity(ProductViewModel model)
        {
            return new Product
            {
                SKU = model.SKU,
                Name = model.Name,
                Description = model.Description,
                Category = model.Category,
                Cost = model.Cost,
                Price = model.Price,
                Quantity = model.Quantity,
                Location = model.Location,
                ReorderPoint = model.ReorderPoint,
                ReorderQuantity = model.ReorderQuantity,
                Supplier = model.Supplier,
                IsActive = model.IsActive
            };
        }

        private void UpdateEntityFromViewModel(Product entity, ProductViewModel model)
        {
            entity.SKU = model.SKU;
            entity.Name = model.Name;
            entity.Description = model.Description;
            entity.Category = model.Category;
            entity.Cost = model.Cost;
            entity.Price = model.Price;
            entity.Quantity = model.Quantity;
            entity.Location = model.Location;
            entity.ReorderPoint = model.ReorderPoint;
            entity.ReorderQuantity = model.ReorderQuantity;
            entity.Supplier = model.Supplier;
            entity.IsActive = model.IsActive;
        }

        private ProductViewModel MapEntityToViewModel(Product entity)
        {
            return new ProductViewModel
            {
                Id = entity.Id,
                SKU = entity.SKU,
                Name = entity.Name,
                Description = entity.Description,
                Category = entity.Category,
                Cost = entity.Cost,
                Price = entity.Price,
                Quantity = entity.Quantity,
                Location = entity.Location,
                ReorderPoint = entity.ReorderPoint,
                ReorderQuantity = entity.ReorderQuantity,
                Supplier = entity.Supplier,
                IsActive = entity.IsActive,
                CreatedAt = entity.CreatedAt,
                UpdatedAt = entity.UpdatedAt
            };
        }
    }
}