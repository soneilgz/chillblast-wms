using ChillBlastWMS_MVC.Models.Domain;
using ChillBlastWMS_MVC.Services.Repositories;
using Microsoft.Extensions.Logging;

namespace ChillBlastWMS_MVC.Services.Business
{
    public class PriceCalculationService : IPriceCalculationService
    {
        private readonly IProductRepository _productRepository;
        private readonly ILogger<PriceCalculationService> _logger;
        private const decimal DEFAULT_COST_PERCENTAGE = 0.6m; // Assume 60% cost if not specified

        public PriceCalculationService(
            IProductRepository productRepository,
            ILogger<PriceCalculationService> logger)
        {
            _productRepository = productRepository;
            _logger = logger;
        }

        public async Task<MarginCalculationResult> CalculateMarginAsync(decimal costPrice, decimal sellingPrice)
        {
            var result = new MarginCalculationResult
            {
                CostPrice = costPrice,
                SellingPrice = sellingPrice
            };

            if (costPrice > 0)
            {
                result.GrossMargin = sellingPrice - costPrice;
                result.GrossMarginPercentage = (result.GrossMargin / sellingPrice) * 100;
                result.Markup = sellingPrice - costPrice;
                result.MarkupPercentage = (result.Markup / costPrice) * 100;
                result.IsProfitable = sellingPrice > costPrice;
            }
            else
            {
                result.IsProfitable = sellingPrice > 0;
            }

            return await Task.FromResult(result);
        }

        public async Task<ProfitabilityAnalysis> AnalyzeProfitabilityAsync(int productId)
        {
            var product = await _productRepository.GetByIdAsync(productId);
            if (product == null)
            {
                throw new ArgumentException($"Product with ID {productId} not found");
            }

            var costPrice = product.Price * DEFAULT_COST_PERCENTAGE;
            var margin = await CalculateMarginAsync(costPrice, product.Price);

            return new ProfitabilityAnalysis
            {
                ProductId = product.Id,
                SKU = product.SKU,
                ProductName = product.Name,
                CostPrice = costPrice,
                SellingPrice = product.Price,
                QuantityInStock = product.Quantity,
                TotalCostValue = costPrice * product.Quantity,
                TotalSellingValue = product.Price * product.Quantity,
                PotentialProfit = (product.Price - costPrice) * product.Quantity,
                MarginPercentage = margin.GrossMarginPercentage,
                ProfitabilityStatus = GetProfitabilityStatus(margin.GrossMarginPercentage)
            };
        }

        public async Task<IEnumerable<ProfitabilityAnalysis>> AnalyzeCategoryProfitabilityAsync(string category)
        {
            var products = await _productRepository.GetByCategoryAsync(category);
            var analyses = new List<ProfitabilityAnalysis>();

            foreach (var product in products)
            {
                var analysis = await AnalyzeProfitabilityAsync(product.Id);
                analyses.Add(analysis);
            }

            return analyses;
        }

        public async Task<decimal> CalculateTotalInventoryValueAsync()
        {
            var products = await _productRepository.GetAllAsync(p => p.IsActive);
            return products.Sum(p => p.Price * p.Quantity);
        }

        public async Task<Dictionary<string, decimal>> GetInventoryValueByCategoryAsync()
        {
            var products = await _productRepository.GetAllAsync(p => p.IsActive);
            return products
                .Where(p => !string.IsNullOrWhiteSpace(p.Category))
                .GroupBy(p => p.Category!)
                .ToDictionary(
                    g => g.Key,
                    g => g.Sum(p => p.Price * p.Quantity)
                );
        }

        public async Task<(bool Success, string Message)> UpdateProductPriceAsync(int productId, decimal newPrice, string reason)
        {
            try
            {
                var product = await _productRepository.GetByIdAsync(productId);
                if (product == null)
                {
                    return (false, "Product not found");
                }

                if (newPrice < 0)
                {
                    return (false, "Price cannot be negative");
                }

                var oldPrice = product.Price;
                product.Price = newPrice;
                
                _productRepository.Update(product);
                await _productRepository.SaveChangesAsync();

                _logger.LogInformation($"Price updated for product {productId}: {oldPrice} -> {newPrice}. Reason: {reason}");
                return (true, $"Price updated successfully from {oldPrice:C} to {newPrice:C}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating price for product {productId}");
                return (false, "An error occurred while updating the price");
            }
        }

        public async Task<BulkPriceUpdateResult> BulkUpdatePricesAsync(Dictionary<int, decimal> priceUpdates, string reason)
        {
            var result = new BulkPriceUpdateResult
            {
                TotalProducts = priceUpdates.Count
            };

            try
            {
                var productIds = priceUpdates.Keys.ToList();
                var products = await _productRepository.GetAllAsync(p => productIds.Contains(p.Id));
                decimal totalValueChange = 0;

                foreach (var product in products)
                {
                    if (priceUpdates.TryGetValue(product.Id, out decimal newPrice))
                    {
                        if (newPrice < 0)
                        {
                            result.FailedUpdates++;
                            result.Errors.Add($"Product {product.SKU}: Price cannot be negative");
                            continue;
                        }

                        var oldValue = product.Price * product.Quantity;
                        product.Price = newPrice;
                        var newValue = product.Price * product.Quantity;
                        totalValueChange += (newValue - oldValue);

                        result.UpdatedProducts[product.Id] = newPrice;
                        result.SuccessfulUpdates++;
                    }
                }

                if (result.SuccessfulUpdates > 0)
                {
                    _productRepository.UpdateRange(products);
                    await _productRepository.SaveChangesAsync();
                }

                result.TotalValueChange = totalValueChange;
                _logger.LogInformation($"Bulk price update: {result.SuccessfulUpdates} products updated. Reason: {reason}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during bulk price update");
                result.Errors.Add($"System error: {ex.Message}");
            }

            return result;
        }

        public async Task<IEnumerable<PriceAlert>> GetPriceAlertsAsync()
        {
            var alerts = new List<PriceAlert>();
            var products = await _productRepository.GetAllAsync(p => p.IsActive);

            foreach (var product in products)
            {
                // Check for zero price
                if (product.Price == 0)
                {
                    alerts.Add(new PriceAlert
                    {
                        ProductId = product.Id,
                        SKU = product.SKU,
                        ProductName = product.Name,
                        AlertType = "Zero Price",
                        Message = "Product has zero price",
                        CurrentPrice = product.Price,
                        Severity = "High"
                    });
                }

                // Check for extremely low margin
                var costPrice = product.Price * DEFAULT_COST_PERCENTAGE;
                var margin = await CalculateMarginAsync(costPrice, product.Price);
                
                if (margin.GrossMarginPercentage < 10 && product.Price > 0)
                {
                    alerts.Add(new PriceAlert
                    {
                        ProductId = product.Id,
                        SKU = product.SKU,
                        ProductName = product.Name,
                        AlertType = "Low Margin",
                        Message = $"Margin is only {margin.GrossMarginPercentage:F1}%",
                        CurrentPrice = product.Price,
                        SuggestedPrice = costPrice * 1.3m, // 30% markup
                        Severity = "Medium"
                    });
                }
            }

            return alerts;
        }

        public async Task<CompetitivePriceAnalysis> AnalyzeCompetitivePricingAsync(int productId, decimal? competitorPrice = null)
        {
            var product = await _productRepository.GetByIdAsync(productId);
            if (product == null)
            {
                throw new ArgumentException($"Product with ID {productId} not found");
            }

            var analysis = new CompetitivePriceAnalysis
            {
                ProductId = product.Id,
                SKU = product.SKU,
                OurPrice = product.Price,
                CompetitorPrice = competitorPrice
            };

            if (competitorPrice.HasValue && competitorPrice.Value > 0)
            {
                analysis.PriceDifference = product.Price - competitorPrice.Value;
                analysis.PriceDifferencePercentage = (analysis.PriceDifference.Value / competitorPrice.Value) * 100;

                if (analysis.PriceDifferencePercentage > 10)
                {
                    analysis.CompetitivePosition = "Above Market";
                    analysis.Recommendation = "Consider reducing price to match competition";
                }
                else if (analysis.PriceDifferencePercentage < -10)
                {
                    analysis.CompetitivePosition = "Below Market";
                    analysis.Recommendation = "Opportunity to increase price while remaining competitive";
                }
                else
                {
                    analysis.CompetitivePosition = "Competitive";
                    analysis.Recommendation = "Price is competitive with market";
                }
            }
            else
            {
                analysis.CompetitivePosition = "No Comparison Available";
                analysis.Recommendation = "Competitor price data needed for analysis";
            }

            return analysis;
        }

        public async Task<IEnumerable<Product>> GetProductsWithNoProfitAsync()
        {
            var products = await _productRepository.GetAllAsync(p => p.IsActive);
            var noProfitProducts = new List<Product>();

            foreach (var product in products)
            {
                var costPrice = product.Price * DEFAULT_COST_PERCENTAGE;
                if (product.Price <= costPrice)
                {
                    noProfitProducts.Add(product);
                }
            }

            return noProfitProducts;
        }

        public async Task<IEnumerable<Product>> GetHighMarginProductsAsync(decimal marginThreshold = 50)
        {
            var products = await _productRepository.GetAllAsync(p => p.IsActive && p.Price > 0);
            var highMarginProducts = new List<Product>();

            foreach (var product in products)
            {
                var costPrice = product.Price * DEFAULT_COST_PERCENTAGE;
                var margin = await CalculateMarginAsync(costPrice, product.Price);
                
                if (margin.GrossMarginPercentage >= marginThreshold)
                {
                    highMarginProducts.Add(product);
                }
            }

            return highMarginProducts.OrderByDescending(p => p.Price);
        }

        public async Task<IEnumerable<Product>> GetLowMarginProductsAsync(decimal marginThreshold = 20)
        {
            var products = await _productRepository.GetAllAsync(p => p.IsActive && p.Price > 0);
            var lowMarginProducts = new List<Product>();

            foreach (var product in products)
            {
                var costPrice = product.Price * DEFAULT_COST_PERCENTAGE;
                var margin = await CalculateMarginAsync(costPrice, product.Price);
                
                if (margin.GrossMarginPercentage <= marginThreshold)
                {
                    lowMarginProducts.Add(product);
                }
            }

            return lowMarginProducts.OrderBy(p => p.Price);
        }

        private string GetProfitabilityStatus(decimal marginPercentage)
        {
            if (marginPercentage < 0) return "Loss";
            if (marginPercentage < 10) return "Very Low";
            if (marginPercentage < 20) return "Low";
            if (marginPercentage < 30) return "Moderate";
            if (marginPercentage < 50) return "Good";
            return "Excellent";
        }
    }
}