using ChillBlastWMS_MVC.Models.Domain;
using ChillBlastWMS_MVC.Models.ViewModels;

namespace ChillBlastWMS_MVC.Services.Business
{
    public interface IProductService
    {
        Task<(bool Success, string Message, Product? Product)> CreateProductAsync(ProductViewModel model);
        Task<(bool Success, string Message)> UpdateProductAsync(int id, ProductViewModel model);
        Task<(bool Success, string Message)> DeleteProductAsync(int id);
        Task<Product?> GetProductByIdAsync(int id);
        Task<Product?> GetProductBySkuAsync(string sku);
        Task<ProductViewModel?> GetProductViewModelAsync(int id);
        Task<IEnumerable<ProductViewModel>> GetAllProductsAsync(bool activeOnly = true);
        Task<(IEnumerable<ProductViewModel> Products, int TotalCount)> GetPagedProductsAsync(
            int pageNumber, 
            int pageSize, 
            string? searchTerm = null, 
            string? category = null, 
            bool? isActive = null);
        Task<IEnumerable<ProductViewModel>> SearchProductsAsync(string searchTerm, string? category = null);
        Task<IEnumerable<ProductViewModel>> GetLowStockProductsAsync(int? threshold = null);
        Task<IEnumerable<ProductViewModel>> GetOutOfStockProductsAsync();
        Task<Dictionary<string, int>> GetStockSummaryAsync();
        Task<(int TotalProducts, decimal TotalValue, int LowStockCount, int OutOfStockCount)> GetInventoryStatisticsAsync();
        Task<IEnumerable<string>> GetCategoriesAsync();
        Task<(bool Success, string Message)> AdjustStockAsync(int productId, int adjustment, string reason);
        Task<(bool Success, string Message)> UpdateStockLevelsAsync(Dictionary<int, int> stockUpdates);
        Task<ValidationResult> ValidateProductDataAsync(ProductViewModel model, bool isUpdate = false);
        Task<IEnumerable<DataAnomalyResult>> DetectAnomaliesAsync();
        Task<(bool Success, string Message)> DeactivateProductAsync(int id);
        Task<(bool Success, string Message)> ReactivateProductAsync(int id);
        Task<IEnumerable<ProductViewModel>> GetRecentlyAddedProductsAsync(int count = 10);
        Task<IEnumerable<ProductViewModel>> GetRecentlyUpdatedProductsAsync(int count = 10);
    }

    public class ValidationResult
    {
        public bool IsValid { get; set; }
        public List<string> Errors { get; set; } = new List<string>();
        public List<string> Warnings { get; set; } = new List<string>();
    }

    public class DataAnomalyResult
    {
        public int ProductId { get; set; }
        public string SKU { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public string AnomalyType { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Severity { get; set; } = "Low";
        public Dictionary<string, object> Details { get; set; } = new Dictionary<string, object>();
    }
}