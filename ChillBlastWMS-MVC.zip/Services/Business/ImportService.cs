using CsvHelper;
using CsvHelper.Configuration;
using ChillBlastWMS_MVC.Models.Domain;
using ChillBlastWMS_MVC.Models.DTOs;
using ChillBlastWMS_MVC.Models.ViewModels;
using ChillBlastWMS_MVC.Services.Repositories;
using ChillBlastWMS_MVC.Utilities;
using System.Globalization;
using System.Text;
using System.Diagnostics;

namespace ChillBlastWMS_MVC.Services.Business
{
    public class ImportService : IImportService
    {
        private readonly IProductRepository _productRepository;
        private readonly IImportLogRepository _importLogRepository;
        private readonly ILogger<ImportService> _logger;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly CsvValidator _csvValidator;
        private readonly DuplicateDetector _duplicateDetector;
        private readonly AnomalyDetector _anomalyDetector;
        private const int BATCH_SIZE = 500; // Process in batches of 500 for large datasets

        public ImportService(
            IProductRepository productRepository,
            IImportLogRepository importLogRepository,
            ILogger<ImportService> logger,
            IHttpContextAccessor httpContextAccessor)
        {
            _productRepository = productRepository;
            _importLogRepository = importLogRepository;
            _logger = logger;
            _httpContextAccessor = httpContextAccessor;
            _csvValidator = new CsvValidator();
            _duplicateDetector = new DuplicateDetector();
            _anomalyDetector = new AnomalyDetector();
        }

        public async Task<ImportResultViewModel> ProcessCsvImportAsync(IFormFile file, ImportOptions options)
        {
            var stopwatch = Stopwatch.StartNew();
            var processingReport = new ImportProcessingReport();
            var result = new ImportResultViewModel
            {
                FileName = file.FileName,
                Success = false
            };

            try
            {
                _logger.LogInformation($"Starting CSV import for file: {file.FileName} ({file.Length} bytes)");

                // Step 1: Validate file structure
                var fileValidation = await ValidateFileAsync(file);
                if (!fileValidation.IsValid)
                {
                    result.Message = "File validation failed";
                    result.Errors = fileValidation.Errors.Select((e, i) => new ImportErrorDetail 
                    { 
                        RowNumber = 0, 
                        ErrorMessage = e 
                    }).ToList();
                    return result;
                }

                // Create import log
                var importLog = new ImportLog
                {
                    FileName = file.FileName,
                    ImportDate = DateTime.UtcNow,
                    Status = "Processing",
                    ImportType = "Product",
                    ImportedBy = _httpContextAccessor.HttpContext?.User?.Identity?.Name,
                    FileSizeBytes = file.Length
                };

                await _importLogRepository.AddAsync(importLog);
                await _importLogRepository.SaveChangesAsync();

                // Step 2: Parse CSV to DTOs
                var rawProducts = await ParseCsvAsync(file);
                processingReport.TotalRecords = rawProducts.Count;
                _logger.LogInformation($"Parsed {rawProducts.Count} records from CSV");

                // Step 3: Transform and normalize data
                var transformedProducts = await TransformDataAsync(rawProducts);
                _logger.LogInformation($"Data transformation completed for {transformedProducts.Count} records");

                // Step 4: Detect duplicates
                var duplicates = await DetectDuplicatesAsync(transformedProducts);
                processingReport.DuplicateGroups = duplicates;
                
                if (duplicates.Any())
                {
                    _logger.LogWarning($"Found {duplicates.Count} duplicate groups affecting {duplicates.Sum(d => d.Count)} products");
                    processingReport.SkippedDuplicates = duplicates.Sum(d => d.Count);
                    
                    // Note: We don't remove duplicates here anymore, we handle them in business validation
                    // This ensures accurate counting throughout the process
                }

                // Step 5: Detect anomalies
                var anomalies = await DetectAnomaliesAsync(transformedProducts);
                processingReport.Anomalies = anomalies;
                
                if (anomalies.Any())
                {
                    _logger.LogWarning($"Detected {anomalies.Count} anomalies in the data");
                    
                    // Log critical anomalies
                    var criticalAnomalies = anomalies.Where(a => a.Severity == AnomalySeverity.Critical).ToList();
                    if (criticalAnomalies.Any())
                    {
                        _logger.LogError($"Found {criticalAnomalies.Count} critical anomalies");
                        foreach (var anomaly in criticalAnomalies.Take(10))
                        {
                            _logger.LogError($"Critical: {anomaly.ProductSKU} - {anomaly.Message}");
                        }
                    }
                }

                // Step 6: Validate business rules
                var businessValidation = await ValidateBusinessRulesAsync(transformedProducts, anomalies);
                processingReport.BusinessRuleViolations = businessValidation.Violations;

                // Step 7: Process import in batches
                if (!options.ValidateOnly)
                {
                    var processResult = await ProcessImportAsync(transformedProducts, options, processingReport);
                    result = processResult;
                    result.FileName = file.FileName;
                }
                else
                {
                    // Validation only mode - provide accurate counts
                    var skippedRecords = transformedProducts.Count(p => 
                        p.ValidationErrors.Any(e => e.StartsWith("SKIP:")));
                    var flaggedRecords = transformedProducts.Count(p => 
                        p.ValidationErrors.Any(e => e.StartsWith("FLAG:") || e.StartsWith("WARNING:")));
                    var validRecords = transformedProducts.Count - businessValidation.Violations.Count - skippedRecords;

                    result.Success = businessValidation.IsValid && skippedRecords == 0;
                    result.Message = result.Success 
                        ? "Validation successful" 
                        : $"Validation completed: {businessValidation.Violations.Count} critical errors, {skippedRecords} skipped, {flaggedRecords} flagged";
                    
                    result.TotalRecords = processingReport.TotalRecords; // Use original raw count
                    result.SuccessfulRecords = validRecords;
                    result.FailedRecords = businessValidation.Violations.Count;
                    result.SkippedRecords = skippedRecords;
                }

                // Step 8: Generate comprehensive report with tier analysis
                var report = await GenerateImportReportAsync(processingReport, result);
                result.Message = report.Summary;

                // Log tier-based processing summary
                var skippedCount = transformedProducts.Count(p => 
                    p.ValidationErrors.Any(e => e.StartsWith("SKIP:")));
                var flaggedCount = transformedProducts.Count(p => 
                    p.ValidationErrors.Any(e => e.StartsWith("FLAG:") || e.StartsWith("WARNING:")));
                var normalizedCount = transformedProducts.Count(p => 
                    p.ValidationErrors.Any(e => e.StartsWith("INFO:")));
                var truncatedCount = transformedProducts.Count(p => 
                    p.ValidationErrors.Any(e => e.Contains("truncated")));
                var cleanCount = transformedProducts.Count(p => 
                    !p.ValidationErrors.Any(e => e.StartsWith("SKIP:") || e.StartsWith("FLAG:") || e.StartsWith("WARNING:") || e.StartsWith("INFO:")));

                _logger.LogInformation("Import tier summary - Total: {Total}, Skipped: {Skipped}, Flagged: {Flagged}, Normalized: {Normalized}, Truncated: {Truncated}, Clean: {Clean}",
                    transformedProducts.Count, skippedCount, flaggedCount, normalizedCount, truncatedCount, cleanCount);

                // Validate our counting logic
                var totalCounted = skippedCount + flaggedCount + normalizedCount + cleanCount;
                if (totalCounted != transformedProducts.Count)
                {
                    _logger.LogWarning("Count mismatch detected - Total: {Total}, Counted: {Counted}", 
                        transformedProducts.Count, totalCounted);
                }

                // Update import log
                stopwatch.Stop();
                await _importLogRepository.CompleteImportAsync(
                    importLog.Id,
                    result.SuccessfulRecords,
                    result.FailedRecords,
                    stopwatch.Elapsed);

                result.ProcessingTime = stopwatch.Elapsed;
                _logger.LogInformation($"Import completed in {stopwatch.Elapsed.TotalSeconds:F2} seconds. Success: {result.SuccessfulRecords}, Failed: {result.FailedRecords}");
                
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error processing CSV import: {file.FileName}");
                result.Message = $"Import failed: {ex.Message}";
                result.Errors.Add(new ImportErrorDetail 
                { 
                    RowNumber = 0, 
                    ErrorMessage = ex.Message 
                });
                return result;
            }
        }

        public async Task<CsvValidationResult> ValidateFileAsync(IFormFile file)
        {
            var validationResult = new CsvValidationResult { IsValid = true };

            // TIER 1: ABORT CONDITIONS - Structural issues requiring user intervention
            
            // ❌ Wrong file format (not CSV)
            if (!file.FileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase))
            {
                validationResult.IsValid = false;
                validationResult.Errors.Add("ABORT: File must be a CSV file (.csv extension required)");
                return validationResult; // Immediate abort
            }

            // ❌ File too large (>50MB safety limit)
            if (file.Length > 50 * 1024 * 1024)
            {
                validationResult.IsValid = false;
                validationResult.Errors.Add("ABORT: File size exceeds 50MB safety limit");
                return validationResult; // Immediate abort
            }

            // ❌ Completely empty file
            if (file.Length == 0)
            {
                validationResult.IsValid = false;
                validationResult.Errors.Add("ABORT: File is completely empty");
                return validationResult; // Immediate abort
            }

            try
            {
                using var stream = file.OpenReadStream();
                var structureValidation = await _csvValidator.ValidateFileStructureAsync(stream);
                
                // Check for file corruption/encoding errors
                if (structureValidation.Errors.Any(e => e.Contains("encoding") || e.Contains("corruption") || e.Contains("malformed")))
                {
                    validationResult.IsValid = false;
                    validationResult.Errors.Add("ABORT: File corruption or encoding errors detected");
                    validationResult.Errors.AddRange(structureValidation.Errors);
                    return validationResult; // Immediate abort
                }

                // ❌ Missing required headers - this is a structural issue
                var requiredHeaders = new[] { "Sku", "Name", "ManufacturersCode", "DateCreated", "DateUpdated", 
                    "IsActive", "Summary", "Weight", "WeightUnit", "CategoryID", "Category", 
                    "ManufacturerID", "Manufacturer", "CostPrice", "SellPrice", "Qty" };
                    
                var missingHeaders = requiredHeaders.Where(h => 
                    !structureValidation.Headers.Any(header => 
                        string.Equals(header, h, StringComparison.OrdinalIgnoreCase))).ToList();

                if (missingHeaders.Any())
                {
                    validationResult.IsValid = false;
                    validationResult.Errors.Add($"ABORT: Missing required headers: {string.Join(", ", missingHeaders)}");
                    validationResult.Errors.Add("Required headers: " + string.Join(", ", requiredHeaders));
                    return validationResult; // Immediate abort
                }

                // If we reach here, file structure is valid - copy other results
                validationResult.Warnings.AddRange(structureValidation.Warnings);
                validationResult.TotalRows = structureValidation.TotalRows;
                validationResult.Headers = structureValidation.Headers;
                validationResult.Summary = "File structure validation passed - ready for import processing";
            }
            catch (Exception ex)
            {
                validationResult.IsValid = false;
                validationResult.Errors.Add($"ABORT: File validation failed - {ex.Message}");
                return validationResult; // Immediate abort
            }

            return validationResult;
        }

        public async Task<List<ProductImportDto>> ParseCsvAsync(IFormFile file)
        {
            var products = new List<ProductImportDto>();

            using var reader = new StreamReader(file.OpenReadStream());
            using var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HeaderValidated = null,
                MissingFieldFound = null,
                BadDataFound = (args) => {
                    try
                    {
                        var record = args.Context.Parser.Record;
                        _logger.LogWarning("Bad data found at row {Row}, field: {Field} - Raw record: {RawRecord}", 
                            args.Context.Parser.Row, args.Field, 
                            record != null ? string.Join(",", record) : "Unable to read record");
                    }
                    catch
                    {
                        _logger.LogWarning("Bad data found at row {Row}, field: {Field}", 
                            args.Context.Parser.Row, args.Field);
                    }
                },
                TrimOptions = TrimOptions.Trim,
                IgnoreBlankLines = true,
                PrepareHeaderForMatch = args => args.Header.ToLower(),
                Delimiter = ",",
                HasHeaderRecord = true,
                Mode = CsvMode.RFC4180, // Standard CSV parsing with proper quote handling
                Quote = '"',
                Escape = '"',
                ShouldSkipRecord = args => args.Row.Parser.Record == null || args.Row.Parser.Record.All(string.IsNullOrWhiteSpace)
            });

            try
            {
                products = await Task.Run(() => {
                    var records = new List<ProductImportDto>();
                    var recordIndex = 0;
                    
                    // Read and log headers for debugging
                    csv.Read();
                    csv.ReadHeader();
                    var headers = csv.HeaderRecord;
                    _logger.LogInformation("CSV Headers ({Count}): {Headers}", headers?.Length ?? 0, 
                        string.Join(", ", headers ?? new string[0]));
                    
                    foreach (var record in csv.GetRecords<ProductImportDto>())
                    {
                        recordIndex++;
                        try
                        {
                            // TIER 2: ROW-LEVEL VALIDATION (SKIP CONDITIONS)
                            var shouldSkip = false;
                            var rowErrors = new List<string>();

                            // Empty/null SKU (required field)
                            if (string.IsNullOrWhiteSpace(record.SKU))
                            {
                                rowErrors.Add("SKIP: Empty or null SKU (required field)");
                                shouldSkip = true;
                            }

                            // Empty/null Name (required field)
                            if (string.IsNullOrWhiteSpace(record.Name))
                            {
                                rowErrors.Add("SKIP: Empty or null Name (required field)");
                                shouldSkip = true;
                            }

                            if (shouldSkip)
                            {
                                _logger.LogWarning("Skipping row {Row} due to critical validation errors: {Errors}", 
                                    recordIndex + 1, string.Join("; ", rowErrors));
                                
                                // Create error record for reporting but don't include in processing
                                var errorRecord = new ProductImportDto();
                                errorRecord.ValidationErrors.AddRange(rowErrors);
                                records.Add(errorRecord);
                                continue;
                            }

                            // TIER 4: DATA QUALITY AUTO-FIXES (NORMALIZE)
                            // Trailing spaces → Trim automatically
                            record.SKU = record.SKU?.Trim();
                            record.Name = record.Name?.Trim();
                            record.ManufacturersCode = record.ManufacturersCode?.Trim();
                            record.Summary = record.Summary?.Trim();
                            record.WeightUnit = record.WeightUnit?.Trim();
                            record.Category = record.Category?.Trim();
                            record.Manufacturer = record.Manufacturer?.Trim();

                            // Case inconsistencies → Standardize
                            record.SKU = record.SKU?.ToUpper();
                            record.WeightUnit = record.WeightUnit?.ToUpper();

                            records.Add(record);
                        }
                        catch (Exception recordEx)
                        {
                            _logger.LogWarning(recordEx, "Failed to parse record at row {Row}: {Message}", recordIndex + 1, recordEx.Message);
                            
                            // Log the actual field values for debugging column misalignment
                            try
                            {
                                var rawRecord = csv.Context.Parser.Record;
                                if (rawRecord != null && rawRecord.Length > 0)
                                {
                                    _logger.LogWarning("Raw record values at row {Row}: {Values}", recordIndex + 1, 
                                        string.Join(" | ", rawRecord.Select((val, idx) => $"[{idx}]={val}")));
                                }
                            }
                            catch (Exception logEx)
                            {
                                _logger.LogWarning("Could not log raw record data: {LogError}", logEx.Message);
                            }
                            
                            // TIER 2: Critical data corruption in row - SKIP
                            var errorRecord = new ProductImportDto();
                            
                            // Check if this looks like a column misalignment issue
                            if (recordEx.Message.Contains("column misalignment") || 
                                recordEx.Message.Contains("CategoryID") || 
                                recordEx.Message.Contains("ManufacturerID"))
                            {
                                errorRecord.ValidationErrors.Add($"SKIP: Column misalignment detected - {recordEx.Message}");
                            }
                            else
                            {
                                errorRecord.ValidationErrors.Add($"SKIP: Critical parse error - {recordEx.Message}");
                            }
                            
                            records.Add(errorRecord);
                        }
                    }
                    
                    return records;
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error parsing CSV file");
                throw new InvalidOperationException($"Failed to parse CSV: {ex.Message}", ex);
            }

            return products;
        }

        public async Task<List<ProductImportDto>> TransformDataAsync(List<ProductImportDto> products)
        {
            return await Task.Run(() =>
            {
                var transformed = new List<ProductImportDto>();

                foreach (var product in products)
                {
                    try
                    {
                        // Normalize cost price 
                        if (!string.IsNullOrWhiteSpace(product.CostPrice.ToString()))
                        {
                            var costPriceString = product.CostPrice.ToString();
                            product.CostPrice = PriceNormalizer.NormalizePriceString(costPriceString);
                        }

                        // Normalize sell price 
                        if (!string.IsNullOrWhiteSpace(product.Price.ToString()))
                        {
                            var priceString = product.Price.ToString();
                            product.Price = PriceNormalizer.NormalizePriceString(priceString);
                        }

                        // Normalize SKU
                        if (!string.IsNullOrWhiteSpace(product.SKU))
                        {
                            product.SKU = product.SKU.Trim().ToUpper();
                        }

                        // Normalize other fields
                        product.Name = product.Name?.Trim();
                        product.Category = product.Category?.Trim();
                        product.Supplier = product.Supplier?.Trim();
                        product.Location = product.Location?.Trim();

                        // Handle null or negative values
                        if (product.Quantity < 0) product.Quantity = 0;
                        if (product.ReorderPoint < 0) product.ReorderPoint = 0;
                        if (product.ReorderQuantity < 0) product.ReorderQuantity = 0;

                        transformed.Add(product);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning($"Error transforming product {product.SKU}: {ex.Message}");
                        product.ValidationErrors.Add($"Transformation error: {ex.Message}");
                        transformed.Add(product);
                    }
                }

                return transformed;
            });
        }

        public async Task<List<DuplicateGroup>> DetectDuplicatesAsync(List<ProductImportDto> products)
        {
            return await Task.Run(() =>
            {
                var duplicates = _duplicateDetector.DetectDuplicateSKUs(products);
                
                // Also check against existing database products
                var existingSkus = _productRepository.GetAllAsync()
                    .Result
                    .Select(p => p.SKU.ToUpper())
                    .ToHashSet();

                // TIER 3: Duplicate SKUs (import first, flag others)
                var processedSkus = new HashSet<string>();
                var duplicateCount = 0;
                
                foreach (var product in products)
                {
                    var upperSku = product.SKU?.ToUpper() ?? string.Empty;
                    
                    // Skip if already marked for skipping
                    if (product.ValidationErrors.Any(e => e.StartsWith("SKIP:")))
                        continue;
                    
                    // Check if SKU exists in database
                    if (existingSkus.Contains(upperSku))
                    {
                        product.ValidationErrors.Add("FLAG: SKU already exists in database - requires update decision");
                    }
                    
                    // Check for duplicates within the import file
                    if (processedSkus.Contains(upperSku))
                    {
                        product.ValidationErrors.Add("FLAG: Duplicate SKU in import file - only first occurrence will be processed");
                        duplicateCount++;
                    }
                    else if (!string.IsNullOrWhiteSpace(upperSku))
                    {
                        processedSkus.Add(upperSku);
                    }
                }

                _logger.LogInformation("Duplicate detection: {DuplicateGroups} groups, {TotalDuplicates} total duplicates identified", 
                    duplicates.Count, duplicateCount);

                return duplicates;
            });
        }

        public async Task<List<Anomaly>> DetectAnomaliesAsync(List<ProductImportDto> products)
        {
            return await Task.Run(() =>
            {
                var anomalies = _anomalyDetector.DetectAnomalies(products);
                return anomalies;
            });
        }

        public async Task<BusinessRuleValidationResult> ValidateBusinessRulesAsync(
            List<ProductImportDto> products, 
            List<Anomaly> anomalies)
        {
            var result = new BusinessRuleValidationResult { IsValid = true };

            await Task.Run(() =>
            {
                var rowNumber = 1; // Start from 1 for header
                foreach (var product in products)
                {
                    rowNumber++;
                    
                    // Skip products that already have SKIP errors
                    if (product.ValidationErrors.Any(e => e.StartsWith("SKIP:")))
                    {
                        result.IsValid = false;
                        result.Violations.Add(new BusinessRuleViolation
                        {
                            SKU = product.SKU ?? "Unknown",
                            Rule = "Row Skipped",
                            Message = string.Join("; ", product.ValidationErrors)
                        });
                        continue;
                    }

                    // TIER 3: BUSINESS RULE VIOLATIONS (IMPORT WITH FLAGS)
                    var businessWarnings = new List<string>();

                    // Negative margins (import but require approval)
                    if (product.CostPrice > 0 && product.Price > 0 && product.CostPrice > product.Price)
                    {
                        businessWarnings.Add("FLAG: Negative margin detected - requires approval");
                        product.ValidationErrors.Add("WARNING: Cost price exceeds sell price");
                    }

                    // Extreme values (import with data quality alerts)
                    if (product.Price > 10000)
                    {
                        businessWarnings.Add("FLAG: Extremely high price - data quality alert");
                        product.ValidationErrors.Add("WARNING: Price above £10,000");
                    }

                    if (product.Weight > 1000)
                    {
                        businessWarnings.Add("FLAG: Extremely heavy product - data quality alert");
                        product.ValidationErrors.Add("WARNING: Weight above 1000kg");
                    }

                    // HTML content (sanitize and import)
                    if (!string.IsNullOrEmpty(product.Summary) && 
                        (product.Summary.Contains("<") || product.Summary.Contains(">")))
                    {
                        businessWarnings.Add("FLAG: HTML content detected - sanitized");
                        product.ValidationErrors.Add("INFO: HTML content sanitized in Summary");
                        // Note: Actual sanitization would happen in the custom converters
                    }

                    // Field length truncation warnings
                    if (!string.IsNullOrEmpty(product.Name))
                    {
                        if (product.Name.EndsWith("..."))
                        {
                            businessWarnings.Add("FLAG: Product name was truncated during import");
                            product.ValidationErrors.Add("WARNING: Product name truncated to fit database constraints");
                            _logger.LogWarning("Product name truncated for SKU {SKU}: '{Name}'", product.SKU, product.Name);
                        }
                        else if (product.Name.Length >= 252)
                        {
                            businessWarnings.Add("FLAG: Product name near length limit");
                            product.ValidationErrors.Add("WARNING: Product name is near the maximum length limit");
                        }
                    }

                    if (!string.IsNullOrEmpty(product.Summary))
                    {
                        if (product.Summary.EndsWith("..."))
                        {
                            businessWarnings.Add("FLAG: Product summary was truncated during import");
                            product.ValidationErrors.Add("WARNING: Product summary truncated to fit database constraints");
                            _logger.LogWarning("Product summary truncated for SKU {SKU}: '{Summary}'", product.SKU, product.Summary);
                        }
                        else if (product.Summary.Length >= 997)
                        {
                            businessWarnings.Add("FLAG: Product summary near length limit");
                            product.ValidationErrors.Add("WARNING: Product summary is near the maximum length limit");
                        }
                    }

                    // Check for critical anomalies
                    var criticalAnomalies = anomalies
                        .Where(a => a.ProductSKU == product.SKU && a.Severity == AnomalySeverity.Critical)
                        .ToList();

                    if (criticalAnomalies.Any())
                    {
                        result.IsValid = false;
                        result.Violations.Add(new BusinessRuleViolation
                        {
                            SKU = product.SKU ?? "Unknown",
                            Rule = "Critical Anomaly",
                            Message = string.Join("; ", criticalAnomalies.Select(a => a.Message))
                        });
                    }

                    // Basic data validation (but don't fail import for business warnings)
                    if (!product.IsValid())
                    {
                        var criticalErrors = product.ValidationErrors
                            .Where(e => !e.StartsWith("WARNING:") && !e.StartsWith("INFO:"))
                            .ToList();

                        if (criticalErrors.Any())
                        {
                            result.IsValid = false;
                            result.Violations.Add(new BusinessRuleViolation
                            {
                                SKU = product.SKU ?? "Unknown",
                                Rule = "Data Validation",
                                Message = string.Join("; ", criticalErrors)
                            });
                        }
                    }

                    // Log business warnings for review
                    if (businessWarnings.Any())
                    {
                        _logger.LogInformation("Product {SKU} imported with business flags: {Warnings}", 
                            product.SKU, string.Join("; ", businessWarnings));
                    }
                }
            });

            return result;
        }

        public async Task<ImportResultViewModel> ProcessImportAsync(
            List<ProductImportDto> products,
            ImportOptions options,
            ImportProcessingReport report)
        {
            var result = new ImportResultViewModel
            {
                TotalRecords = products.Count,
                Success = true
            };

            var successCount = 0;
            var failedCount = 0;
            var updatedCount = 0;
            var skippedCount = 0;

            // Filter out records that should be skipped before processing
            var validProducts = products.Where(p => 
                !p.ValidationErrors.Any(e => e.StartsWith("SKIP:"))).ToList();
            
            var skippedFromValidation = products.Count - validProducts.Count;
            _logger.LogInformation($"Filtered {skippedFromValidation} products marked for skipping during validation");

            // Track processed SKUs within this import to prevent duplicates
            var processedSkusInImport = new HashSet<string>();

            // Process in batches for efficiency
            var batches = validProducts
                .Select((product, index) => new { product, index })
                .GroupBy(x => x.index / BATCH_SIZE)
                .Select(g => g.Select(x => x.product).ToList())
                .ToList();

            _logger.LogInformation($"Processing {validProducts.Count} valid products in {batches.Count} batches of {BATCH_SIZE}");

            foreach (var batch in batches)
            {
                var batchProducts = new List<Product>();
                var batchUpdates = new List<Product>();

                foreach (var dto in batch)
                {
                    try
                    {
                        // TIER 2: Skip records with critical validation errors
                        if (dto.ValidationErrors.Any(e => e.StartsWith("SKIP:")))
                        {
                            skippedCount++;
                            continue;
                        }

                        // TIER 3: Handle duplicate SKUs within import
                        var upperSku = dto.SKU?.ToUpper() ?? "";
                        if (processedSkusInImport.Contains(upperSku))
                        {
                            skippedCount++;
                            result.Errors.Add(CreateErrorDetail(dto, "Duplicate SKU in import batch - skipped", "SKIP", "Medium"));
                            continue;
                        }

                        // Skip invalid products unless configured to continue
                        if (!dto.IsValid() && !options.SkipInvalidRecords)
                        {
                            failedCount++;
                            result.Errors.Add(CreateErrorDetail(dto, string.Join("; ", dto.ValidationErrors), "ERROR", "Critical"));
                            continue;
                        }

                        var existingProduct = await _productRepository.GetBySkuAsync(dto.SKU!);

                        if (existingProduct != null)
                        {
                            if (options.UpdateExisting)
                            {
                                UpdateProductFromDto(existingProduct, dto, options);
                                batchUpdates.Add(existingProduct);
                                updatedCount++;
                                processedSkusInImport.Add(upperSku);
                            }
                            else
                            {
                                skippedCount++;
                                result.Errors.Add(CreateErrorDetail(dto, "SKU already exists in database - update not enabled", "SKIP", "Low"));
                            }
                        }
                        else
                        {
                            var newProduct = CreateProductFromDto(dto, options);
                            batchProducts.Add(newProduct);
                            successCount++;
                            processedSkusInImport.Add(upperSku);
                        }
                    }
                    catch (Exception ex)
                    {
                        failedCount++;
                        result.Errors.Add(CreateErrorDetail(dto, ex.Message, "ERROR", "High"));

                        if (!options.SkipInvalidRecords)
                        {
                            result.Success = false;
                            break;
                        }
                    }
                }

                // Save batch with error handling for database constraints
                try
                {
                    if (batchProducts.Any())
                    {
                        await _productRepository.AddRangeAsync(batchProducts);
                        await _productRepository.SaveChangesAsync();
                    }

                    if (batchUpdates.Any())
                    {
                        _productRepository.UpdateRange(batchUpdates);
                        await _productRepository.SaveChangesAsync();
                    }

                    _logger.LogInformation($"Batch processed: {batchProducts.Count} new, {batchUpdates.Count} updated");
                }
                catch (Microsoft.EntityFrameworkCore.DbUpdateException dbEx)
                {
                    _logger.LogError(dbEx, "Database constraint violation in batch");
                    
                    // Handle specific constraint violations
                    if (dbEx.InnerException?.Message.Contains("duplicate key") == true)
                    {
                        // Extract SKU from error message if possible
                        var duplicateSku = ExtractSkuFromDuplicateError(dbEx.InnerException.Message);
                        
                        result.Errors.Add(new ImportErrorDetail
                        {
                            SKU = duplicateSku ?? "Unknown",
                            ErrorMessage = $"Database constraint violation: Duplicate SKU detected during save",
                            Category = "ERROR",
                            Severity = "Critical",
                            Resolution = "Check for duplicate SKUs in the import file or database"
                        });
                        
                        // Adjust counts
                        failedCount += batchProducts.Count + batchUpdates.Count;
                        successCount -= batchProducts.Count;
                        updatedCount -= batchUpdates.Count;
                        
                        _logger.LogWarning("Batch failed due to duplicate key constraint - adjusted counts");
                    }
                    else
                    {
                        // Re-throw other database exceptions
                        throw;
                    }
                }
            }

            result.SuccessfulRecords = successCount;
            result.UpdatedRecords = updatedCount;
            result.FailedRecords = failedCount;
            result.SkippedRecords = skippedCount;

            return result;
        }

        public async Task<ImportReport> GenerateImportReportAsync(
            ImportProcessingReport processingReport,
            ImportResultViewModel result)
        {
            var report = new ImportReport();

            await Task.Run(() =>
            {
                var summary = new StringBuilder();
                summary.AppendLine("Import Summary:");
                summary.AppendLine($"Total Records: {processingReport.TotalRecords}");
                summary.AppendLine($"Processed Records: {result.TotalRecords}");
                summary.AppendLine($"Successful: {result.SuccessfulRecords}");
                summary.AppendLine($"Updated: {result.UpdatedRecords}");
                summary.AppendLine($"Failed: {result.FailedRecords}");
                summary.AppendLine($"Skipped: {result.SkippedRecords}");

                // Calculate validation statistics
                var validationMath = result.SuccessfulRecords + result.UpdatedRecords + result.FailedRecords + result.SkippedRecords;
                if (validationMath != result.TotalRecords)
                {
                    summary.AppendLine($"Note: {result.TotalRecords - validationMath} records filtered during processing");
                }

                if (processingReport.DuplicateGroups.Any())
                {
                    var totalDuplicates = processingReport.SkippedDuplicates;
                    summary.AppendLine($"\nDuplicates: {processingReport.DuplicateGroups.Count} groups found");
                    summary.AppendLine($"- {totalDuplicates} duplicate records flagged for review");
                }

                if (processingReport.Anomalies.Any())
                {
                    var criticalCount = processingReport.Anomalies.Count(a => a.Severity == AnomalySeverity.Critical);
                    var highCount = processingReport.Anomalies.Count(a => a.Severity == AnomalySeverity.High);
                    var mediumCount = processingReport.Anomalies.Count(a => a.Severity == AnomalySeverity.Medium);
                    
                    summary.AppendLine($"\nAnomalies Detected:");
                    summary.AppendLine($"- Critical: {criticalCount}");
                    summary.AppendLine($"- High: {highCount}");
                    summary.AppendLine($"- Medium: {mediumCount}");
                    
                    // Show specific anomaly examples
                    var negativeMarginAnomalies = processingReport.Anomalies
                        .Where(a => a.Type == AnomalyType.NegativeMargin)
                        .Take(3)
                        .ToList();
                    if (negativeMarginAnomalies.Any())
                    {
                        summary.AppendLine($"- {negativeMarginAnomalies.Count} negative margin products flagged: {string.Join(", ", negativeMarginAnomalies.Select(a => a.ProductSKU))}");
                    }
                }

                summary.AppendLine($"\nProcessing Time: {result.ProcessingTime.TotalSeconds:F2} seconds");

                report.Summary = summary.ToString();
                report.Details = processingReport;
            });

            return report;
        }

        public async Task<(bool IsValid, List<string> Errors)> ValidateCsvFileAsync(IFormFile file)
        {
            var errors = new List<string>();

            if (file == null || file.Length == 0)
            {
                errors.Add("File is empty or not provided");
                return (false, errors);
            }

            if (!file.FileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase))
            {
                errors.Add("File must be a CSV file");
                return (false, errors);
            }

            if (file.Length > 10 * 1024 * 1024) // 10MB limit
            {
                errors.Add("File size exceeds 10MB limit");
                return (false, errors);
            }

            return await Task.FromResult((errors.Count == 0, errors));
        }

        public async Task<List<ProductImportDto>> ParseCsvFileAsync(IFormFile file)
        {
            var products = new List<ProductImportDto>();

            using var reader = new StreamReader(file.OpenReadStream());
            using var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HeaderValidated = null,
                MissingFieldFound = null,
                BadDataFound = null
            });

            try
            {
                products = await Task.Run(() => csv.GetRecords<ProductImportDto>().ToList());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error parsing CSV file");
                throw new InvalidOperationException("Failed to parse CSV file. Please check the file format.", ex);
            }

            return products;
        }

        public async Task<ImportResultViewModel> ImportProductsAsync(List<ProductImportDto> products, ImportOptions options)
        {
            var result = new ImportResultViewModel
            {
                TotalRecords = products.Count,
                Success = true
            };

            var successCount = 0;
            var failedCount = 0;
            var updatedCount = 0;
            var skippedCount = 0;
            var errors = new List<ImportErrorDetail>();

            for (int i = 0; i < products.Count; i++)
            {
                var dto = products[i];
                var rowNumber = i + 2; // Account for header row

                try
                {
                    // Validate DTO
                    if (!dto.IsValid())
                    {
                        if (options.SkipInvalidRecords)
                        {
                            skippedCount++;
                            errors.Add(new ImportErrorDetail
                            {
                                RowNumber = rowNumber,
                                SKU = dto.SKU ?? "Unknown",
                                ErrorMessage = string.Join("; ", dto.ValidationErrors)
                            });
                            continue;
                        }
                        else
                        {
                            failedCount++;
                            result.Success = false;
                            errors.Add(new ImportErrorDetail
                            {
                                RowNumber = rowNumber,
                                SKU = dto.SKU ?? "Unknown",
                                ErrorMessage = string.Join("; ", dto.ValidationErrors)
                            });
                            continue;
                        }
                    }

                    // Check if product exists
                    var existingProduct = await _productRepository.GetBySkuAsync(dto.SKU!);

                    if (existingProduct != null)
                    {
                        if (options.UpdateExisting)
                        {
                            // Update existing product
                            UpdateProductFromDto(existingProduct, dto, options);
                            _productRepository.Update(existingProduct);
                            updatedCount++;
                            successCount++;
                        }
                        else
                        {
                            skippedCount++;
                            errors.Add(new ImportErrorDetail
                            {
                                RowNumber = rowNumber,
                                SKU = dto.SKU!,
                                ErrorMessage = "Product already exists (update not allowed)"
                            });
                        }
                    }
                    else
                    {
                        // Create new product
                        var newProduct = CreateProductFromDto(dto, options);
                        await _productRepository.AddAsync(newProduct);
                        successCount++;
                    }
                }
                catch (Exception ex)
                {
                    failedCount++;
                    errors.Add(new ImportErrorDetail
                    {
                        RowNumber = rowNumber,
                        SKU = dto.SKU ?? "Unknown",
                        ErrorMessage = ex.Message
                    });

                    if (!options.SkipInvalidRecords)
                    {
                        result.Success = false;
                        break;
                    }
                }
            }

            // Save all changes
            if (successCount > 0 || updatedCount > 0)
            {
                await _productRepository.SaveChangesAsync();
            }

            result.SuccessfulRecords = successCount;
            result.FailedRecords = failedCount;
            result.UpdatedRecords = updatedCount;
            result.SkippedRecords = skippedCount;
            result.Errors = errors;
            result.Message = GenerateImportMessage(successCount, updatedCount, failedCount, skippedCount);

            return result;
        }

        public async Task<byte[]> GenerateImportTemplateAsync()
        {
            var csvContent = new StringBuilder();
            csvContent.AppendLine("Sku,Name,ManufacturersCode,DateCreated,DateUpdated,IsActive,Summary,Weight,WeightUnit,CategoryID,Category,ManufacturerID,Manufacturer,CostPrice,SellPrice,Qty");
            csvContent.AppendLine("SAMPLE001,Sample Product,MFG001,2024-01-01,2024-01-01,1,Sample product description,1.5,kg,1,Electronics,1,Sample Manufacturer,25.00,49.99,100");

            return await Task.FromResult(Encoding.UTF8.GetBytes(csvContent.ToString()));
        }

        public async Task<byte[]> GenerateErrorReportAsync(List<ImportErrorDetail> errors)
        {
            var csvContent = new StringBuilder();
            csvContent.AppendLine("Row Number,SKU,Error Message");

            foreach (var error in errors)
            {
                csvContent.AppendLine($"{error.RowNumber},{error.SKU},\"{error.ErrorMessage}\"");
            }

            return await Task.FromResult(Encoding.UTF8.GetBytes(csvContent.ToString()));
        }

        public async Task<IEnumerable<ImportHistoryViewModel>> GetImportHistoryAsync(int? limit = null)
        {
            var imports = limit.HasValue 
                ? await _importLogRepository.GetRecentImportsAsync(limit.Value)
                : await _importLogRepository.GetAllAsync();

            return imports.Select(MapImportLogToViewModel);
        }

        public async Task<ImportHistoryViewModel?> GetImportDetailsAsync(int importId)
        {
            var import = await _importLogRepository.GetByIdAsync(importId);
            return import != null ? MapImportLogToViewModel(import) : null;
        }

        public async Task<byte[]> ExportProductsToCsvAsync(ExportOptions options)
        {
            var query = _productRepository.GetQueryable();

            if (options.ActiveOnly)
                query = query.Where(p => p.IsActive);

            if (!string.IsNullOrWhiteSpace(options.Category))
                query = query.Where(p => p.Category == options.Category);

            if (!string.IsNullOrWhiteSpace(options.Supplier))
                query = query.Where(p => p.Supplier == options.Supplier);

            var products = query.ToList();

            using var memoryStream = new MemoryStream();
            using var writer = new StreamWriter(memoryStream, Encoding.UTF8);
            using var csv = new CsvWriter(writer, CultureInfo.InvariantCulture);

            if (options.SelectedFields?.Any() == true)
            {
                // Write custom headers
                csv.WriteField("SKU");
                if (options.SelectedFields.Contains("Name")) csv.WriteField("Name");
                if (options.SelectedFields.Contains("Description")) csv.WriteField("Description");
                if (options.SelectedFields.Contains("Category")) csv.WriteField("Category");
                if (options.IncludePricing && options.SelectedFields.Contains("Price")) csv.WriteField("Price");
                if (options.IncludeStockInfo && options.SelectedFields.Contains("Quantity")) csv.WriteField("Quantity");
                if (options.SelectedFields.Contains("Location")) csv.WriteField("Location");
                if (options.IncludeStockInfo && options.SelectedFields.Contains("ReorderPoint")) csv.WriteField("ReorderPoint");
                if (options.IncludeStockInfo && options.SelectedFields.Contains("ReorderQuantity")) csv.WriteField("ReorderQuantity");
                if (options.SelectedFields.Contains("Supplier")) csv.WriteField("Supplier");
                csv.NextRecord();

                // Write data
                foreach (var product in products)
                {
                    csv.WriteField(product.SKU);
                    if (options.SelectedFields.Contains("Name")) csv.WriteField(product.Name);
                    if (options.SelectedFields.Contains("Description")) csv.WriteField(product.Description);
                    if (options.SelectedFields.Contains("Category")) csv.WriteField(product.Category);
                    if (options.IncludePricing && options.SelectedFields.Contains("Price")) csv.WriteField(product.Price);
                    if (options.IncludeStockInfo && options.SelectedFields.Contains("Quantity")) csv.WriteField(product.Quantity);
                    if (options.SelectedFields.Contains("Location")) csv.WriteField(product.Location);
                    if (options.IncludeStockInfo && options.SelectedFields.Contains("ReorderPoint")) csv.WriteField(product.ReorderPoint);
                    if (options.IncludeStockInfo && options.SelectedFields.Contains("ReorderQuantity")) csv.WriteField(product.ReorderQuantity);
                    if (options.SelectedFields.Contains("Supplier")) csv.WriteField(product.Supplier);
                    csv.NextRecord();
                }
            }
            else
            {
                // Export all fields
                var exportDtos = products.Select(p => new ProductImportDto
                {
                    SKU = p.SKU,
                    Name = p.Name,
                    Description = p.Description,
                    Category = p.Category,
                    Price = options.IncludePricing ? p.Price : 0,
                    Quantity = options.IncludeStockInfo ? p.Quantity : 0,
                    Location = p.Location,
                    ReorderPoint = options.IncludeStockInfo ? p.ReorderPoint : 0,
                    ReorderQuantity = options.IncludeStockInfo ? p.ReorderQuantity : 0,
                    Supplier = p.Supplier
                });

                await csv.WriteRecordsAsync(exportDtos);
            }

            await writer.FlushAsync();
            return memoryStream.ToArray();
        }

        public async Task<ImportValidationResult> ValidateImportDataAsync(List<ProductImportDto> products)
        {
            var result = new ImportValidationResult
            {
                TotalRecords = products.Count,
                IsValid = true
            };

            var validCount = 0;
            var invalidCount = 0;

            for (int i = 0; i < products.Count; i++)
            {
                var product = products[i];
                var rowNumber = i + 2;

                if (!product.IsValid())
                {
                    invalidCount++;
                    result.IsValid = false;

                    foreach (var error in product.ValidationErrors)
                    {
                        result.Errors.Add(new ImportValidationError
                        {
                            RowNumber = rowNumber,
                            FieldName = GetFieldNameFromError(error),
                            Value = GetFieldValue(product, error),
                            ErrorMessage = error
                        });
                    }
                }
                else
                {
                    validCount++;

                    // Check for warnings
                    if (product.Price == 0)
                    {
                        result.Warnings.Add(new ImportValidationWarning
                        {
                            RowNumber = rowNumber,
                            WarningMessage = "Product has zero price"
                        });
                    }

                    // Check for duplicate SKUs
                    if (await _productRepository.SkuExistsAsync(product.SKU!))
                    {
                        result.Warnings.Add(new ImportValidationWarning
                        {
                            RowNumber = rowNumber,
                            WarningMessage = $"SKU '{product.SKU}' already exists in the database"
                        });
                    }
                }
            }

            result.ValidRecords = validCount;
            result.InvalidRecords = invalidCount;

            return result;
        }

        public async Task<(bool Success, string Message)> RollbackImportAsync(int importId)
        {
            try
            {
                var importLog = await _importLogRepository.GetByIdAsync(importId);
                if (importLog == null)
                {
                    return (false, "Import log not found");
                }

                // This would require tracking which products were added/modified during the import
                // For now, return a not implemented message
                return (false, "Rollback functionality not yet implemented");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error rolling back import ID={importId}");
                return (false, "An error occurred during rollback");
            }
        }

        private Product CreateProductFromDto(ProductImportDto dto, ImportOptions options)
        {
            return new Product
            {
                SKU = dto.SKU!,
                Name = dto.Name!,
                Description = dto.Description,
                Category = dto.Category ?? options.DefaultCategory,
                Cost = dto.CostPrice,
                Price = dto.Price,
                Quantity = dto.Quantity,
                Location = dto.Location,
                ReorderPoint = dto.ReorderPoint ?? 0,
                ReorderQuantity = dto.ReorderQuantity ?? 0,
                Supplier = dto.Supplier ?? options.DefaultSupplier,
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            };
        }

        private void UpdateProductFromDto(Product product, ProductImportDto dto, ImportOptions options)
        {
            product.Name = dto.Name!;
            product.Description = dto.Description ?? product.Description;
            product.Category = dto.Category ?? product.Category ?? options.DefaultCategory;
            product.Cost = dto.CostPrice;
            product.Price = dto.Price;
            product.Quantity = dto.Quantity;
            product.Location = dto.Location ?? product.Location;
            product.ReorderPoint = dto.ReorderPoint ?? product.ReorderPoint;
            product.ReorderQuantity = dto.ReorderQuantity ?? product.ReorderQuantity;
            product.Supplier = dto.Supplier ?? product.Supplier ?? options.DefaultSupplier;
        }

        private ImportHistoryViewModel MapImportLogToViewModel(ImportLog log)
        {
            return new ImportHistoryViewModel
            {
                Id = log.Id,
                FileName = log.FileName,
                ImportDate = log.ImportDate,
                Status = log.Status,
                TotalRecords = log.TotalRecords,
                SuccessfulRecords = log.SuccessfulRecords,
                FailedRecords = log.FailedRecords,
                ImportedBy = log.ImportedBy,
                ProcessingTime = log.ProcessingTime,
                FileSizeBytes = log.FileSizeBytes
            };
        }

        private string GenerateImportMessage(int success, int updated, int failed, int skipped)
        {
            var parts = new List<string>();

            if (success > 0)
                parts.Add($"{success} products imported");
            if (updated > 0)
                parts.Add($"{updated} products updated");
            if (failed > 0)
                parts.Add($"{failed} failed");
            if (skipped > 0)
                parts.Add($"{skipped} skipped");

            return parts.Any() 
                ? string.Join(", ", parts) 
                : "No products were processed";
        }

        private string GetFieldNameFromError(string error)
        {
            if (error.Contains("SKU")) return "SKU";
            if (error.Contains("Name")) return "Name";
            if (error.Contains("Price")) return "Price";
            if (error.Contains("Quantity")) return "Quantity";
            return "Unknown";
        }

        private string GetFieldValue(ProductImportDto product, string error)
        {
            if (error.Contains("SKU")) return product.SKU ?? "";
            if (error.Contains("Name")) return product.Name ?? "";
            if (error.Contains("Price")) return product.Price.ToString();
            if (error.Contains("Quantity")) return product.Quantity.ToString();
            return "";
        }

        private string? ExtractSkuFromDuplicateError(string errorMessage)
        {
            try
            {
                // Extract SKU from error message like: "The duplicate key value is (NOT1161)."
                var match = System.Text.RegularExpressions.Regex.Match(errorMessage, @"The duplicate key value is \(([^)]+)\)");
                if (match.Success)
                {
                    return match.Groups[1].Value;
                }
            }
            catch
            {
                // Ignore regex errors
            }
            return null;
        }

        private ImportErrorDetail CreateErrorDetail(ProductImportDto dto, string errorMessage, string category, string severity)
        {
            var resolution = GetResolutionSuggestion(category, errorMessage);
            
            return new ImportErrorDetail
            {
                SKU = dto.SKU ?? "Unknown",
                ProductName = dto.Name ?? "Unknown",
                ErrorMessage = errorMessage,
                Category = category,
                Severity = severity,
                Resolution = resolution,
                Field = ExtractFieldFromError(errorMessage),
                Value = ExtractValueFromDto(dto, ExtractFieldFromError(errorMessage))
            };
        }

        private string GetResolutionSuggestion(string category, string errorMessage)
        {
            return category.ToUpper() switch
            {
                "SKIP" when errorMessage.Contains("duplicate") => "Remove duplicate rows from the CSV file",
                "SKIP" when errorMessage.Contains("exists") => "Enable 'Update Existing' option or remove existing SKUs",
                "SKIP" when errorMessage.Contains("required") => "Provide missing required field values",
                "FLAG" when errorMessage.Contains("margin") => "Review pricing strategy for this product",
                "FLAG" when errorMessage.Contains("extreme") => "Verify data accuracy for unusual values",
                "ERROR" when errorMessage.Contains("format") => "Check data format and fix invalid values", 
                "ERROR" when errorMessage.Contains("constraint") => "Check for duplicate SKUs in file and database",
                _ => "Review and correct the data issue"
            };
        }

        private string ExtractFieldFromError(string errorMessage)
        {
            if (errorMessage.Contains("SKU") || errorMessage.Contains("Sku")) return "SKU";
            if (errorMessage.Contains("Name")) return "Name";
            if (errorMessage.Contains("Price")) return "Price";
            if (errorMessage.Contains("Quantity") || errorMessage.Contains("Qty")) return "Quantity";
            if (errorMessage.Contains("Category")) return "Category";
            if (errorMessage.Contains("Manufacturer")) return "Manufacturer";
            if (errorMessage.Contains("Weight")) return "Weight";
            if (errorMessage.Contains("Date")) return "Date";
            return "";
        }

        private string ExtractValueFromDto(ProductImportDto dto, string field)
        {
            return field switch
            {
                "SKU" => dto.SKU ?? "",
                "Name" => dto.Name ?? "",
                "Price" => dto.Price.ToString(),
                "Quantity" => dto.Quantity.ToString(),
                "Category" => dto.Category ?? "",
                "Manufacturer" => dto.Manufacturer ?? "",
                "Weight" => dto.Weight.ToString(),
                _ => ""
            };
        }
    }
}