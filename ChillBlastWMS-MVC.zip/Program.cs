using ChillBlastWMS_MVC.Data;
using ChillBlastWMS_MVC.Services.Repositories;
using ChillBlastWMS_MVC.Services.Business;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.DataProtection;
using System.Globalization;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Determine which connection string to use based on environment
var useDockerConnection = builder.Configuration.GetValue<bool>("Database:UseDockerConnection") || 
                         Environment.GetEnvironmentVariable("DOTNET_RUNNING_IN_CONTAINER") == "true" ||
                         Environment.GetEnvironmentVariable("USE_DOCKER_DB") == "true";

var connectionString = useDockerConnection 
    ? builder.Configuration.GetConnectionString("DockerConnection") 
    : builder.Configuration.GetConnectionString("DefaultConnection");

if (string.IsNullOrEmpty(connectionString))
{
    throw new InvalidOperationException("No valid connection string found.");
}

// Log which connection is being used
var logger = LoggerFactory.Create(config => config.AddConsole()).CreateLogger("Startup");
logger.LogInformation("Using {ConnectionType} database connection", 
    useDockerConnection ? "Docker" : "LocalDB");

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

builder.Services.AddDefaultIdentity<IdentityUser>(options => 
    {
        // For development, disable email confirmation for easier testing
        options.SignIn.RequireConfirmedAccount = !builder.Environment.IsDevelopment();
        
        // Password requirements
        options.Password.RequiredLength = 6;
        options.Password.RequireNonAlphanumeric = true;
        options.Password.RequireDigit = true;
        options.Password.RequireUppercase = true;
        options.Password.RequireLowercase = true;
    })
    .AddRoles<IdentityRole>()
    .AddEntityFrameworkStores<ApplicationDbContext>();
builder.Services.AddControllersWithViews();

// Configure localization for UK culture (GBP currency)
builder.Services.Configure<RequestLocalizationOptions>(options =>
{
    var ukCulture = new CultureInfo("en-GB");
    ukCulture.NumberFormat.CurrencySymbol = "£";
    ukCulture.NumberFormat.CurrencyDecimalSeparator = ".";
    ukCulture.NumberFormat.CurrencyGroupSeparator = ",";
    ukCulture.NumberFormat.CurrencyPositivePattern = 0; // £1.23
    ukCulture.NumberFormat.CurrencyNegativePattern = 1; // -£1.23
    
    options.DefaultRequestCulture = new Microsoft.AspNetCore.Localization.RequestCulture(ukCulture, ukCulture);
    options.SupportedCultures = new[] { ukCulture };
    options.SupportedUICultures = new[] { ukCulture };
});

// Add IHttpContextAccessor for audit trail functionality
builder.Services.AddHttpContextAccessor();

// Configure Data Protection for Docker environments
if (Environment.GetEnvironmentVariable("DOTNET_RUNNING_IN_CONTAINER") == "true")
{
    builder.Services.AddDataProtection()
        .PersistKeysToFileSystem(new DirectoryInfo("/app/keys"))
        .SetApplicationName("ChillBlastWMS");
}

// Register Repository Layer - Scoped lifetime for EF Core compatibility
builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
builder.Services.AddScoped<IProductRepository, ProductRepository>();
builder.Services.AddScoped<IImportLogRepository, ImportLogRepository>();

// Register Business Service Layer - Scoped lifetime to match repositories
builder.Services.AddScoped<IProductService, ProductService>();
builder.Services.AddScoped<IImportService, ImportService>();
builder.Services.AddScoped<IPriceCalculationService, PriceCalculationService>();

// Add logging services (already included by default, but can be configured here)
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();
if (builder.Environment.IsDevelopment())
{
    builder.Logging.AddFilter("Microsoft.EntityFrameworkCore.Database.Command", LogLevel.Information);
}

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseMigrationsEndPoint();
}
else
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

// Use localization middleware
app.UseRequestLocalization();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
app.MapRazorPages();

// Seed the database in background for Docker environments
var isContainer = Environment.GetEnvironmentVariable("DOTNET_RUNNING_IN_CONTAINER") == "true";
var appLogger = app.Services.GetRequiredService<ILogger<Program>>();

if (isContainer)
{
    // Start seeding in background to not block application startup
    _ = Task.Run(async () =>
    {
        try
        {
            appLogger.LogInformation("Starting database seeding in background");
            await DatabaseSeeder.SeedAsync(app.Services, app.Configuration);
        }
        catch (Exception ex)
        {
            appLogger.LogError(ex, "Background database seeding failed");
        }
    });
}
else
{
    // For local development, seed synchronously
    try
    {
        await DatabaseSeeder.SeedAsync(app.Services, app.Configuration);
    }
    catch (Exception ex)
    {
        appLogger.LogError(ex, "Database seeding failed during startup");
        // Continue with app startup even if seeding fails locally
    }
}

app.Run();
