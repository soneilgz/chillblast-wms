﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ChillBlastWMS_MVC.Models.Domain;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace ChillBlastWMS_MVC.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        private readonly IHttpContextAccessor? _httpContextAccessor;

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options, IHttpContextAccessor httpContextAccessor)
            : base(options)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<ImportLog> ImportLogs { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Product entity configuration
            builder.Entity<Product>(entity =>
            {
                entity.ToTable("Products");
                
                entity.HasKey(e => e.Id);
                
                entity.Property(e => e.SKU)
                    .IsRequired()
                    .HasMaxLength(50);
                
                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(255);
                
                entity.Property(e => e.Description)
                    .HasMaxLength(1000);
                
                entity.Property(e => e.Category)
                    .HasMaxLength(100);
                
                entity.Property(e => e.Price)
                    .HasColumnType("decimal(18,2)")
                    .IsRequired();
                
                entity.Property(e => e.Location)
                    .HasMaxLength(50);
                
                entity.Property(e => e.Supplier)
                    .HasMaxLength(100);
                
                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(450);
                
                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(450);

                // Indexes for performance
                entity.HasIndex(e => e.SKU)
                    .IsUnique()
                    .HasDatabaseName("IX_Products_SKU");
                
                entity.HasIndex(e => e.Category)
                    .HasDatabaseName("IX_Products_Category");
                
                entity.HasIndex(e => e.IsActive)
                    .HasDatabaseName("IX_Products_IsActive");
                
                entity.HasIndex(e => new { e.IsActive, e.Category })
                    .HasDatabaseName("IX_Products_IsActive_Category");
                
                entity.HasIndex(e => e.Quantity)
                    .HasDatabaseName("IX_Products_Quantity");
                
                entity.HasIndex(e => e.CreatedAt)
                    .HasDatabaseName("IX_Products_CreatedAt");
            });

            // ImportLog entity configuration
            builder.Entity<ImportLog>(entity =>
            {
                entity.ToTable("ImportLogs");
                
                entity.HasKey(e => e.Id);
                
                entity.Property(e => e.FileName)
                    .IsRequired()
                    .HasMaxLength(255);
                
                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(50);
                
                entity.Property(e => e.ImportType)
                    .IsRequired()
                    .HasMaxLength(50);
                
                entity.Property(e => e.ImportedBy)
                    .HasMaxLength(450);
                
                entity.Property(e => e.ErrorDetails)
                    .HasColumnType("nvarchar(max)");

                // Indexes for ImportLog
                entity.HasIndex(e => e.ImportDate)
                    .HasDatabaseName("IX_ImportLogs_ImportDate");
                
                entity.HasIndex(e => e.Status)
                    .HasDatabaseName("IX_ImportLogs_Status");
                
                entity.HasIndex(e => e.ImportType)
                    .HasDatabaseName("IX_ImportLogs_ImportType");
            });
        }

        public override int SaveChanges()
        {
            UpdateAuditFields();
            return base.SaveChanges();
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            UpdateAuditFields();
            return await base.SaveChangesAsync(cancellationToken);
        }

        private void UpdateAuditFields()
        {
            var entries = ChangeTracker.Entries()
                .Where(e => e.Entity is Product && 
                           (e.State == EntityState.Added || e.State == EntityState.Modified));

            var currentUsername = _httpContextAccessor?.HttpContext?.User?.Identity?.Name ?? "System";
            var currentTime = DateTime.UtcNow;

            foreach (var entry in entries)
            {
                var entity = (Product)entry.Entity;

                if (entry.State == EntityState.Added)
                {
                    entity.CreatedAt = currentTime;
                    entity.CreatedBy = currentUsername;
                }

                if (entry.State == EntityState.Modified)
                {
                    entity.UpdatedAt = currentTime;
                    entity.UpdatedBy = currentUsername;
                    
                    // Prevent modification of creation audit fields
                    entry.Property(nameof(Product.CreatedAt)).IsModified = false;
                    entry.Property(nameof(Product.CreatedBy)).IsModified = false;
                }
            }
        }
    }
}
