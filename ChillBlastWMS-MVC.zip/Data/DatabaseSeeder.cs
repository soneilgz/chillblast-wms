using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;

namespace ChillBlastWMS_MVC.Data
{
    public static class DatabaseSeeder
    {
        private const int MaxRetryAttempts = 10;
        private const int DelayBetweenRetriesMs = 5000; // 5 seconds

        public static async Task SeedAsync(IServiceProvider serviceProvider, IConfiguration configuration)
        {
            using var scope = serviceProvider.CreateScope();
            var services = scope.ServiceProvider;
            var logger = services.GetRequiredService<ILogger<Program>>();
            
            try
            {
                var context = services.GetRequiredService<ApplicationDbContext>();
                var userManager = services.GetRequiredService<UserManager<IdentityUser>>();
                var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();

                // Wait for database to be ready with retry logic
                await WaitForDatabaseAsync(context, logger);

                // Ensure database is created
                await context.Database.EnsureCreatedAsync();

                // Seed roles
                await SeedRolesAsync(roleManager, logger);

                // Seed default admin user
                await SeedDefaultUserAsync(userManager, configuration, logger);

                logger.LogInformation("Database seeding completed successfully");
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "An error occurred while seeding the database");
                // Don't throw in production to prevent app crash
                if (Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") != "Production")
                {
                    throw;
                }
                logger.LogWarning("Database seeding failed, but continuing with application startup");
            }
        }

        private static async Task WaitForDatabaseAsync(ApplicationDbContext context, ILogger logger)
        {
            var attempt = 0;
            while (attempt < MaxRetryAttempts)
            {
                try
                {
                    logger.LogInformation("Attempting to connect to SQL Server (attempt {Attempt}/{MaxAttempts})", 
                        attempt + 1, MaxRetryAttempts);
                    
                    // First, test connection to master database to ensure SQL Server is ready
                    var connectionString = context.Database.GetConnectionString();
                    var masterConnectionString = connectionString?.Replace("Database=ChillBlastWMS", "Database=master");
                    
                    using var masterConnection = new SqlConnection(masterConnectionString);
                    await masterConnection.OpenAsync();
                    await masterConnection.CloseAsync();
                    
                    logger.LogInformation("Successfully connected to SQL Server");
                    return;
                }
                catch (SqlException ex) when (IsTransientError(ex) || ex.Number == 4060) // Include "database does not exist" as transient
                {
                    attempt++;
                    logger.LogWarning("SQL Server connection failed (attempt {Attempt}/{MaxAttempts}): {Error}", 
                        attempt, MaxRetryAttempts, ex.Message);
                    
                    if (attempt >= MaxRetryAttempts)
                    {
                        logger.LogError("Failed to connect to SQL Server after {MaxAttempts} attempts", MaxRetryAttempts);
                        throw;
                    }
                    
                    logger.LogInformation("Waiting {Delay}ms before retry...", DelayBetweenRetriesMs);
                    await Task.Delay(DelayBetweenRetriesMs);
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, "Non-transient error occurred while connecting to SQL Server");
                    throw;
                }
            }
        }

        private static bool IsTransientError(SqlException ex)
        {
            // Common transient SQL Server error codes
            var transientErrorCodes = new[]
            {
                2,      // Timeout
                20,     // Instance failure
                64,     // Connection failed
                233,    // Connection was not properly initialized
                4060,   // Database does not exist (transient during startup)
                10053,  // Provider: TCP Provider, error: 0 - An existing connection was forcibly closed
                10054,  // Provider: TCP Provider, error: 0 - An existing connection was forcibly closed
                10060,  // Network or instance-specific error
                40143,  // Connection was terminated
                40197,  // Service has encountered an error processing your request
                40501,  // Service is currently busy
                40613,  // Database is currently unavailable
            };
            
            return transientErrorCodes.Contains(ex.Number);
        }

        private static async Task SeedRolesAsync(RoleManager<IdentityRole> roleManager, ILogger logger)
        {
            var roles = new[] { "Admin", "Manager", "User" };

            foreach (var role in roles)
            {
                if (!await roleManager.RoleExistsAsync(role))
                {
                    var result = await roleManager.CreateAsync(new IdentityRole(role));
                    if (result.Succeeded)
                    {
                        logger.LogInformation("Created role: {Role}", role);
                    }
                    else
                    {
                        logger.LogWarning("Failed to create role {Role}: {Errors}", 
                            role, string.Join(", ", result.Errors.Select(e => e.Description)));
                    }
                }
            }
        }

        private static async Task SeedDefaultUserAsync(UserManager<IdentityUser> userManager, IConfiguration configuration, ILogger logger)
        {
            // Get default admin credentials from configuration
            var adminEmail = configuration["DefaultAdmin:Email"] ?? "admin@chillblastwms.com";
            var adminPassword = configuration["DefaultAdmin:Password"] ?? "Admin123!";

            // Check if admin user already exists
            var existingUser = await userManager.FindByEmailAsync(adminEmail);
            if (existingUser != null)
            {
                logger.LogInformation("Default admin user already exists: {Email}", adminEmail);
                return;
            }

            // Create the admin user
            var adminUser = new IdentityUser
            {
                UserName = adminEmail,
                Email = adminEmail,
                EmailConfirmed = true // Skip email confirmation for default admin
            };

            var result = await userManager.CreateAsync(adminUser, adminPassword);
            if (result.Succeeded)
            {
                // Add user to Admin role
                await userManager.AddToRoleAsync(adminUser, "Admin");
                
                logger.LogInformation("Default admin user created successfully: {Email}", adminEmail);
                logger.LogInformation("Default admin password: {Password}", adminPassword);
            }
            else
            {
                logger.LogError("Failed to create default admin user: {Errors}", 
                    string.Join(", ", result.Errors.Select(e => e.Description)));
                throw new InvalidOperationException($"Failed to create default admin user: {string.Join(", ", result.Errors.Select(e => e.Description))}");
            }
        }
    }
}