using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;
using ChillBlastWMS_MVC.Controllers;
using ChillBlastWMS_MVC.Models.ViewModels;
using ChillBlastWMS_MVC.Models.Domain;
using ChillBlastWMS_MVC.Services.Business;
using Microsoft.AspNetCore.Mvc.ViewFeatures;

namespace ChillBlastWMS_MVC.Tests.Controllers
{
    public class ProductsControllerTests
    {
        private readonly Mock<IProductService> _mockProductService;
        private readonly Mock<IImportService> _mockImportService;
        private readonly Mock<IPriceCalculationService> _mockPriceCalculationService;
        private readonly Mock<ILogger<ProductsController>> _mockLogger;
        private readonly ProductsController _controller;

        public ProductsControllerTests()
        {
            _mockProductService = new Mock<IProductService>();
            _mockImportService = new Mock<IImportService>();
            _mockPriceCalculationService = new Mock<IPriceCalculationService>();
            _mockLogger = new Mock<ILogger<ProductsController>>();

            _controller = new ProductsController(
                _mockProductService.Object,
                _mockImportService.Object,
                _mockPriceCalculationService.Object,
                _mockLogger.Object
            );

            // Setup TempData for controller
            var tempData = new TempDataDictionary(new DefaultHttpContext(), Mock.Of<ITempDataProvider>());
            _controller.TempData = tempData;
        }

        [Fact]
        public async Task Index_ReturnsViewWithProducts()
        {
            // Arrange
            var products = new List<ProductViewModel>
            {
                new ProductViewModel { Id = 1, SKU = "PROD-001", Name = "Product 1", Price = 99.99m },
                new ProductViewModel { Id = 2, SKU = "PROD-002", Name = "Product 2", Price = 149.99m }
            };

            var categories = new List<string> { "Electronics", "Computers" };

            _mockProductService.Setup(s => s.GetAllProductsAsync(true))
                .ReturnsAsync(products);
            _mockProductService.Setup(s => s.GetCategoriesAsync())
                .ReturnsAsync(categories);

            // Act
            var result = await _controller.Index(null, null);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<IEnumerable<ProductViewModel>>(viewResult.Model);
            Assert.Equal(2, model.Count());
            
            // Check ViewBag properties
            Assert.NotNull(_controller.ViewBag.Categories);
            Assert.NotNull(_controller.ViewBag.SortOptions);
            Assert.NotNull(_controller.ViewBag.StockStatusOptions);
        }

        [Fact]
        public async Task Index_WithFilters_AppliesCorrectFiltering()
        {
            // Arrange
            var products = new List<ProductViewModel>
            {
                new ProductViewModel { Id = 1, SKU = "PROD-001", Name = "Gaming Keyboard", Category = "Electronics", Price = 99.99m }
            };

            _mockProductService.Setup(s => s.GetAllProductsAsync(true))
                .ReturnsAsync(products);
            _mockProductService.Setup(s => s.GetCategoriesAsync())
                .ReturnsAsync(new List<string> { "Electronics" });

            // Act
            var result = await _controller.Index("Gaming", "Electronics", "Name", "asc", 50m, 150m, "all", 1, 10);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<IEnumerable<ProductViewModel>>(viewResult.Model);
            
            // Verify filter was applied
            Assert.Single(model);
            var filterModel = _controller.ViewBag.FilterModel as ProductFilterModel;
            Assert.NotNull(filterModel);
            Assert.Equal("Gaming", filterModel.SearchTerm);
            Assert.Equal("Electronics", filterModel.Category);
        }

        [Fact]
        public async Task Details_ValidId_ReturnsProductWithProfitability()
        {
            // Arrange
            var product = new ProductViewModel
            {
                Id = 1,
                SKU = "PROD-001",
                Name = "Test Product",
                Price = 99.99m
            };

            var profitability = new ProfitabilityAnalysis
            {
                MarginPercentage = 25.5m,
                TotalSellingValue = 999.90m,
                PotentialProfit = 249.97m
            };

            _mockProductService.Setup(s => s.GetProductViewModelAsync(1))
                .ReturnsAsync(product);
            _mockPriceCalculationService.Setup(s => s.AnalyzeProfitabilityAsync(1))
                .ReturnsAsync(profitability);

            // Act
            var result = await _controller.Details(1);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsType<ProductViewModel>(viewResult.Model);
            Assert.Equal(product.Id, model.Id);
            Assert.Equal(profitability, _controller.ViewBag.Profitability);
        }

        [Fact]
        public async Task Details_InvalidId_ReturnsNotFound()
        {
            // Arrange
            _mockProductService.Setup(s => s.GetProductViewModelAsync(999))
                .ReturnsAsync((ProductViewModel)null);

            // Act
            var result = await _controller.Details(999);

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }

        [Fact]
        public void Create_Get_ReturnsEmptyViewModel()
        {
            // Act
            var result = _controller.Create();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsType<ProductViewModel>(viewResult.Model);
            Assert.Equal(0, model.Id);
        }

        [Fact]
        public async Task Create_Post_ValidModel_RedirectsToIndex()
        {
            // Arrange
            var model = new ProductViewModel
            {
                SKU = "NEW-001",
                Name = "New Product",
                Price = 99.99m,
                Cost = 49.99m,
                Quantity = 10
            };

            var serviceResult = (Success: true, Message: "Product created successfully", Product: new Product { Id = 1 });

            _mockProductService.Setup(s => s.CreateProductAsync(model))
                .ReturnsAsync(serviceResult);

            // Act
            var result = await _controller.Create(model);

            // Assert
            var redirectResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal(nameof(ProductsController.Index), redirectResult.ActionName);
            Assert.Equal("Product created successfully", _controller.TempData["SuccessMessage"]);
        }

        [Fact]
        public async Task Create_Post_InvalidModel_ReturnsViewWithErrors()
        {
            // Arrange
            var model = new ProductViewModel();
            _controller.ModelState.AddModelError("Name", "Name is required");

            // Act
            var result = await _controller.Create(model);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal(model, viewResult.Model);
            Assert.False(_controller.ModelState.IsValid);
        }

        [Fact]
        public async Task Create_Post_ServiceFailure_ReturnsViewWithError()
        {
            // Arrange
            var model = new ProductViewModel
            {
                SKU = "EXISTING-001",
                Name = "Product"
            };

            var serviceResult = (Success: false, Message: "SKU already exists", Product: (Product?)null);

            _mockProductService.Setup(s => s.CreateProductAsync(model))
                .ReturnsAsync(serviceResult);

            // Act
            var result = await _controller.Create(model);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal(model, viewResult.Model);
            Assert.True(_controller.ModelState.ContainsKey(""));
        }

        [Fact]
        public async Task Edit_Get_ValidId_ReturnsProduct()
        {
            // Arrange
            var product = new ProductViewModel
            {
                Id = 1,
                SKU = "PROD-001",
                Name = "Test Product"
            };

            _mockProductService.Setup(s => s.GetProductViewModelAsync(1))
                .ReturnsAsync(product);

            // Act
            var result = await _controller.Edit(1);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsType<ProductViewModel>(viewResult.Model);
            Assert.Equal(product.Id, model.Id);
        }

        [Fact]
        public async Task Edit_Get_InvalidId_ReturnsNotFound()
        {
            // Arrange
            _mockProductService.Setup(s => s.GetProductViewModelAsync(999))
                .ReturnsAsync((ProductViewModel)null);

            // Act
            var result = await _controller.Edit(999);

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }

        [Fact]
        public async Task Edit_Post_ValidModel_RedirectsToIndex()
        {
            // Arrange
            var model = new ProductViewModel
            {
                Id = 1,
                SKU = "PROD-001",
                Name = "Updated Product"
            };

            var serviceResult = (Success: true, Message: "Product updated successfully");

            _mockProductService.Setup(s => s.UpdateProductAsync(1, model))
                .ReturnsAsync(serviceResult);

            // Act
            var result = await _controller.Edit(1, model);

            // Assert
            var redirectResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal(nameof(ProductsController.Index), redirectResult.ActionName);
        }

        [Fact]
        public async Task Edit_Post_MismatchedId_ReturnsBadRequest()
        {
            // Arrange
            var model = new ProductViewModel { Id = 2 };

            // Act
            var result = await _controller.Edit(1, model);

            // Assert
            Assert.IsType<BadRequestResult>(result);
        }

        [Fact]
        public async Task Delete_Get_ValidId_ReturnsProduct()
        {
            // Arrange
            var product = new ProductViewModel
            {
                Id = 1,
                SKU = "PROD-001",
                Name = "Test Product"
            };

            _mockProductService.Setup(s => s.GetProductViewModelAsync(1))
                .ReturnsAsync(product);

            // Act
            var result = await _controller.Delete(1);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsType<ProductViewModel>(viewResult.Model);
            Assert.Equal(product.Id, model.Id);
        }

        [Fact]
        public async Task DeleteConfirmed_ValidId_RedirectsToIndex()
        {
            // Arrange
            var serviceResult = (Success: true, Message: "Product deleted successfully");

            _mockProductService.Setup(s => s.DeleteProductAsync(1))
                .ReturnsAsync(serviceResult);

            // Act
            var result = await _controller.DeleteConfirmed(1);

            // Assert
            var redirectResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal(nameof(ProductsController.Index), redirectResult.ActionName);
            Assert.Equal("Product deleted successfully", _controller.TempData["SuccessMessage"]);
        }

        [Fact]
        public async Task DeleteConfirmed_ServiceFailure_RedirectsWithError()
        {
            // Arrange
            var serviceResult = (Success: false, Message: "Cannot delete product with existing orders");

            _mockProductService.Setup(s => s.DeleteProductAsync(1))
                .ReturnsAsync(serviceResult);

            // Act
            var result = await _controller.DeleteConfirmed(1);

            // Assert
            var redirectResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal(nameof(ProductsController.Index), redirectResult.ActionName);
            Assert.Equal("Cannot delete product with existing orders", _controller.TempData["ErrorMessage"]);
        }

        [Fact]
        public async Task Search_ValidTerm_ReturnsJsonResults()
        {
            // Arrange
            var products = new List<ProductViewModel>
            {
                new ProductViewModel
                {
                    Id = 1,
                    SKU = "GAME-001",
                    Name = "Gaming Keyboard",
                    Category = "Electronics",
                    Price = 99.99m,
                    Quantity = 50
                }
            };

            _mockProductService.Setup(s => s.SearchProductsAsync("Gaming", ""))
                .ReturnsAsync(products);

            // Act
            var result = await _controller.Search("Gaming", "", 10);

            // Assert
            var jsonResult = Assert.IsType<JsonResult>(result);
            var data = jsonResult.Value as IEnumerable<object>;
            Assert.NotNull(data);
            Assert.Single(data);
        }

        [Fact]
        public async Task Search_EmptyTermAndCategory_ReturnsEmptyList()
        {
            // Act
            var result = await _controller.Search("", "", 10);

            // Assert
            var jsonResult = Assert.IsType<JsonResult>(result);
            var data = jsonResult.Value as IEnumerable<object>;
            Assert.NotNull(data);
            Assert.Empty(data);
        }

        [Fact]
        public async Task QuickView_ValidId_ReturnsProductJson()
        {
            // Arrange
            var product = new ProductViewModel
            {
                Id = 1,
                SKU = "PROD-001",
                Name = "Test Product",
                Price = 99.99m,
                Quantity = 50
            };

            var profitability = new ProfitabilityAnalysis
            {
                MarginPercentage = 25.5m,
                TotalSellingValue = 999.90m,
                PotentialProfit = 249.97m
            };

            _mockProductService.Setup(s => s.GetProductViewModelAsync(1))
                .ReturnsAsync(product);
            _mockPriceCalculationService.Setup(s => s.AnalyzeProfitabilityAsync(1))
                .ReturnsAsync(profitability);

            // Act
            var result = await _controller.QuickView(1);

            // Assert
            var jsonResult = Assert.IsType<JsonResult>(result);
            Assert.NotNull(jsonResult.Value);
        }

        [Fact]
        public async Task QuickView_InvalidId_ReturnsNotFound()
        {
            // Arrange
            _mockProductService.Setup(s => s.GetProductViewModelAsync(999))
                .ReturnsAsync((ProductViewModel)null);

            // Act
            var result = await _controller.QuickView(999);

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }

        [Fact]
        public async Task AdjustStock_ValidAdjustment_ReturnsSuccessJson()
        {
            // Arrange
            var serviceResult = (Success: true, Message: "Stock adjusted successfully");

            _mockProductService.Setup(s => s.AdjustStockAsync(1, 10, "Manual adjustment"))
                .ReturnsAsync(serviceResult);

            // Act
            var result = await _controller.AdjustStock(1, 10, "Manual adjustment");

            // Assert
            var jsonResult = Assert.IsType<JsonResult>(result);
            var data = jsonResult.Value;
            Assert.NotNull(data);
        }

        [Fact]
        public async Task BulkDelete_ValidIds_ReturnsSuccessJson()
        {
            // Arrange
            var productIds = new int[] { 1, 2, 3 };

            _mockProductService.SetupSequence(s => s.DeleteProductAsync(It.IsAny<int>()))
                .ReturnsAsync((Success: true, Message: "Deleted"))
                .ReturnsAsync((Success: true, Message: "Deleted"))
                .ReturnsAsync((Success: true, Message: "Deleted"));

            // Act
            var result = await _controller.BulkDelete(productIds);

            // Assert
            var jsonResult = Assert.IsType<JsonResult>(result);
            var data = jsonResult.Value;
            Assert.NotNull(data);
        }

        [Fact]
        public async Task BulkDelete_NoIds_ReturnsErrorJson()
        {
            // Act
            var result = await _controller.BulkDelete(new int[0]);

            // Assert
            var jsonResult = Assert.IsType<JsonResult>(result);
            var data = jsonResult.Value;
            Assert.NotNull(data);
        }

        [Fact]
        public async Task BulkUpdate_ValidModel_ReturnsSuccessJson()
        {
            // Arrange
            var model = new BulkUpdateModel
            {
                ProductIds = new int[] { 1, 2 },
                Operation = "activate"
            };

            _mockProductService.Setup(s => s.GetProductByIdAsync(It.IsAny<int>()))
                .ReturnsAsync(new Product { Id = 1, SKU = "TEST-001", Name = "Test Product", Price = 99.99m, Cost = 50.00m });
            
            _mockProductService.Setup(s => s.ReactivateProductAsync(It.IsAny<int>()))
                .ReturnsAsync((Success: true, Message: "Product reactivated"));

            // Act
            var result = await _controller.BulkUpdate(model);

            // Assert
            var jsonResult = Assert.IsType<JsonResult>(result);
            var data = jsonResult.Value;
            Assert.NotNull(data);
        }

        [Fact]
        public async Task LowStock_ReturnsLowStockProducts()
        {
            // Arrange
            var lowStockProducts = new List<ProductViewModel>
            {
                new ProductViewModel { Id = 1, Name = "Low Stock Product", Quantity = 2, ReorderPoint = 10 }
            };

            _mockProductService.Setup(s => s.GetLowStockProductsAsync(null))
                .ReturnsAsync(lowStockProducts);

            // Act
            var result = await _controller.LowStock();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("Index", viewResult.ViewName);
            var model = Assert.IsAssignableFrom<IEnumerable<ProductViewModel>>(viewResult.Model);
            Assert.Single(model);
        }

        [Fact]
        public async Task OutOfStock_ReturnsOutOfStockProducts()
        {
            // Arrange
            var outOfStockProducts = new List<ProductViewModel>
            {
                new ProductViewModel { Id = 1, Name = "Out of Stock Product", Quantity = 0 }
            };

            _mockProductService.Setup(s => s.GetOutOfStockProductsAsync())
                .ReturnsAsync(outOfStockProducts);

            // Act
            var result = await _controller.OutOfStock();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("Index", viewResult.ViewName);
            var model = Assert.IsAssignableFrom<IEnumerable<ProductViewModel>>(viewResult.Model);
            Assert.Single(model);
        }

        [Fact]
        public async Task ExportCsv_WithFilter_ReturnsFileResult()
        {
            // Arrange
            var products = new List<ProductViewModel>
            {
                new ProductViewModel
                {
                    SKU = "PROD-001",
                    Name = "Product 1",
                    Price = 99.99m,
                    Quantity = 10
                }
            };

            _mockProductService.Setup(s => s.GetAllProductsAsync(true))
                .ReturnsAsync(products);

            // Act
            var result = await _controller.ExportCsv("simple");

            // Assert
            var fileResult = Assert.IsType<FileContentResult>(result);
            Assert.Equal("text/csv", fileResult.ContentType);
            Assert.Contains("products_simple_", fileResult.FileDownloadName);
        }

        [Fact]
        public async Task PriceAnalysis_ValidId_ReturnsAnalysis()
        {
            // Arrange
            var product = new ProductViewModel
            {
                Id = 1,
                SKU = "PROD-001",
                Name = "Test Product",
                Price = 99.99m
            };

            var profitability = new ProfitabilityAnalysis
            {
                MarginPercentage = 25.5m,
                TotalSellingValue = 999.90m,
                PotentialProfit = 249.97m
            };

            _mockProductService.Setup(s => s.GetProductViewModelAsync(1))
                .ReturnsAsync(product);
            _mockPriceCalculationService.Setup(s => s.AnalyzeProfitabilityAsync(1))
                .ReturnsAsync(profitability);

            // Act
            var result = await _controller.PriceAnalysis(1);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal(product, _controller.ViewBag.Product);
            Assert.Equal(profitability, _controller.ViewBag.Profitability);
        }

        [Fact]
        public async Task Anomalies_ReturnsAnomaliesView()
        {
            // Arrange
            var anomalies = new List<DataAnomalyResult>
            {
                new DataAnomalyResult
                {
                    ProductId = 1,
                    SKU = "PROD-001",
                    AnomalyType = "High Price",
                    Description = "Price significantly higher than category average"
                }
            };

            _mockProductService.Setup(s => s.DetectAnomaliesAsync())
                .ReturnsAsync(anomalies);

            // Act
            var result = await _controller.Anomalies();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<IEnumerable<DataAnomalyResult>>(viewResult.Model);
            Assert.Single(model);
        }
    }
}