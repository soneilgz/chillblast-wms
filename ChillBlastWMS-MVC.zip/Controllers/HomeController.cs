using System.Diagnostics;
using ChillBlastWMS_MVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using ChillBlastWMS_MVC.Models.ViewModels;

namespace ChillBlastWMS_MVC.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            var viewModel = new DashboardViewModel
            {
                UserName = User.Identity?.Name ?? "User",
                UserEmail = User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value ?? "",
                DisplayName = User.FindFirst(System.Security.Claims.ClaimTypes.GivenName)?.Value ?? 
                            User.FindFirst(System.Security.Claims.ClaimTypes.Name)?.Value ?? 
                            User.Identity?.Name ?? "User"
            };

            return View(viewModel);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
