using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using ChillBlastWMS_MVC.Services.Business;
using ChillBlastWMS_MVC.Models.ViewModels;
using ChillBlastWMS_MVC.Models.DTOs;
using ChillBlastWMS_MVC.Models;
using System.Text.Json;
using System.Text;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewEngines;

namespace ChillBlastWMS_MVC.Controllers
{
    [Authorize]
    [Route("Import")]
    public class ImportController : Controller
    {
        private readonly IImportService _importService;
        private readonly ILogger<ImportController> _logger;
        private readonly ICompositeViewEngine _viewEngine;

        // Supported import entity types - Only Products for now
        private static readonly Dictionary<string, ImportEntityConfig> SupportedEntities = new()
        {
            ["Products"] = new ImportEntityConfig
            {
                DisplayName = "Products",
                Description = "Import product catalog with pricing and inventory",
                RequiredFields = new[] { "SKU", "Name", "Price", "Quantity" },
                OptionalFields = new[] { "Description", "Category", "Supplier", "Location", "ReorderPoint", "ReorderQuantity", "Barcode", "Weight", "Volume", "Notes" },
                MaxFileSize = 50 * 1024 * 1024, // 50MB
                SupportedFormats = new[] { "CSV", "Excel", "JSON" },
                TemplateAction = "ProductTemplate"
            }
        };

        public ImportController(
            IImportService importService,
            ILogger<ImportController> logger,
            ICompositeViewEngine viewEngine)
        {
            _importService = importService;
            _logger = logger;
            _viewEngine = viewEngine;
        }

        /// <summary>
        /// Import dashboard showing import history and statistics
        /// </summary>
        [HttpGet("")]
        [HttpGet("Index")]
        public IActionResult Index()
        {
            // Redirect to Products Import since we only support product imports now
            return RedirectToAction("Import", "Products");
        }

        /// <summary>
        /// Display file upload form for various import types
        /// </summary>
        [HttpGet("Upload")]
        public IActionResult Upload(string entityType = "Products")
        {
            if (!SupportedEntities.ContainsKey(entityType))
            {
                TempData["Error"] = $"Import type '{entityType}' is not supported.";
                return RedirectToAction("Index");
            }

            var config = SupportedEntities[entityType];
            var viewModel = new ImportUploadViewModel
            {
                EntityType = entityType,
                EntityConfig = config,
                SupportedEntities = SupportedEntities,
                ImportOptions = new ImportOptionsViewModel
                {
                    UpdateExisting = false,
                    SkipInvalidRecords = true,
                    ValidateOnly = false,
                    BatchSize = 500,
                    BackupBeforeImport = true,
                    CreateMissingReferences = false
                }
            };

            return View(viewModel);
        }

        /// <summary>
        /// Process uploaded file and handle various import types
        /// </summary>
        [HttpPost("Upload")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ProcessUpload(ImportUploadViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    model.SupportedEntities = SupportedEntities;
                    model.EntityConfig = SupportedEntities.GetValueOrDefault(model.EntityType);
                    return View("Upload", model);
                }

                if (!SupportedEntities.ContainsKey(model.EntityType))
                {
                    ModelState.AddModelError("", $"Import type '{model.EntityType}' is not supported.");
                    return View("Upload", model);
                }

                var file = model.ImportFile;
                if (file == null || file.Length == 0)
                {
                    ModelState.AddModelError("ImportFile", "Please select a file to upload.");
                    model.SupportedEntities = SupportedEntities;
                    model.EntityConfig = SupportedEntities[model.EntityType];
                    return View("Upload", model);
                }

                var config = SupportedEntities[model.EntityType];
                
                // Validate file size
                if (file.Length > config.MaxFileSize)
                {
                    ModelState.AddModelError("ImportFile", $"File size exceeds maximum allowed size of {FormatFileSize(config.MaxFileSize)}.");
                    model.SupportedEntities = SupportedEntities;
                    model.EntityConfig = config;
                    return View("Upload", model);
                }

                // Validate file format
                var fileExtension = Path.GetExtension(file.FileName).ToUpper().TrimStart('.');
                if (!config.SupportedFormats.Contains(fileExtension))
                {
                    ModelState.AddModelError("ImportFile", $"File format '{fileExtension}' is not supported. Supported formats: {string.Join(", ", config.SupportedFormats)}.");
                    model.SupportedEntities = SupportedEntities;
                    model.EntityConfig = config;
                    return View("Upload", model);
                }

                _logger.LogInformation("Processing {EntityType} import file: {FileName} ({FileSize} bytes)", 
                    model.EntityType, file.FileName, file.Length);

                // For now, only Products import is fully implemented
                if (model.EntityType == "Products")
                {
                    var importOptions = new ChillBlastWMS_MVC.Services.Business.ImportOptions
                    {
                        UpdateExisting = model.ImportOptions.UpdateExisting,
                        SkipInvalidRecords = model.ImportOptions.SkipInvalidRecords,
                        ValidateOnly = model.ImportOptions.ValidateOnly,
                        BackupBeforeImport = model.ImportOptions.BackupBeforeImport,
                        DefaultCategory = model.ImportOptions.DefaultCategory,
                        DefaultSupplier = model.ImportOptions.DefaultSupplier,
                        CreateCategories = model.ImportOptions.CreateMissingReferences
                    };

                    // Process the file based on format
                    ImportResultViewModel result;
                    if (fileExtension == "CSV")
                    {
                        result = await _importService.ProcessCsvImportAsync(file, importOptions);
                    }
                    else
                    {
                        // For Excel and JSON, we would need additional processing logic
                        throw new NotImplementedException($"Import from {fileExtension} format is not yet implemented.");
                    }

                    TempData["ImportResult"] = result;
                    var importId = result.FileName?.GetHashCode().ToString() ?? Guid.NewGuid().ToString();
                    
                    return RedirectToAction("Result", new { importId = importId });
                }
                else
                {
                    TempData["Error"] = $"Import for {model.EntityType} is not yet implemented. Please check back later.";
                    return View("Upload", model);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing import upload for entity type: {EntityType}", model?.EntityType);
                ModelState.AddModelError("", $"Import processing failed: {ex.Message}");
                model.SupportedEntities = SupportedEntities;
                model.EntityConfig = SupportedEntities.GetValueOrDefault(model?.EntityType ?? "Products");
                return View("Upload", model);
            }
        }

        /// <summary>
        /// Preview data before importing - allows data mapping and validation
        /// </summary>
        [HttpPost("Preview")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Preview(ImportUploadViewModel model)
        {
            try
            {
                if (!ModelState.IsValid || model.ImportFile == null)
                {
                    return BadRequest("Invalid request or no file provided.");
                }

                var file = model.ImportFile;
                var entityType = model.EntityType;

                _logger.LogInformation("Generating preview for {EntityType} import: {FileName}", entityType, file.FileName);

                // For Products import
                if (entityType == "Products")
                {
                    // Validate file format
                    var validation = await _importService.ValidateCsvFileAsync(file);
                    if (!validation.IsValid)
                    {
                        return Json(new { success = false, errors = validation.Errors });
                    }

                    // Parse CSV for preview
                    var products = await _importService.ParseCsvFileAsync(file);
                    var previewData = products.Take(20).ToList(); // Show first 20 records for preview

                    // Detect column mappings
                    var columnMappings = DetectColumnMappings(file, SupportedEntities[entityType]);

                    // Validate preview data
                    var validationResult = await _importService.ValidateImportDataAsync(previewData);

                    var previewModel = new ImportPreviewViewModel
                    {
                        EntityType = entityType,
                        FileName = file.FileName,
                        TotalRecords = products.Count,
                        PreviewData = previewData.Select(p => ConvertToPreviewRecord(p)).ToList(),
                        ColumnMappings = columnMappings,
                        ValidationResult = validationResult,
                        SuggestedMappings = GenerateSuggestedMappings(columnMappings, SupportedEntities[entityType])
                    };

                    return Json(new { 
                        success = true, 
                        html = await RenderPartialViewAsync("_PreviewPartial", previewModel) 
                    });
                }
                else
                {
                    return Json(new { success = false, message = $"Preview for {entityType} is not yet implemented." });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating import preview");
                return Json(new { success = false, message = $"Preview generation failed: {ex.Message}" });
            }
        }

        /// <summary>
        /// Process confirmed import data with final options - Simplified without progress tracking
        /// </summary>
        [HttpPost("Confirm")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConfirmImport([FromBody] ImportConfirmationRequest request)
        {
            try
            {
                _logger.LogInformation("Confirming import for entity type: {EntityType}", request.EntityType);

                // Generate import ID for tracking
                var importId = Guid.NewGuid().ToString();

                // For simplified import, process directly without background tasks
                if (request.EntityType == "Products")
                {
                    // This would typically process the import directly
                    // For now, return success with a simple implementation
                    return Json(new { success = true, importId = importId, message = "Import processing simplified - use direct CSV upload instead" });
                }
                else
                {
                    return Json(new { success = false, message = $"Import for {request.EntityType} is not implemented." });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error confirming import");
                return Json(new { success = false, message = $"Import confirmation failed: {ex.Message}" });
            }
        }


        /// <summary>
        /// View detailed error information for an import - Simplified without progress service
        /// </summary>
        [HttpGet("Errors/{importId}")]
        public async Task<IActionResult> ViewErrors(string importId)
        {
            try
            {
                _logger.LogInformation("Loading error details for import: {ImportId}", importId);

                // With progress service removed, redirect to simplified import
                TempData["Info"] = "Error tracking has been simplified. Please use the direct CSV import feature in Products.";
                return RedirectToAction("Import", "Products");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading import errors for {ImportId}", importId);
                TempData["Error"] = "Failed to load error information.";
                return RedirectToAction("Index");
            }
        }

        /// <summary>
        /// Download error report in various formats - Simplified without progress service
        /// </summary>
        [HttpGet("Errors/{importId}/Download")]
        public async Task<IActionResult> DownloadErrors(string importId, string format = "csv")
        {
            try
            {
                _logger.LogInformation("Error report download requested for import: {ImportId}, format: {Format}", importId, format);

                // With progress service removed, redirect to simplified import
                TempData["Info"] = "Error report download has been simplified. Import errors are now shown directly during CSV import.";
                return RedirectToAction("Import", "Products");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error handling error report download for import: {ImportId}", importId);
                TempData["Error"] = "Failed to generate error report.";
                return RedirectToAction("Index");
            }
        }

        /// <summary>
        /// Display import result with detailed statistics
        /// </summary>
        [HttpGet("Result/{importId}")]
        public async Task<IActionResult> Result(string importId)
        {
            try
            {
                _logger.LogInformation("Loading import result for: {ImportId}", importId);

                // Try to get result from TempData first (for immediate redirects)
                var tempResult = TempData.Peek("ImportResult") as ImportResultViewModel;
                if (tempResult != null && (tempResult.FileName?.GetHashCode().ToString() == importId || importId == "latest"))
                {
                    var viewModel = new ImportResultPageViewModel
                    {
                        ImportResult = ConvertToImportResultModel(tempResult),
                        ErrorDetails = tempResult.Errors.ToList(),
                        HasErrors = tempResult.Errors.Any(),
                        ImportId = importId
                    };

                    return View(viewModel);
                }

                // Progress service removed - handle import result not found
                TempData["Error"] = "Import result not found.";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading import result for {ImportId}", importId);
                TempData["Error"] = "Failed to load import result.";
                return RedirectToAction("Index");
            }
        }

        #region Template Downloads

        /// <summary>
        /// Download import template for specific entity type
        /// </summary>
        [HttpGet("DownloadTemplate")]
        public IActionResult DownloadTemplate(string type = "Products")
        {
            try
            {
                return type.ToLower() switch
                {
                    "products" => GenerateProductTemplate(),
                    _ => GenerateProductTemplate()
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating {EntityType} template", type);
                TempData["Error"] = $"Failed to generate {type} template.";
                return RedirectToAction("Upload", new { entityType = type });
            }
        }

        /// <summary>
        /// Generate product import template with correct schema
        /// </summary>
        private IActionResult GenerateProductTemplate()
        {
            var csvContent = new StringBuilder();
            
            // Add header with required columns
            csvContent.AppendLine("Sku,Name,ManufacturersCode,DateCreated,DateUpdated,IsActive,Summary,Weight,WeightUnit,CategoryID,Category,ManufacturerID,Manufacturer,CostPrice,SellPrice,Qty");
            
            // Add sample data
            csvContent.AppendLine("PROD001,Sample Product 1,MFG001,2024-01-01,2024-01-01,1,High-quality sample product,1.5,kg,1,Electronics,1,Sample Manufacturer,25.00,49.99,100");
            csvContent.AppendLine("PROD002,Sample Product 2,MFG002,2024-01-01,2024-01-01,true,Another sample product,0.8,kg,2,Accessories,2,Another Manufacturer,15.50,29.99,50");
            csvContent.AppendLine("PROD003,Sample Product 3,MFG003,2024-01-01,2024-01-01,yes,Third sample product,2.1,kg,1,Electronics,1,Sample Manufacturer,45.00,89.99,25");

            var bytes = Encoding.UTF8.GetBytes(csvContent.ToString());
            return File(bytes, "text/csv", "product-import-template.csv");
        }

        /// <summary>
        /// Download import template for products (legacy endpoint)
        /// </summary>
        [HttpGet("Template/Products")]
        public IActionResult ProductTemplate()
        {
            return GenerateProductTemplate();
        }

        #endregion

        #region Helper Methods

        private Dictionary<string, string> DetectColumnMappings(IFormFile file, ImportEntityConfig config)
        {
            var mappings = new Dictionary<string, string>();
            
            // This would analyze the CSV headers and suggest mappings
            // For now, return basic mappings
            if (config.DisplayName == "Products")
            {
                mappings = new Dictionary<string, string>
                {
                    ["SKU"] = "SKU",
                    ["Name"] = "Name", 
                    ["Description"] = "Description",
                    ["Price"] = "Price",
                    ["Quantity"] = "Quantity",
                    ["Category"] = "Category"
                };
            }

            return mappings;
        }

        private Dictionary<string, object> ConvertToPreviewRecord(ProductImportDto product)
        {
            return new Dictionary<string, object>
            {
                ["SKU"] = product.SKU ?? "",
                ["Name"] = product.Name ?? "",
                ["Description"] = product.Description ?? "",
                ["Price"] = product.Price,
                ["Quantity"] = product.Quantity,
                ["Category"] = product.Category ?? "",
                ["Supplier"] = product.Supplier ?? "",
                ["Location"] = product.Location ?? ""
            };
        }

        private Dictionary<string, string> GenerateSuggestedMappings(Dictionary<string, string> currentMappings, ImportEntityConfig config)
        {
            var suggestions = new Dictionary<string, string>();
            
            // Add intelligent mapping suggestions based on column names and data analysis
            foreach (var required in config.RequiredFields)
            {
                if (!currentMappings.ContainsKey(required))
                {
                    suggestions[required] = $"Please map the '{required}' field";
                }
            }

            return suggestions;
        }

        private async Task<string> RenderPartialViewAsync(string viewName, object model)
        {
            var viewData = new ViewDataDictionary<object>(ViewData, model);
            
            using var writer = new StringWriter();
            var viewResult = _viewEngine.FindView(ControllerContext, viewName, false);
            
            if (viewResult.Success)
            {
                var viewContext = new ViewContext(ControllerContext, viewResult.View, viewData, TempData, writer, new HtmlHelperOptions());
                await viewResult.View.RenderAsync(viewContext);
                return writer.ToString();
            }
            
            return "";
        }

        private static string FormatFileSize(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            double len = bytes;
            int order = 0;
            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len /= 1024;
            }
            return $"{len:0.##} {sizes[order]}";
        }

        private ImportResultModel ConvertToImportResultModel(ImportResultViewModel result)
        {
            return new ImportResultModel
            {
                IsSuccess = result.Success,
                FileName = result.FileName,
                TotalRecordsInFile = result.TotalRecords,
                RecordsCreated = result.SuccessfulRecords,
                RecordsFailed = result.FailedRecords,
                RecordsUpdated = result.UpdatedRecords,
                RecordsSkipped = result.SkippedRecords,
                RecordsProcessed = result.TotalRecords,
                ImportStartTime = DateTime.UtcNow.Subtract(result.ProcessingTime),
                ImportEndTime = DateTime.UtcNow,
                CompletionStatus = result.Success 
                    ? (result.FailedRecords > 0 || result.SkippedRecords > 0 ? ImportCompletionStatus.PartialSuccess : ImportCompletionStatus.Success)
                    : ImportCompletionStatus.Failed
            };
        }

        #endregion
    }
}