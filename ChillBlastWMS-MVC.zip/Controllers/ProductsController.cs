using ChillBlastWMS_MVC.Models.ViewModels;
using ChillBlastWMS_MVC.Services.Business;
using ChillBlastWMS_MVC.Utilities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System.Text;
using System.Linq.Dynamic.Core;

namespace ChillBlastWMS_MVC.Controllers
{
    [Authorize]
    public class ProductsController : Controller
    {
        private readonly IProductService _productService;
        private readonly IImportService _importService;
        private readonly IPriceCalculationService _priceCalculationService;
        private readonly ILogger<ProductsController> _logger;

        public ProductsController(
            IProductService productService,
            IImportService importService,
            IPriceCalculationService priceCalculationService,
            ILogger<ProductsController> logger)
        {
            _productService = productService;
            _importService = importService;
            _priceCalculationService = priceCalculationService;
            _logger = logger;
        }

        // GET: Products
        public async Task<IActionResult> Index(
            string searchTerm, 
            string category, 
            string sortBy = "Name",
            string sortOrder = "asc",
            decimal? minPrice = null,
            decimal? maxPrice = null,
            string stockStatus = "all",
            int page = 1,
            int pageSize = 20)
        {
            // Build filter model
            var filterModel = new ProductFilterModel
            {
                SearchTerm = searchTerm,
                Category = category,
                SortBy = sortBy,
                SortOrder = sortOrder,
                MinPrice = minPrice,
                MaxPrice = maxPrice,
                StockStatus = stockStatus,
                Page = page,
                PageSize = pageSize
            };

            // Get filtered and sorted products
            var products = await GetFilteredProductsAsync(filterModel);
            var totalCount = await GetFilteredProductCountAsync(filterModel);

            // Prepare view data
            ViewBag.FilterModel = filterModel;
            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
            ViewBag.TotalCount = totalCount;
            ViewBag.Categories = new SelectList(await _productService.GetCategoriesAsync(), category);
            ViewBag.SortOptions = GetSortOptions();
            ViewBag.StockStatusOptions = GetStockStatusOptions();

            // Add pagination info
            ViewBag.StartRecord = ((page - 1) * pageSize) + 1;
            ViewBag.EndRecord = Math.Min(page * pageSize, totalCount);

            // Store current filter in TempData for export
            TempData["CurrentFilter"] = System.Text.Json.JsonSerializer.Serialize(filterModel);

            return View(products);
        }

        private async Task<IEnumerable<ProductViewModel>> GetFilteredProductsAsync(ProductFilterModel filter)
        {
            var allProducts = await _productService.GetAllProductsAsync(filter.StockStatus != "inactive");
            var query = allProducts.AsQueryable();

            // Apply search filter
            if (!string.IsNullOrWhiteSpace(filter.SearchTerm))
            {
                var searchLower = filter.SearchTerm.ToLower();
                query = query.Where(p => 
                    p.SKU.ToLower().Contains(searchLower) ||
                    p.Name.ToLower().Contains(searchLower) ||
                    (p.Description != null && p.Description.ToLower().Contains(searchLower)) ||
                    (p.Supplier != null && p.Supplier.ToLower().Contains(searchLower)));
            }

            // Apply category filter
            if (!string.IsNullOrWhiteSpace(filter.Category))
            {
                query = query.Where(p => p.Category == filter.Category);
            }

            // Apply price range filter
            if (filter.MinPrice.HasValue)
            {
                query = query.Where(p => p.Price >= filter.MinPrice.Value);
            }
            if (filter.MaxPrice.HasValue)
            {
                query = query.Where(p => p.Price <= filter.MaxPrice.Value);
            }

            // Apply stock status filter
            query = filter.StockStatus?.ToLower() switch
            {
                "instock" => query.Where(p => p.Quantity > p.ReorderPoint),
                "lowstock" => query.Where(p => p.Quantity > 0 && p.Quantity <= p.ReorderPoint),
                "outofstock" => query.Where(p => p.Quantity == 0),
                "inactive" => query.Where(p => !p.IsActive),
                _ => query.Where(p => p.IsActive)
            };

            // Apply sorting
            query = ApplySorting(query, filter.SortBy, filter.SortOrder);

            // Apply pagination
            return query
                .Skip((filter.Page - 1) * filter.PageSize)
                .Take(filter.PageSize)
                .ToList();
        }

        private async Task<int> GetFilteredProductCountAsync(ProductFilterModel filter)
        {
            var products = await GetFilteredProductsAsync(new ProductFilterModel 
            { 
                SearchTerm = filter.SearchTerm,
                Category = filter.Category,
                MinPrice = filter.MinPrice,
                MaxPrice = filter.MaxPrice,
                StockStatus = filter.StockStatus,
                Page = 1,
                PageSize = int.MaxValue
            });
            return products.Count();
        }

        private IQueryable<ProductViewModel> ApplySorting(IQueryable<ProductViewModel> query, string sortBy, string sortOrder)
        {
            var isDescending = sortOrder?.ToLower() == "desc";

            return sortBy?.ToLower() switch
            {
                "sku" => isDescending ? query.OrderByDescending(p => p.SKU) : query.OrderBy(p => p.SKU),
                "name" => isDescending ? query.OrderByDescending(p => p.Name) : query.OrderBy(p => p.Name),
                "category" => isDescending ? query.OrderByDescending(p => p.Category) : query.OrderBy(p => p.Category),
                "price" => isDescending ? query.OrderByDescending(p => p.Price) : query.OrderBy(p => p.Price),
                "quantity" => isDescending ? query.OrderByDescending(p => p.Quantity) : query.OrderBy(p => p.Quantity),
                "created" => isDescending ? query.OrderByDescending(p => p.CreatedAt) : query.OrderBy(p => p.CreatedAt),
                "updated" => isDescending ? query.OrderByDescending(p => p.UpdatedAt) : query.OrderBy(p => p.UpdatedAt),
                _ => query.OrderBy(p => p.Name)
            };
        }

        private SelectList GetSortOptions()
        {
            var options = new List<SelectListItem>
            {
                new SelectListItem { Value = "Name", Text = "Name" },
                new SelectListItem { Value = "SKU", Text = "SKU" },
                new SelectListItem { Value = "Category", Text = "Category" },
                new SelectListItem { Value = "Price", Text = "Price" },
                new SelectListItem { Value = "Quantity", Text = "Quantity" },
                new SelectListItem { Value = "Created", Text = "Date Added" },
                new SelectListItem { Value = "Updated", Text = "Last Updated" }
            };
            return new SelectList(options, "Value", "Text");
        }

        private SelectList GetStockStatusOptions()
        {
            var options = new List<SelectListItem>
            {
                new SelectListItem { Value = "all", Text = "All Active" },
                new SelectListItem { Value = "instock", Text = "In Stock" },
                new SelectListItem { Value = "lowstock", Text = "Low Stock" },
                new SelectListItem { Value = "outofstock", Text = "Out of Stock" },
                new SelectListItem { Value = "inactive", Text = "Inactive" }
            };
            return new SelectList(options, "Value", "Text");
        }

        // GET: Products/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var product = await _productService.GetProductViewModelAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            // Get profitability analysis
            var profitability = await _priceCalculationService.AnalyzeProfitabilityAsync(id);
            ViewBag.Profitability = profitability;

            return View(product);
        }

        // GET: Products/Create
        public IActionResult Create()
        {
            return View(new ProductViewModel());
        }

        // POST: Products/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = await _productService.CreateProductAsync(model);
                if (result.Success)
                {
                    TempData["SuccessMessage"] = result.Message;
                    return RedirectToAction(nameof(Index));
                }
                
                ModelState.AddModelError("", result.Message);
            }

            return View(model);
        }

        // GET: Products/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var product = await _productService.GetProductViewModelAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // POST: Products/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, ProductViewModel model)
        {
            if (id != model.Id)
            {
                return BadRequest();
            }

            if (ModelState.IsValid)
            {
                var result = await _productService.UpdateProductAsync(id, model);
                if (result.Success)
                {
                    TempData["SuccessMessage"] = result.Message;
                    return RedirectToAction(nameof(Index));
                }
                
                ModelState.AddModelError("", result.Message);
            }

            return View(model);
        }

        // GET: Products/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var product = await _productService.GetProductViewModelAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // POST: Products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var result = await _productService.DeleteProductAsync(id);
            if (result.Success)
            {
                TempData["SuccessMessage"] = result.Message;
            }
            else
            {
                TempData["ErrorMessage"] = result.Message;
            }

            return RedirectToAction(nameof(Index));
        }

        // GET: Products/Import
        public async Task<IActionResult> Import()
        {
            var model = new ImportViewModel();
            ViewBag.ImportHistory = await _importService.GetImportHistoryAsync(10);
            return View(model);
        }

        // POST: Products/Import
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Import(ImportViewModel model)
        {
            if (model.CsvFile == null || model.CsvFile.Length == 0)
            {
                ModelState.AddModelError("CsvFile", "Please select a CSV file to import.");
                ViewBag.ImportHistory = await _importService.GetImportHistoryAsync(10);
                return View(model);
            }

            try
            {
                var options = new ChillBlastWMS_MVC.Services.Business.ImportOptions
                {
                    UpdateExisting = model.UpdateExisting,
                    SkipInvalidRecords = model.SkipInvalidRecords,
                    ValidateOnly = false
                };

                var result = await _importService.ProcessCsvImportAsync(model.CsvFile, options);

                if (result.Success)
                {
                    TempData["SuccessMessage"] = $"Import completed successfully! {result.Message}";
                }
                else
                {
                    TempData["ErrorMessage"] = $"Import completed with errors. {result.Message}";
                    ViewBag.ImportErrors = result.Errors;
                }

                ViewBag.ImportResult = result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during CSV import");
                TempData["ErrorMessage"] = "An error occurred during import. Please check the file format and try again.";
            }

            ViewBag.ImportHistory = await _importService.GetImportHistoryAsync(10);
            return View(model);
        }

        // POST: Products/ValidateImport
        [HttpPost]
        public async Task<IActionResult> ValidateImport(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return Json(new { success = false, message = "No file provided" });
            }

            try
            {
                var options = new ChillBlastWMS_MVC.Services.Business.ImportOptions
                {
                    ValidateOnly = true,
                    SkipInvalidRecords = true
                };

                var result = await _importService.ProcessCsvImportAsync(file, options);
                
                // Build detailed row breakdown from validation results
                var rowDetails = new List<object>();
                var warningCount = 0;
                
                // Add validation errors as row details
                foreach (var error in result.Errors)
                {
                    rowDetails.Add(new 
                    {
                        rowNumber = error.RowNumber > 0 ? error.RowNumber.ToString() : "Unknown",
                        status = "error",
                        issues = new[] 
                        {
                            new 
                            {
                                field = error.Field ?? "Unknown",
                                message = error.ErrorMessage ?? error.Message ?? "Validation error",
                                severity = "error"
                            }
                        },
                        data = new Dictionary<string, object>
                        {
                            ["SKU"] = error.SKU ?? "N/A",
                            ["Field"] = error.Field ?? "Unknown",
                            ["Value"] = error.Value ?? "N/A",
                            ["Error"] = error.ErrorMessage ?? error.Message ?? "Validation error"
                        }
                    });
                }
                
                // Parse anomalies from the message if available
                _logger.LogInformation("ValidateImport result - Success: {Success}, TotalRecords: {Total}, SuccessfulRecords: {Successful}, FailedRecords: {Failed}, Message: {Message}", 
                    result.Success, result.TotalRecords, result.SuccessfulRecords, result.FailedRecords, result.Message);
                _logger.LogInformation("Error count: {ErrorCount}", result.Errors?.Count ?? 0);
                
                if (!string.IsNullOrEmpty(result.Message))
                {
                    _logger.LogInformation("Parsing validation message: {Message}", result.Message);
                    
                    // Parse the structured message format for anomalies
                    var anomalyPatterns = new Dictionary<string, string>
                    {
                        ["negative margin"] = @"- (\d+) negative margin products flagged: ([^\r\n]+)",
                        ["high price"] = @"- (\d+) extremely high price products flagged: ([^\r\n]+)",
                        ["heavy product"] = @"- (\d+) extremely heavy products flagged: ([^\r\n]+)"
                    };
                    
                    foreach (var pattern in anomalyPatterns)
                    {
                        var matches = System.Text.RegularExpressions.Regex.Matches(result.Message, pattern.Value, System.Text.RegularExpressions.RegexOptions.Multiline);
                        _logger.LogInformation("Found {MatchCount} matches for {PatternType} with pattern: {Pattern}", matches.Count, pattern.Key, pattern.Value);
                        
                        foreach (System.Text.RegularExpressions.Match match in matches)
                        {
                            if (match.Groups.Count >= 3)
                            {
                                var count = int.Parse(match.Groups[1].Value);
                                var skuList = match.Groups[2].Value;
                                var skus = skuList.Split(',').Select(s => s.Trim()).ToArray();
                                
                                _logger.LogInformation("Processing {Count} {PatternType} anomalies: {SkuList}", count, pattern.Key, skuList);
                                
                                foreach (var sku in skus)
                                {
                                    var issueDescription = pattern.Key switch
                                    {
                                        "negative margin" => "Negative margin detected - requires approval",
                                        "high price" => "Extremely high price - data quality alert", 
                                        "heavy product" => "Extremely heavy product - data quality alert",
                                        _ => "Business rule violation detected"
                                    };
                                    
                                    var issueType = pattern.Key switch
                                    {
                                        "negative margin" => "Negative Margin",
                                        "high price" => "High Price Alert",
                                        "heavy product" => "Weight Alert", 
                                        _ => "Data Quality Alert"
                                    };
                                    
                                    rowDetails.Add(new 
                                    {
                                        rowNumber = "Unknown",
                                        status = "warning",
                                        issues = new[] 
                                        {
                                            new 
                                            {
                                                field = GetFieldFromIssue(issueDescription),
                                                message = issueDescription,
                                                severity = "warning"
                                            }
                                        },
                                        data = new Dictionary<string, object>
                                        {
                                            ["SKU"] = sku,
                                            ["Issue Type"] = issueType,
                                            ["Description"] = issueDescription,
                                            ["Requires Action"] = IsHighPriorityIssue(issueDescription) ? "Yes" : "No"
                                        }
                                    });
                                }
                            }
                        }
                    }
                    
                    // Also check for anomaly summary counts to get remaining anomalies not captured by specific patterns
                    var criticalMatch = System.Text.RegularExpressions.Regex.Match(result.Message, @"- Critical: (\d+)");
                    var highMatch = System.Text.RegularExpressions.Regex.Match(result.Message, @"- High: (\d+)");
                    var mediumMatch = System.Text.RegularExpressions.Regex.Match(result.Message, @"- Medium: (\d+)");
                    
                    var criticalCount = criticalMatch.Success ? int.Parse(criticalMatch.Groups[1].Value) : 0;
                    var highCount = highMatch.Success ? int.Parse(highMatch.Groups[1].Value) : 0;
                    var mediumCount = mediumMatch.Success ? int.Parse(mediumMatch.Groups[1].Value) : 0;
                    
                    var totalCategorizedAnomalies = criticalCount + highCount + mediumCount;
                    var currentDetailedCount = rowDetails.Count;
                    
                    _logger.LogInformation("Anomaly summary - Critical: {Critical}, High: {High}, Medium: {Medium}, Current detailed count: {DetailedCount}", 
                        criticalCount, highCount, mediumCount, currentDetailedCount);
                    
                    // Add remaining anomalies if the total categorized count is higher than what we've detailed
                    if (totalCategorizedAnomalies > currentDetailedCount)
                    {
                        var remaining = totalCategorizedAnomalies - currentDetailedCount;
                        for (int i = 0; i < remaining; i++)
                        {
                            rowDetails.Add(new 
                            {
                                rowNumber = "Unknown",
                                status = "warning",
                                issues = new[] 
                                {
                                    new 
                                    {
                                        field = "Data Quality",
                                        message = "Additional business rule violation detected",
                                        severity = "warning"
                                    }
                                },
                                data = new Dictionary<string, object>
                                {
                                    ["SKU"] = "Unknown",
                                    ["Issue Type"] = "Data Quality Alert",
                                    ["Description"] = "Additional anomaly detected in validation",
                                    ["Requires Action"] = "Review validation logs for details"
                                }
                            });
                        }
                    }
                    
                    // Set warning count to the total categorized anomalies
                    warningCount = totalCategorizedAnomalies;
                }
                
                // Extract duplicate count from message but don't add it as a separate row
                // since duplicates are usually part of the anomaly count already
                var duplicateMatch = System.Text.RegularExpressions.Regex.Match(result.Message ?? "", @"(\d+) duplicate records flagged");
                var duplicateCount = duplicateMatch.Success ? int.Parse(duplicateMatch.Groups[1].Value) : 0;
                
                _logger.LogInformation("Final validation results - RowDetails count: {RowDetailsCount}, WarningCount: {WarningCount}, DuplicateCount: {DuplicateCount}", 
                    rowDetails.Count, warningCount, duplicateCount);
                
                return Json(new 
                { 
                    success = true, // Always true for successful validation, even with issues
                    message = result.Message,
                    totalRecords = result.TotalRecords,
                    validRecords = result.SuccessfulRecords,
                    invalidRecords = result.FailedRecords,
                    warningRecords = warningCount,
                    rowDetails = rowDetails,
                    columns = new[] { "SKU", "Issue Type", "Description", "Requires Action" },
                    errors = result.Errors.Take(10) // Keep for backward compatibility
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error validating CSV import");
                return Json(new { success = false, message = "Validation failed: " + ex.Message });
            }
        }
        
        private string GetFieldFromIssue(string issue)
        {
            if (issue.Contains("margin")) return "Margin";
            if (issue.Contains("price")) return "Price";
            if (issue.Contains("weight") || issue.Contains("heavy")) return "Weight";
            return "General";
        }
        
        private string GetIssueType(string issue)
        {
            if (issue.Contains("Negative margin")) return "Negative Margin";
            if (issue.Contains("high price")) return "High Price Alert";
            if (issue.Contains("heavy product")) return "Weight Alert";
            return "Business Rule Violation";
        }
        
        private bool IsHighPriorityIssue(string issue)
        {
            return issue.Contains("Negative margin") || issue.Contains("requires approval");
        }

        // GET: Products/DownloadTemplate
        public async Task<IActionResult> DownloadTemplate()
        {
            var template = await _importService.GenerateImportTemplateAsync();
            return File(template, "text/csv", "product_import_template.csv");
        }

        // GET: Products/ExportProducts
        public async Task<IActionResult> ExportProducts(string category, bool activeOnly = true)
        {
            var options = new ExportOptions
            {
                ActiveOnly = activeOnly,
                Category = category,
                IncludeStockInfo = true,
                IncludePricing = true
            };

            var csvData = await _importService.ExportProductsToCsvAsync(options);
            var fileName = $"products_export_{DateTime.Now:yyyyMMdd_HHmmss}.csv";
            
            return File(csvData, "text/csv", fileName);
        }

        // GET: Products/LowStock
        public async Task<IActionResult> LowStock()
        {
            var products = await _productService.GetLowStockProductsAsync();
            return View("Index", products);
        }

        // GET: Products/OutOfStock
        public async Task<IActionResult> OutOfStock()
        {
            var products = await _productService.GetOutOfStockProductsAsync();
            return View("Index", products);
        }

        // GET: Products/Anomalies
        public async Task<IActionResult> Anomalies()
        {
            var anomalies = await _productService.DetectAnomaliesAsync();
            return View(anomalies);
        }

        // POST: Products/BulkDelete
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BulkDelete(int[] productIds)
        {
            if (productIds == null || productIds.Length == 0)
            {
                return Json(new { success = false, message = "No products selected" });
            }

            var successCount = 0;
            var failedCount = 0;
            var errors = new List<string>();

            foreach (var id in productIds)
            {
                var result = await _productService.DeleteProductAsync(id);
                if (result.Success)
                {
                    successCount++;
                }
                else
                {
                    failedCount++;
                    errors.Add($"Product ID {id}: {result.Message}");
                }
            }

            var message = $"Deleted {successCount} products successfully.";
            if (failedCount > 0)
            {
                message += $" {failedCount} products failed to delete.";
            }

            return Json(new 
            { 
                success = failedCount == 0, 
                message = message,
                successCount = successCount,
                failedCount = failedCount,
                errors = errors
            });
        }

        // POST: Products/BulkUpdate
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BulkUpdate(BulkUpdateModel model)
        {
            if (model.ProductIds == null || model.ProductIds.Length == 0)
            {
                return Json(new { success = false, message = "No products selected" });
            }

            var updates = new Dictionary<int, int>();
            var priceUpdates = new Dictionary<int, decimal>();

            foreach (var id in model.ProductIds)
            {
                var product = await _productService.GetProductByIdAsync(id);
                if (product == null) continue;

                // Apply updates based on operation type
                switch (model.Operation?.ToLower())
                {
                    case "activate":
                        await _productService.ReactivateProductAsync(id);
                        break;
                    case "deactivate":
                        await _productService.DeactivateProductAsync(id);
                        break;
                    case "updatecategory":
                        if (!string.IsNullOrWhiteSpace(model.NewCategory))
                        {
                            var vm = await _productService.GetProductViewModelAsync(id);
                            if (vm != null)
                            {
                                vm.Category = model.NewCategory;
                                await _productService.UpdateProductAsync(id, vm);
                            }
                        }
                        break;
                    case "adjustprice":
                        if (model.PriceAdjustment.HasValue)
                        {
                            priceUpdates[id] = product.Price * (1 + model.PriceAdjustment.Value / 100);
                        }
                        break;
                    case "setreorderpoint":
                        if (model.NewReorderPoint.HasValue)
                        {
                            var vm = await _productService.GetProductViewModelAsync(id);
                            if (vm != null)
                            {
                                vm.ReorderPoint = model.NewReorderPoint.Value;
                                await _productService.UpdateProductAsync(id, vm);
                            }
                        }
                        break;
                }
            }

            // Apply price updates if any
            if (priceUpdates.Any())
            {
                var priceResult = await _priceCalculationService.BulkUpdatePricesAsync(
                    priceUpdates, $"Bulk price adjustment: {model.PriceAdjustment}%");
            }

            return Json(new 
            { 
                success = true, 
                message = $"Successfully updated {model.ProductIds.Length} products",
                affectedCount = model.ProductIds.Length
            });
        }

        // GET: Products/Search (AJAX)
        [HttpGet]
        public async Task<IActionResult> Search(string term, string category, int limit = 10)
        {
            if (string.IsNullOrWhiteSpace(term) && string.IsNullOrWhiteSpace(category))
            {
                return Json(new List<object>());
            }

            var products = await _productService.SearchProductsAsync(term ?? "", category);
            
            var results = products
                .Take(limit)
                .Select(p => new
                {
                    id = p.Id,
                    sku = p.SKU,
                    name = p.Name,
                    category = p.Category,
                    price = p.Price,
                    quantity = p.Quantity,
                    stockStatus = p.StockStatus,
                    stockLevel = p.StockLevel,
                    imageUrl = "/images/product-placeholder.png" // Add actual image URL if available
                })
                .ToList();

            return Json(results);
        }

        // GET: Products/QuickView/5 (AJAX)
        [HttpGet]
        public async Task<IActionResult> QuickView(int id)
        {
            var product = await _productService.GetProductViewModelAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            var profitability = await _priceCalculationService.AnalyzeProfitabilityAsync(id);

            return Json(new
            {
                product = new
                {
                    id = product.Id,
                    sku = product.SKU,
                    name = product.Name,
                    description = product.Description,
                    category = product.Category,
                    price = product.Price,
                    quantity = product.Quantity,
                    location = product.Location,
                    supplier = product.Supplier,
                    reorderPoint = product.ReorderPoint,
                    reorderQuantity = product.ReorderQuantity,
                    stockStatus = product.StockStatus,
                    isActive = product.IsActive,
                    createdAt = product.CreatedAt.ToString("yyyy-MM-dd HH:mm"),
                    updatedAt = product.UpdatedAt?.ToString("yyyy-MM-dd HH:mm")
                },
                profitability = new
                {
                    marginPercentage = profitability.MarginPercentage,
                    totalValue = profitability.TotalSellingValue,
                    potentialProfit = profitability.PotentialProfit,
                    status = profitability.ProfitabilityStatus
                }
            });
        }

        // POST: Products/AdjustStock
        [HttpPost]
        public async Task<IActionResult> AdjustStock(int id, int adjustment, string reason)
        {
            var result = await _productService.AdjustStockAsync(id, adjustment, reason);
            
            if (result.Success)
            {
                return Json(new { success = true, message = result.Message });
            }
            
            return Json(new { success = false, message = result.Message });
        }

        // GET: Products/ExportCsv
        public async Task<IActionResult> ExportCsv(string format = "full")
        {
            // Retrieve current filter from TempData
            ProductFilterModel? filter = null;
            if (TempData["CurrentFilter"] is string filterJson)
            {
                filter = System.Text.Json.JsonSerializer.Deserialize<ProductFilterModel>(filterJson);
                TempData.Keep("CurrentFilter");
            }

            // Get filtered products
            var products = filter != null 
                ? await GetFilteredProductsAsync(new ProductFilterModel 
                  { 
                      SearchTerm = filter.SearchTerm,
                      Category = filter.Category,
                      MinPrice = filter.MinPrice,
                      MaxPrice = filter.MaxPrice,
                      StockStatus = filter.StockStatus,
                      Page = 1,
                      PageSize = int.MaxValue
                  })
                : await _productService.GetAllProductsAsync();

            var csv = new StringBuilder();
            
            switch (format.ToLower())
            {
                case "simple":
                    csv.AppendLine("SKU,Name,Price,Quantity");
                    foreach (var product in products)
                    {
                        csv.AppendLine($"{EscapeCsv(product.SKU)},{EscapeCsv(product.Name)},{product.Price},{product.Quantity}");
                    }
                    break;

                case "inventory":
                    csv.AppendLine("SKU,Name,Category,Quantity,Reorder Point,Reorder Quantity,Location,Stock Status");
                    foreach (var product in products)
                    {
                        csv.AppendLine($"{EscapeCsv(product.SKU)},{EscapeCsv(product.Name)},{EscapeCsv(product.Category)}," +
                                     $"{product.Quantity},{product.ReorderPoint},{product.ReorderQuantity}," +
                                     $"{EscapeCsv(product.Location)},{product.StockStatus}");
                    }
                    break;

                case "pricing":
                    csv.AppendLine("SKU,Name,Category,Price,Quantity,Total Value");
                    foreach (var product in products)
                    {
                        var totalValue = product.Price * product.Quantity;
                        csv.AppendLine($"{EscapeCsv(product.SKU)},{EscapeCsv(product.Name)},{EscapeCsv(product.Category)}," +
                                     $"{product.Price},{product.Quantity},{totalValue:F2}");
                    }
                    break;

                default: // full
                    csv.AppendLine("SKU,Name,Description,Category,Price,Quantity,Location,Reorder Point,Reorder Quantity,Supplier,Active,Created,Updated");
                    foreach (var product in products)
                    {
                        csv.AppendLine($"{EscapeCsv(product.SKU)},{EscapeCsv(product.Name)},{EscapeCsv(product.Description)}," +
                                     $"{EscapeCsv(product.Category)},{product.Price},{product.Quantity},{EscapeCsv(product.Location)}," +
                                     $"{product.ReorderPoint},{product.ReorderQuantity},{EscapeCsv(product.Supplier)}," +
                                     $"{product.IsActive},{product.CreatedAt:yyyy-MM-dd HH:mm},{product.UpdatedAt?.ToString("yyyy-MM-dd HH:mm") ?? ""}");
                    }
                    break;
            }

            var fileName = $"products_{format}_{DateTime.Now:yyyyMMdd_HHmmss}.csv";
            var bytes = Encoding.UTF8.GetBytes(csv.ToString());
            
            return File(bytes, "text/csv", fileName);
        }

        private string EscapeCsv(string? value)
        {
            if (string.IsNullOrEmpty(value))
                return "";
            
            if (value.Contains(",") || value.Contains("\"") || value.Contains("\n"))
            {
                return $"\"{value.Replace("\"", "\"\"")}\"";
            }
            
            return value;
        }

        // GET: Products/PriceAnalysis/5
        public async Task<IActionResult> PriceAnalysis(int id)
        {
            var product = await _productService.GetProductViewModelAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            var profitability = await _priceCalculationService.AnalyzeProfitabilityAsync(id);

            ViewBag.Product = product;
            ViewBag.Profitability = profitability;

            return View();
        }
    }
}