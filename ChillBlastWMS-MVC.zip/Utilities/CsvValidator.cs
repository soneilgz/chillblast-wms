using System.Text;
using System.Text.RegularExpressions;
using CsvHelper;
using CsvHelper.Configuration;
using System.Globalization;

namespace ChillBlastWMS_MVC.Utilities
{
    public class CsvValidator
    {
        private readonly List<string> _requiredColumns;
        private readonly List<string> _optionalColumns;
        private readonly Dictionary<string, Type> _columnTypes;
        private readonly CsvValidationOptions _options;

        public CsvValidator(CsvValidationOptions? options = null)
        {
            _options = options ?? new CsvValidationOptions();
            
            _requiredColumns = new List<string> { 
                "Sku", "Name", "ManufacturersCode", "DateCreated", "DateUpdated", 
                "IsActive", "Summary", "Weight", "WeightUnit", "CategoryID", 
                "Category", "ManufacturerID", "Manufacturer", "CostPrice", 
                "SellPrice", "Qty" 
            };
            _optionalColumns = new List<string> { "Description", "Location", 
                "ReorderPoint", "ReorderQuantity", "Supplier" };
            
            _columnTypes = new Dictionary<string, Type>
            {
                { "Sku", typeof(string) },
                { "Name", typeof(string) },
                { "ManufacturersCode", typeof(string) },
                { "DateCreated", typeof(DateTime) },
                { "DateUpdated", typeof(DateTime) },
                { "IsActive", typeof(bool) },
                { "Summary", typeof(string) },
                { "Weight", typeof(decimal) },
                { "WeightUnit", typeof(string) },
                { "CategoryID", typeof(int) },
                { "Category", typeof(string) },
                { "ManufacturerID", typeof(int) },
                { "Manufacturer", typeof(string) },
                { "CostPrice", typeof(decimal) },
                { "SellPrice", typeof(decimal) },
                { "Qty", typeof(int) },
                { "Description", typeof(string) },
                { "Location", typeof(string) },
                { "ReorderPoint", typeof(int) },
                { "ReorderQuantity", typeof(int) },
                { "Supplier", typeof(string) }
            };
        }

        public async Task<CsvValidationResult> ValidateFileStructureAsync(Stream fileStream)
        {
            var result = new CsvValidationResult { IsValid = true };

            try
            {
                using var reader = new StreamReader(fileStream);
                var content = await reader.ReadToEndAsync();
                
                if (string.IsNullOrWhiteSpace(content))
                {
                    result.IsValid = false;
                    result.Errors.Add("File is empty");
                    return result;
                }

                // Reset stream position for further processing
                fileStream.Position = 0;

                // Validate encoding
                var encoding = DetectEncoding(fileStream);
                if (_options.RequireUtf8 && encoding.EncodingName != Encoding.UTF8.EncodingName)
                {
                    result.Warnings.Add($"File encoding is {encoding.EncodingName}, UTF-8 recommended");
                }

                // Reset stream again
                fileStream.Position = 0;

                // Validate CSV structure
                using var textReader = new StreamReader(fileStream);
                using var csv = new CsvReader(textReader, new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    HasHeaderRecord = true,
                    HeaderValidated = null,
                    MissingFieldFound = null
                });

                await csv.ReadAsync();
                csv.ReadHeader();
                var headers = csv.HeaderRecord;

                if (headers == null || headers.Length == 0)
                {
                    result.IsValid = false;
                    result.Errors.Add("No headers found in CSV file");
                    return result;
                }

                // Validate required columns
                var missingRequired = _requiredColumns.Where(col => 
                    !headers.Contains(col, StringComparer.OrdinalIgnoreCase)).ToList();
                
                if (missingRequired.Any())
                {
                    result.IsValid = false;
                    result.Errors.Add($"Missing required columns: {string.Join(", ", missingRequired)}");
                }

                // Check for duplicate columns
                var duplicates = headers.GroupBy(h => h, StringComparer.OrdinalIgnoreCase)
                    .Where(g => g.Count() > 1)
                    .Select(g => g.Key)
                    .ToList();

                if (duplicates.Any())
                {
                    result.IsValid = false;
                    result.Errors.Add($"Duplicate columns found: {string.Join(", ", duplicates)}");
                }

                // Check for unknown columns
                var knownColumns = _requiredColumns.Concat(_optionalColumns)
                    .Select(c => c.ToLower()).ToHashSet();
                var unknownColumns = headers.Where(h => 
                    !knownColumns.Contains(h.ToLower())).ToList();

                if (unknownColumns.Any() && _options.WarnOnUnknownColumns)
                {
                    result.Warnings.Add($"Unknown columns will be ignored: {string.Join(", ", unknownColumns)}");
                }

                // Validate data rows
                var rowCount = 0;
                var dataErrors = new List<string>();

                while (await csv.ReadAsync() && rowCount < _options.MaxRowsToValidate)
                {
                    rowCount++;
                    
                    if (_options.ValidateDataTypes)
                    {
                        foreach (var header in headers)
                        {
                            if (_columnTypes.TryGetValue(header, out Type expectedType))
                            {
                                var value = csv.GetField(header);
                                if (!IsValidType(value, expectedType))
                                {
                                    dataErrors.Add($"Row {rowCount + 1}: Invalid {expectedType.Name} value in column '{header}'");
                                    if (dataErrors.Count >= _options.MaxErrorsToReport)
                                        break;
                                }
                            }
                        }
                    }

                    if (dataErrors.Count >= _options.MaxErrorsToReport)
                        break;
                }

                result.TotalRows = rowCount;
                result.ColumnCount = headers.Length;
                result.Headers = headers.ToList();

                if (dataErrors.Any())
                {
                    result.DataErrors.AddRange(dataErrors.Take(_options.MaxErrorsToReport));
                    if (dataErrors.Count > _options.MaxErrorsToReport)
                    {
                        result.DataErrors.Add($"... and {dataErrors.Count - _options.MaxErrorsToReport} more errors");
                    }
                }

                // Check for minimum rows
                if (rowCount == 0)
                {
                    result.IsValid = false;
                    result.Errors.Add("No data rows found in CSV file");
                }
                else if (rowCount < _options.MinimumRows)
                {
                    result.Warnings.Add($"File contains only {rowCount} data rows");
                }

                result.Summary = GenerateValidationSummary(result);
            }
            catch (Exception ex)
            {
                result.IsValid = false;
                result.Errors.Add($"Error validating file: {ex.Message}");
            }

            return result;
        }

        public bool ValidateIsActiveFlag(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return false;

            var normalizedValue = value.Trim().ToLower();
            
            return normalizedValue == "0" || normalizedValue == "1" ||
                   normalizedValue == "true" || normalizedValue == "false" ||
                   normalizedValue == "yes" || normalizedValue == "no" ||
                   normalizedValue == "active" || normalizedValue == "inactive";
        }

        public bool ConvertIsActiveFlag(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return true; // Default to active

            var normalizedValue = value.Trim().ToLower();
            
            return normalizedValue == "1" || 
                   normalizedValue == "true" || 
                   normalizedValue == "yes" || 
                   normalizedValue == "active";
        }

        public List<string> ValidateRowData(Dictionary<string, string> rowData, int rowNumber)
        {
            var errors = new List<string>();

            // Check required fields
            foreach (var required in _requiredColumns)
            {
                if (!rowData.ContainsKey(required) || string.IsNullOrWhiteSpace(rowData[required]))
                {
                    errors.Add($"Row {rowNumber}: Missing required field '{required}'");
                }
            }

            // Validate SKU format
            if (rowData.TryGetValue("Sku", out var sku))
            {
                if (!IsValidSku(sku))
                {
                    errors.Add($"Row {rowNumber}: Invalid SKU format '{sku}'");
                }
            }

            // Validate cost price
            if (rowData.TryGetValue("CostPrice", out var costPrice))
            {
                if (!PriceNormalizer.IsPriceValid(costPrice, out _, out var priceError))
                {
                    errors.Add($"Row {rowNumber}: Invalid CostPrice - {priceError}");
                }
            }

            // Validate sell price
            if (rowData.TryGetValue("SellPrice", out var sellPrice))
            {
                if (!PriceNormalizer.IsPriceValid(sellPrice, out _, out var priceError))
                {
                    errors.Add($"Row {rowNumber}: Invalid SellPrice - {priceError}");
                }
            }

            // Validate quantity
            if (rowData.TryGetValue("Qty", out var quantity))
            {
                if (!int.TryParse(quantity, out var qty) || qty < 0)
                {
                    errors.Add($"Row {rowNumber}: Invalid quantity '{quantity}'");
                }
            }

            // Validate CategoryID
            if (rowData.TryGetValue("CategoryID", out var categoryId))
            {
                if (!int.TryParse(categoryId, out var catId) || catId < 0)
                {
                    errors.Add($"Row {rowNumber}: Invalid CategoryID '{categoryId}'");
                }
            }

            // Validate ManufacturerID
            if (rowData.TryGetValue("ManufacturerID", out var manufacturerId))
            {
                if (!int.TryParse(manufacturerId, out var mfgId) || mfgId < 0)
                {
                    errors.Add($"Row {rowNumber}: Invalid ManufacturerID '{manufacturerId}'");
                }
            }

            // Validate Weight
            if (rowData.TryGetValue("Weight", out var weight))
            {
                if (!decimal.TryParse(weight, out var weightValue) || weightValue < 0)
                {
                    errors.Add($"Row {rowNumber}: Invalid Weight '{weight}'");
                }
            }

            // Validate DateCreated
            if (rowData.TryGetValue("DateCreated", out var dateCreated))
            {
                if (!DateParser.TryParseUkDateTime(dateCreated).HasValue)
                {
                    errors.Add($"Row {rowNumber}: Invalid DateCreated format '{dateCreated}'");
                }
            }

            // Validate DateUpdated
            if (rowData.TryGetValue("DateUpdated", out var dateUpdated))
            {
                if (!DateParser.TryParseUkDateTime(dateUpdated).HasValue)
                {
                    errors.Add($"Row {rowNumber}: Invalid DateUpdated format '{dateUpdated}'");
                }
            }

            // Validate IsActive
            if (rowData.TryGetValue("IsActive", out var isActive))
            {
                if (!ValidateIsActiveFlag(isActive))
                {
                    errors.Add($"Row {rowNumber}: Invalid IsActive value '{isActive}'. Use 1/0, true/false, yes/no, or active/inactive");
                }
            }

            return errors;
        }

        private bool IsValidSku(string sku)
        {
            if (string.IsNullOrWhiteSpace(sku))
                return false;

            // SKU validation rules:
            // - Must be between 3 and 50 characters
            // - Can contain letters, numbers, hyphens, and underscores
            // - Cannot start or end with special characters
            var skuPattern = @"^[A-Za-z0-9][A-Za-z0-9\-_]{1,48}[A-Za-z0-9]$";
            
            if (sku.Length < 3)
                return false;

            return Regex.IsMatch(sku, skuPattern);
        }

        private bool IsValidType(string value, Type expectedType)
        {
            if (string.IsNullOrWhiteSpace(value))
                return !_options.TreatEmptyAsInvalid;

            try
            {
                if (expectedType == typeof(string))
                    return true;

                if (expectedType == typeof(int))
                    return int.TryParse(value, out _);

                if (expectedType == typeof(decimal))
                    return PriceNormalizer.TryNormalizePriceString(value).HasValue;

                if (expectedType == typeof(DateTime))
                    return DateParser.TryParseUkDateTime(value).HasValue;

                if (expectedType == typeof(bool))
                    return ValidateIsActiveFlag(value);

                return false;
            }
            catch
            {
                return false;
            }
        }

        private Encoding DetectEncoding(Stream stream)
        {
            var buffer = new byte[4];
            stream.Read(buffer, 0, 4);
            stream.Position = 0;

            // Check for BOM
            if (buffer[0] == 0xef && buffer[1] == 0xbb && buffer[2] == 0xbf)
                return Encoding.UTF8;
            if (buffer[0] == 0xff && buffer[1] == 0xfe)
                return Encoding.Unicode; // UTF-16 LE
            if (buffer[0] == 0xfe && buffer[1] == 0xff)
                return Encoding.BigEndianUnicode; // UTF-16 BE
            if (buffer[0] == 0 && buffer[1] == 0 && buffer[2] == 0xfe && buffer[3] == 0xff)
                return Encoding.UTF32;

            // Default to UTF-8
            return Encoding.UTF8;
        }

        private string GenerateValidationSummary(CsvValidationResult result)
        {
            var summary = new StringBuilder();
            
            summary.AppendLine($"File Validation Summary:");
            summary.AppendLine($"- Valid: {result.IsValid}");
            summary.AppendLine($"- Total Rows: {result.TotalRows}");
            summary.AppendLine($"- Column Count: {result.ColumnCount}");
            
            if (result.Errors.Any())
            {
                summary.AppendLine($"- Errors: {result.Errors.Count}");
            }
            
            if (result.Warnings.Any())
            {
                summary.AppendLine($"- Warnings: {result.Warnings.Count}");
            }
            
            if (result.DataErrors.Any())
            {
                summary.AppendLine($"- Data Errors: {result.DataErrors.Count}");
            }

            return summary.ToString();
        }
    }

    public class CsvValidationResult
    {
        public bool IsValid { get; set; }
        public List<string> Errors { get; set; } = new List<string>();
        public List<string> Warnings { get; set; } = new List<string>();
        public List<string> DataErrors { get; set; } = new List<string>();
        public int TotalRows { get; set; }
        public int ColumnCount { get; set; }
        public List<string> Headers { get; set; } = new List<string>();
        public string Summary { get; set; } = string.Empty;
    }

    public class CsvValidationOptions
    {
        public bool ValidateDataTypes { get; set; } = true;
        public bool RequireUtf8 { get; set; } = false;
        public bool WarnOnUnknownColumns { get; set; } = true;
        public bool TreatEmptyAsInvalid { get; set; } = false;
        public int MaxRowsToValidate { get; set; } = 1000;
        public int MaxErrorsToReport { get; set; } = 100;
        public int MinimumRows { get; set; } = 1;
    }
}