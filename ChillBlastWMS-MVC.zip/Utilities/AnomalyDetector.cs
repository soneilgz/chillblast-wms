using ChillBlastWMS_MVC.Models.Domain;
using ChillBlastWMS_MVC.Models.DTOs;
using System.Text;

namespace ChillBlastWMS_MVC.Utilities
{
    public class AnomalyDetector
    {
        private readonly AnomalyDetectionOptions _options;
        private readonly List<IBusinessRule> _businessRules;

        public AnomalyDetector(AnomalyDetectionOptions? options = null)
        {
            _options = options ?? new AnomalyDetectionOptions();
            _businessRules = InitializeBusinessRules();
        }

        public List<Anomaly> DetectAnomalies(IEnumerable<ProductImportDto> products)
        {
            var anomalies = new List<Anomaly>();
            var productList = products.ToList();
            var rowIndex = 0;

            foreach (var product in productList)
            {
                rowIndex++;
                
                // Check business rules
                foreach (var rule in _businessRules.Where(r => r.IsEnabled))
                {
                    var ruleAnomalies = rule.Check(product, rowIndex);
                    anomalies.AddRange(ruleAnomalies);
                }

                // Check for statistical anomalies
                if (_options.EnableStatisticalAnalysis)
                {
                    var statAnomalies = DetectStatisticalAnomalies(product, productList, rowIndex);
                    anomalies.AddRange(statAnomalies);
                }
            }

            // Check for cross-product anomalies
            if (_options.EnableCrossProductAnalysis)
            {
                var crossAnomalies = DetectCrossProductAnomalies(productList);
                anomalies.AddRange(crossAnomalies);
            }

            return anomalies;
        }

        private List<Anomaly> DetectStatisticalAnomalies(ProductImportDto product, List<ProductImportDto> allProducts, int rowIndex)
        {
            var anomalies = new List<Anomaly>();

            if (allProducts.Count < _options.MinSampleSizeForStatistics)
                return anomalies;

            // Price outliers
            var prices = allProducts.Where(p => p.Price > 0).Select(p => p.Price).ToList();
            if (prices.Any())
            {
                var stats = CalculateStatistics(prices);
                
                if (product.Price > stats.Mean + (_options.OutlierThreshold * stats.StandardDeviation))
                {
                    anomalies.Add(new Anomaly
                    {
                        Type = AnomalyType.StatisticalOutlier,
                        Severity = AnomalySeverity.Medium,
                        Field = "Price",
                        Value = product.Price.ToString("C"),
                        Message = $"Price is {((product.Price - stats.Mean) / stats.StandardDeviation):F1} standard deviations above mean",
                        ProductSKU = product.SKU ?? $"Row {rowIndex}",
                        SuggestedAction = "Verify if price is correct"
                    });
                }
                else if (product.Price < stats.Mean - (_options.OutlierThreshold * stats.StandardDeviation) && product.Price > 0)
                {
                    anomalies.Add(new Anomaly
                    {
                        Type = AnomalyType.StatisticalOutlier,
                        Severity = AnomalySeverity.Medium,
                        Field = "Price",
                        Value = product.Price.ToString("C"),
                        Message = $"Price is {((stats.Mean - product.Price) / stats.StandardDeviation):F1} standard deviations below mean",
                        ProductSKU = product.SKU ?? $"Row {rowIndex}",
                        SuggestedAction = "Verify if price is correct"
                    });
                }
            }

            // Quantity outliers
            var quantities = allProducts.Select(p => (decimal)p.Quantity).ToList();
            if (quantities.Any())
            {
                var stats = CalculateStatistics(quantities);
                
                if (product.Quantity > (int)(stats.Mean + (_options.OutlierThreshold * stats.StandardDeviation)))
                {
                    anomalies.Add(new Anomaly
                    {
                        Type = AnomalyType.StatisticalOutlier,
                        Severity = AnomalySeverity.Low,
                        Field = "Quantity",
                        Value = product.Quantity.ToString(),
                        Message = "Unusually high quantity compared to other products",
                        ProductSKU = product.SKU ?? $"Row {rowIndex}",
                        SuggestedAction = "Verify quantity is correct"
                    });
                }
            }

            return anomalies;
        }

        private List<Anomaly> DetectCrossProductAnomalies(List<ProductImportDto> products)
        {
            var anomalies = new List<Anomaly>();

            // Group by category and check for price inconsistencies
            var categoryGroups = products
                .Where(p => !string.IsNullOrWhiteSpace(p.Category))
                .GroupBy(p => p.Category);

            foreach (var group in categoryGroups)
            {
                if (group.Count() < 2) continue;

                var prices = group.Select(p => p.Price).ToList();
                var stats = CalculateStatistics(prices);

                // Check coefficient of variation
                if (stats.StandardDeviation > 0 && stats.Mean > 0)
                {
                    var coefficientOfVariation = stats.StandardDeviation / stats.Mean;
                    
                    if (coefficientOfVariation > _options.MaxCoefficientOfVariation)
                    {
                        anomalies.Add(new Anomaly
                        {
                            Type = AnomalyType.CategoryInconsistency,
                            Severity = AnomalySeverity.Low,
                            Field = "Category",
                            Value = group.Key,
                            Message = $"High price variation in category '{group.Key}' (CV: {coefficientOfVariation:P})",
                            SuggestedAction = "Review category pricing consistency"
                        });
                    }
                }
            }

            // Check for suspiciously similar products
            for (int i = 0; i < products.Count - 1; i++)
            {
                for (int j = i + 1; j < products.Count; j++)
                {
                    var p1 = products[i];
                    var p2 = products[j];

                    // Skip if same SKU
                    if (string.Equals(p1.SKU, p2.SKU, StringComparison.OrdinalIgnoreCase))
                        continue;

                    // Check if products are too similar
                    if (AreSuspiciouslySimilar(p1, p2))
                    {
                        anomalies.Add(new Anomaly
                        {
                            Type = AnomalyType.PossibleDuplicate,
                            Severity = AnomalySeverity.Medium,
                            Field = "Multiple",
                            Message = $"Products '{p1.SKU}' and '{p2.SKU}' are suspiciously similar",
                            ProductSKU = $"{p1.SKU}, {p2.SKU}",
                            SuggestedAction = "Verify if these are distinct products or duplicates"
                        });
                    }
                }
            }

            return anomalies;
        }

        private bool AreSuspiciouslySimilar(ProductImportDto p1, ProductImportDto p2)
        {
            int similarityScore = 0;

            // Same name
            if (string.Equals(p1.Name, p2.Name, StringComparison.OrdinalIgnoreCase))
                similarityScore += 3;

            // Same price
            if (Math.Abs(p1.Price - p2.Price) < 0.01m)
                similarityScore += 2;

            // Same category
            if (string.Equals(p1.Category, p2.Category, StringComparison.OrdinalIgnoreCase))
                similarityScore += 1;

            // Same quantity
            if (p1.Quantity == p2.Quantity && p1.Quantity > 0)
                similarityScore += 1;

            // Same supplier
            if (!string.IsNullOrWhiteSpace(p1.Supplier) && 
                string.Equals(p1.Supplier, p2.Supplier, StringComparison.OrdinalIgnoreCase))
                similarityScore += 1;

            return similarityScore >= _options.SimilarityScoreThreshold;
        }

        private Statistics CalculateStatistics(List<decimal> values)
        {
            var stats = new Statistics();
            
            if (!values.Any())
                return stats;

            stats.Mean = values.Average();
            stats.Median = GetMedian(values);
            
            var variance = values.Select(v => Math.Pow((double)(v - stats.Mean), 2)).Average();
            stats.StandardDeviation = (decimal)Math.Sqrt(variance);
            
            stats.Min = values.Min();
            stats.Max = values.Max();

            return stats;
        }

        private decimal GetMedian(List<decimal> values)
        {
            var sorted = values.OrderBy(v => v).ToList();
            int count = sorted.Count;
            
            if (count == 0)
                return 0;

            if (count % 2 == 0)
                return (sorted[count / 2 - 1] + sorted[count / 2]) / 2;
            else
                return sorted[count / 2];
        }

        private List<IBusinessRule> InitializeBusinessRules()
        {
            return new List<IBusinessRule>
            {
                new NegativePriceRule(),
                new NegativeQuantityRule(),
                new MissingSKURule(),
                new InvalidSKUFormatRule(),
                new ZeroPriceActiveProductRule(),
                new SuspiciouslyHighPriceRule(_options.MaxReasonablePrice),
                new EmptyNameRule(),
                new InvalidCategoryRule()
            };
        }
    }

    public class Anomaly
    {
        public AnomalyType Type { get; set; }
        public AnomalySeverity Severity { get; set; }
        public string Field { get; set; } = string.Empty;
        public string Value { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public string ProductSKU { get; set; } = string.Empty;
        public string SuggestedAction { get; set; } = string.Empty;
        public DateTime DetectedAt { get; set; } = DateTime.UtcNow;
    }

    public enum AnomalyType
    {
        MissingData,
        InvalidFormat,
        NegativeValue,
        StatisticalOutlier,
        BusinessRuleViolation,
        NegativeMargin,
        PriceAnomaly,
        QuantityAnomaly,
        ConfigurationError,
        PossibleDuplicate,
        CategoryInconsistency,
        DataTypeError
    }

    public enum AnomalySeverity
    {
        Low,
        Medium,
        High,
        Critical
    }

    public class AnomalyDetectionOptions
    {
        public bool EnableStatisticalAnalysis { get; set; } = true;
        public bool EnableCrossProductAnalysis { get; set; } = true;
        public int MinSampleSizeForStatistics { get; set; } = 10;
        public decimal OutlierThreshold { get; set; } = 3.0m; // Standard deviations
        public decimal MaxCoefficientOfVariation { get; set; } = 1.0m;
        public int SimilarityScoreThreshold { get; set; } = 5;
        public decimal MaxReasonablePrice { get; set; } = 100000m;
    }

    public interface IBusinessRule
    {
        bool IsEnabled { get; }
        List<Anomaly> Check(ProductImportDto product, int rowIndex);
    }

    public class NegativePriceRule : IBusinessRule
    {
        public bool IsEnabled => true;
        
        public List<Anomaly> Check(ProductImportDto product, int rowIndex)
        {
            var anomalies = new List<Anomaly>();
            
            if (product.Price < 0)
            {
                anomalies.Add(new Anomaly
                {
                    Type = AnomalyType.NegativeValue,
                    Severity = AnomalySeverity.Critical,
                    Field = "Price",
                    Value = product.Price.ToString("C"),
                    Message = "Price cannot be negative",
                    ProductSKU = product.SKU ?? $"Row {rowIndex}",
                    SuggestedAction = "Correct the price value"
                });
            }
            
            return anomalies;
        }
    }

    public class NegativeQuantityRule : IBusinessRule
    {
        public bool IsEnabled => true;
        
        public List<Anomaly> Check(ProductImportDto product, int rowIndex)
        {
            var anomalies = new List<Anomaly>();
            
            if (product.Quantity < 0)
            {
                anomalies.Add(new Anomaly
                {
                    Type = AnomalyType.NegativeValue,
                    Severity = AnomalySeverity.High,
                    Field = "Quantity",
                    Value = product.Quantity.ToString(),
                    Message = "Quantity cannot be negative",
                    ProductSKU = product.SKU ?? $"Row {rowIndex}",
                    SuggestedAction = "Correct the quantity value"
                });
            }
            
            return anomalies;
        }
    }

    public class MissingSKURule : IBusinessRule
    {
        public bool IsEnabled => true;
        
        public List<Anomaly> Check(ProductImportDto product, int rowIndex)
        {
            var anomalies = new List<Anomaly>();
            
            if (string.IsNullOrWhiteSpace(product.SKU))
            {
                anomalies.Add(new Anomaly
                {
                    Type = AnomalyType.MissingData,
                    Severity = AnomalySeverity.Critical,
                    Field = "SKU",
                    Message = "SKU is required",
                    ProductSKU = $"Row {rowIndex}",
                    SuggestedAction = "Provide a unique SKU"
                });
            }
            
            return anomalies;
        }
    }

    public class InvalidSKUFormatRule : IBusinessRule
    {
        public bool IsEnabled => true;
        
        public List<Anomaly> Check(ProductImportDto product, int rowIndex)
        {
            var anomalies = new List<Anomaly>();
            
            if (!string.IsNullOrWhiteSpace(product.SKU))
            {
                // Check for invalid characters
                if (product.SKU.Contains(" ") || product.SKU.Contains("\t"))
                {
                    anomalies.Add(new Anomaly
                    {
                        Type = AnomalyType.InvalidFormat,
                        Severity = AnomalySeverity.Medium,
                        Field = "SKU",
                        Value = product.SKU,
                        Message = "SKU contains whitespace",
                        ProductSKU = product.SKU,
                        SuggestedAction = "Remove whitespace from SKU"
                    });
                }
                
                // Check length
                if (product.SKU.Length > 50)
                {
                    anomalies.Add(new Anomaly
                    {
                        Type = AnomalyType.InvalidFormat,
                        Severity = AnomalySeverity.Medium,
                        Field = "SKU",
                        Value = product.SKU,
                        Message = "SKU exceeds maximum length of 50 characters",
                        ProductSKU = product.SKU,
                        SuggestedAction = "Shorten the SKU"
                    });
                }
            }
            
            return anomalies;
        }
    }

    public class ZeroPriceActiveProductRule : IBusinessRule
    {
        public bool IsEnabled => true;
        
        public List<Anomaly> Check(ProductImportDto product, int rowIndex)
        {
            var anomalies = new List<Anomaly>();
            
            if (product.Price == 0)
            {
                anomalies.Add(new Anomaly
                {
                    Type = AnomalyType.PriceAnomaly,
                    Severity = AnomalySeverity.High,
                    Field = "Price",
                    Value = "0",
                    Message = "Product has zero price",
                    ProductSKU = product.SKU ?? $"Row {rowIndex}",
                    SuggestedAction = "Set appropriate price"
                });
            }
            
            return anomalies;
        }
    }

    public class SuspiciouslyHighPriceRule : IBusinessRule
    {
        private readonly decimal _maxPrice;
        
        public SuspiciouslyHighPriceRule(decimal maxPrice)
        {
            _maxPrice = maxPrice;
        }
        
        public bool IsEnabled => true;
        
        public List<Anomaly> Check(ProductImportDto product, int rowIndex)
        {
            var anomalies = new List<Anomaly>();
            
            if (product.Price > _maxPrice)
            {
                anomalies.Add(new Anomaly
                {
                    Type = AnomalyType.PriceAnomaly,
                    Severity = AnomalySeverity.High,
                    Field = "Price",
                    Value = product.Price.ToString("C"),
                    Message = $"Price exceeds maximum reasonable value of {_maxPrice:C}",
                    ProductSKU = product.SKU ?? $"Row {rowIndex}",
                    SuggestedAction = "Verify price is correct"
                });
            }
            
            return anomalies;
        }
    }

    public class EmptyNameRule : IBusinessRule
    {
        public bool IsEnabled => true;
        
        public List<Anomaly> Check(ProductImportDto product, int rowIndex)
        {
            var anomalies = new List<Anomaly>();
            
            if (string.IsNullOrWhiteSpace(product.Name))
            {
                anomalies.Add(new Anomaly
                {
                    Type = AnomalyType.MissingData,
                    Severity = AnomalySeverity.High,
                    Field = "Name",
                    Message = "Product name is required",
                    ProductSKU = product.SKU ?? $"Row {rowIndex}",
                    SuggestedAction = "Provide product name"
                });
            }
            
            return anomalies;
        }
    }

    public class InvalidCategoryRule : IBusinessRule
    {
        public bool IsEnabled => true;
        
        public List<Anomaly> Check(ProductImportDto product, int rowIndex)
        {
            var anomalies = new List<Anomaly>();
            
            if (!string.IsNullOrWhiteSpace(product.Category) && product.Category.Length > 100)
            {
                anomalies.Add(new Anomaly
                {
                    Type = AnomalyType.InvalidFormat,
                    Severity = AnomalySeverity.Low,
                    Field = "Category",
                    Value = product.Category,
                    Message = "Category name exceeds 100 characters",
                    ProductSKU = product.SKU ?? $"Row {rowIndex}",
                    SuggestedAction = "Shorten category name"
                });
            }
            
            return anomalies;
        }
    }

    public class Statistics
    {
        public decimal Mean { get; set; }
        public decimal Median { get; set; }
        public decimal StandardDeviation { get; set; }
        public decimal Min { get; set; }
        public decimal Max { get; set; }
    }
}