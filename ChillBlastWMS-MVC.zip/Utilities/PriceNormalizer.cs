using System.Globalization;
using System.Text.RegularExpressions;

namespace ChillBlastWMS_MVC.Utilities
{
    public static class PriceNormalizer
    {
        private static readonly Regex CurrencySymbolRegex = new Regex(@"[£$€¥₹¢]", RegexOptions.Compiled);
        private static readonly Regex NonNumericRegex = new Regex(@"[^\d\.\-,]", RegexOptions.Compiled);
        private static readonly Regex MultipleDotsRegex = new Regex(@"\.{2,}", RegexOptions.Compiled);
        private static readonly Regex WhitespaceRegex = new Regex(@"\s+", RegexOptions.Compiled);

        public static decimal NormalizePriceString(string priceString)
        {
            if (string.IsNullOrWhiteSpace(priceString))
                return 0m;

            try
            {
                // Store original for logging
                var original = priceString;

                // Remove all whitespace
                priceString = WhitespaceRegex.Replace(priceString, "");

                // Handle special cases
                if (priceString.Equals("N/A", StringComparison.OrdinalIgnoreCase) ||
                    priceString.Equals("NA", StringComparison.OrdinalIgnoreCase) ||
                    priceString.Equals("-", StringComparison.OrdinalIgnoreCase))
                {
                    return 0m;
                }

                // Remove currency symbols
                priceString = CurrencySymbolRegex.Replace(priceString, "");

                // Handle parentheses for negative values (accounting format)
                bool isNegative = false;
                if (priceString.StartsWith("(") && priceString.EndsWith(")"))
                {
                    isNegative = true;
                    priceString = priceString.Trim('(', ')');
                }

                // Detect number format (European vs US/UK)
                var format = DetectNumberFormat(priceString);

                // Normalize based on detected format
                priceString = NormalizeByFormat(priceString, format);

                // Remove any remaining non-numeric characters except dot and minus
                priceString = Regex.Replace(priceString, @"[^\d\.\-]", "");

                // Handle multiple dots (keep only first as decimal separator)
                if (priceString.Count(c => c == '.') > 1)
                {
                    var parts = priceString.Split('.');
                    priceString = string.Join("", parts.Take(parts.Length - 1)) + "." + parts.Last();
                }

                // Parse the decimal
                if (decimal.TryParse(priceString, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, 
                    CultureInfo.InvariantCulture, out decimal result))
                {
                    return isNegative ? -Math.Abs(result) : result;
                }

                // If parsing fails, try with current culture
                if (decimal.TryParse(priceString, NumberStyles.Currency, 
                    CultureInfo.CurrentCulture, out result))
                {
                    return isNegative ? -Math.Abs(result) : result;
                }

                return 0m;
            }
            catch
            {
                return 0m;
            }
        }

        public static (decimal Price, string Currency) ExtractPriceAndCurrency(string priceString)
        {
            if (string.IsNullOrWhiteSpace(priceString))
                return (0m, "GBP");

            string currency = "GBP"; // Default currency

            // Detect currency symbol
            if (priceString.Contains("£"))
                currency = "GBP";
            else if (priceString.Contains("$"))
                currency = "USD";
            else if (priceString.Contains("€"))
                currency = "EUR";
            else if (priceString.Contains("¥"))
                currency = "JPY";
            else if (priceString.Contains("₹"))
                currency = "INR";

            decimal price = NormalizePriceString(priceString);
            return (price, currency);
        }

        public static string FormatPrice(decimal price, string currency = "GBP")
        {
            var cultureInfo = currency switch
            {
                "USD" => new CultureInfo("en-US"),
                "EUR" => new CultureInfo("fr-FR"),
                "JPY" => new CultureInfo("ja-JP"),
                "INR" => new CultureInfo("hi-IN"),
                _ => new CultureInfo("en-GB")
            };

            return price.ToString("C", cultureInfo);
        }

        public static bool ValidatePriceRange(decimal price, decimal? minPrice = null, decimal? maxPrice = null)
        {
            if (price < 0)
                return false;

            if (minPrice.HasValue && price < minPrice.Value)
                return false;

            if (maxPrice.HasValue && price > maxPrice.Value)
                return false;

            return true;
        }

        public static List<string> DetectFormatInconsistencies(IEnumerable<string> priceStrings)
        {
            var inconsistencies = new List<string>();
            var formats = new HashSet<string>();
            var currencies = new HashSet<string>();

            foreach (var priceString in priceStrings.Where(p => !string.IsNullOrWhiteSpace(p)))
            {
                // Detect currency
                if (priceString.Contains("£")) currencies.Add("GBP");
                else if (priceString.Contains("$")) currencies.Add("USD");
                else if (priceString.Contains("€")) currencies.Add("EUR");

                // Detect format
                var format = DetectNumberFormat(priceString);
                formats.Add(format.ToString());
            }

            if (currencies.Count > 1)
            {
                inconsistencies.Add($"Mixed currencies detected: {string.Join(", ", currencies)}");
            }

            if (formats.Count > 1)
            {
                inconsistencies.Add($"Mixed number formats detected: {string.Join(", ", formats)}");
            }

            return inconsistencies;
        }

        private enum NumberFormat
        {
            USUk,      // 1,234.56
            European,  // 1.234,56
            Unknown
        }

        private static NumberFormat DetectNumberFormat(string numberString)
        {
            // Remove currency symbols and whitespace for analysis
            var cleaned = CurrencySymbolRegex.Replace(numberString, "").Trim();

            // Check for comma and dot positions
            int lastCommaIndex = cleaned.LastIndexOf(',');
            int lastDotIndex = cleaned.LastIndexOf('.');

            if (lastCommaIndex == -1 && lastDotIndex == -1)
            {
                // No separators, assume US/UK
                return NumberFormat.USUk;
            }

            if (lastCommaIndex > lastDotIndex)
            {
                // Comma after dot (1.234,56) - European format
                if (lastDotIndex > 0 && cleaned.Substring(lastCommaIndex + 1).Length <= 2)
                {
                    return NumberFormat.European;
                }
            }
            else if (lastDotIndex > lastCommaIndex)
            {
                // Dot after comma (1,234.56) - US/UK format
                if (lastCommaIndex > 0 && cleaned.Substring(lastDotIndex + 1).Length <= 2)
                {
                    return NumberFormat.USUk;
                }
            }

            // Check for patterns
            if (Regex.IsMatch(cleaned, @"^\d{1,3}(,\d{3})*(\.\d+)?$"))
            {
                // US/UK format: 1,234,567.89
                return NumberFormat.USUk;
            }

            if (Regex.IsMatch(cleaned, @"^\d{1,3}(\.\d{3})*(,\d+)?$"))
            {
                // European format: 1.234.567,89
                return NumberFormat.European;
            }

            // Default to US/UK
            return NumberFormat.USUk;
        }

        private static string NormalizeByFormat(string numberString, NumberFormat format)
        {
            switch (format)
            {
                case NumberFormat.European:
                    // Replace dots with nothing (thousand separator)
                    // Replace comma with dot (decimal separator)
                    numberString = numberString.Replace(".", "");
                    numberString = numberString.Replace(",", ".");
                    break;

                case NumberFormat.USUk:
                default:
                    // Remove commas (thousand separator)
                    // Keep dots as decimal separator
                    numberString = numberString.Replace(",", "");
                    break;
            }

            return numberString;
        }

        public static decimal? TryNormalizePriceString(string priceString)
        {
            try
            {
                var result = NormalizePriceString(priceString);
                return result;
            }
            catch
            {
                return null;
            }
        }

        public static bool IsPriceValid(string priceString, out decimal price, out string errorMessage)
        {
            price = 0m;
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(priceString))
            {
                errorMessage = "Price is empty or null";
                return false;
            }

            try
            {
                price = NormalizePriceString(priceString);
                
                if (price < 0)
                {
                    errorMessage = "Price cannot be negative";
                    return false;
                }

                if (price > 1000000m)
                {
                    errorMessage = "Price exceeds maximum allowed value";
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                errorMessage = $"Invalid price format: {ex.Message}";
                return false;
            }
        }
    }
}