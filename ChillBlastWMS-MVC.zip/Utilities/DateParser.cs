using System.Globalization;
using System.Text.RegularExpressions;

namespace ChillBlastWMS_MVC.Utilities
{
    public static class DateParser
    {
        private static readonly string[] UkDateFormats = new[]
        {
            "dd/MM/yyyy HH:mm",
            "dd/MM/yyyy HH:mm:ss",
            "dd/MM/yyyy H:mm",
            "dd/MM/yyyy H:mm:ss",
            "d/M/yyyy HH:mm",
            "d/M/yyyy HH:mm:ss",
            "dd-MM-yyyy HH:mm",
            "dd-MM-yyyy HH:mm:ss",
            "dd.MM.yyyy HH:mm",
            "dd.MM.yyyy HH:mm:ss",
            "dd/MM/yyyy",
            "d/M/yyyy",
            "dd-MM-yyyy",
            "dd.MM.yyyy"
        };

        private static readonly string[] UsDateFormats = new[]
        {
            "MM/dd/yyyy HH:mm",
            "MM/dd/yyyy HH:mm:ss",
            "M/d/yyyy HH:mm",
            "M/d/yyyy HH:mm:ss",
            "MM-dd-yyyy HH:mm",
            "MM-dd-yyyy HH:mm:ss",
            "MM/dd/yyyy",
            "M/d/yyyy",
            "MM-dd-yyyy"
        };

        private static readonly string[] IsoDateFormats = new[]
        {
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-ddTHH:mm:ss",
            "yyyy-MM-dd HH:mm",
            "yyyy-MM-ddTHH:mm",
            "yyyy-MM-dd",
            "yyyyMMdd"
        };

        private static readonly string[] ExcelDateFormats = new[]
        {
            "M/d/yyyy h:mm:ss tt",
            "M/d/yyyy h:mm tt",
            "MM/dd/yyyy hh:mm:ss tt",
            "MM/dd/yyyy hh:mm tt"
        };

        public static DateTime ParseUkDateTime(string dateString)
        {
            if (string.IsNullOrWhiteSpace(dateString))
                throw new ArgumentException("Date string cannot be null or empty");

            dateString = dateString.Trim();

            // Try UK formats first
            if (TryParseWithFormats(dateString, UkDateFormats, out DateTime result))
                return result;

            // Try ISO formats
            if (TryParseWithFormats(dateString, IsoDateFormats, out result))
                return result;

            // Try standard parse as last resort
            if (DateTime.TryParse(dateString, CultureInfo.GetCultureInfo("en-GB"), 
                DateTimeStyles.None, out result))
                return result;

            throw new FormatException($"Unable to parse date: {dateString}");
        }

        public static DateTime? TryParseUkDateTime(string dateString)
        {
            try
            {
                return ParseUkDateTime(dateString);
            }
            catch
            {
                return null;
            }
        }

        public static DateTime ParseFlexibleDateTime(string dateString, DateFormat preferredFormat = DateFormat.UK)
        {
            if (string.IsNullOrWhiteSpace(dateString))
                throw new ArgumentException("Date string cannot be null or empty");

            dateString = NormalizeDateString(dateString);

            // Try preferred format first
            var formats = GetFormatsForPreference(preferredFormat);
            if (TryParseWithFormats(dateString, formats, out DateTime result))
                return result;

            // Try all other formats
            var allFormats = UkDateFormats
                .Concat(UsDateFormats)
                .Concat(IsoDateFormats)
                .Concat(ExcelDateFormats)
                .Distinct()
                .ToArray();

            if (TryParseWithFormats(dateString, allFormats, out result))
                return result;

            // Try Excel serial number
            if (TryParseExcelSerialDate(dateString, out result))
                return result;

            // Try standard parse with multiple cultures
            foreach (var culture in new[] { "en-GB", "en-US", "fr-FR", "de-DE" })
            {
                if (DateTime.TryParse(dateString, CultureInfo.GetCultureInfo(culture), 
                    DateTimeStyles.None, out result))
                    return result;
            }

            throw new FormatException($"Unable to parse date: {dateString}");
        }

        public static DateFormat DetectDateFormat(string dateString)
        {
            if (string.IsNullOrWhiteSpace(dateString))
                return DateFormat.Unknown;

            dateString = dateString.Trim();

            // Check for ISO format (yyyy-MM-dd)
            if (Regex.IsMatch(dateString, @"^\d{4}[-/]\d{1,2}[-/]\d{1,2}"))
                return DateFormat.ISO;

            // Check for US format (MM/dd/yyyy or M/d/yyyy)
            if (TryParseWithFormats(dateString, UsDateFormats, out _))
            {
                // Additional check: if day > 12, it's likely UK format
                var parts = dateString.Split(new[] { '/', '-', '.' }, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 2 && int.TryParse(parts[0], out int firstPart) && firstPart > 12)
                    return DateFormat.UK;
                
                return DateFormat.US;
            }

            // Check for UK format (dd/MM/yyyy or d/M/yyyy)
            if (TryParseWithFormats(dateString, UkDateFormats, out _))
                return DateFormat.UK;

            return DateFormat.Unknown;
        }

        private static bool TryParseWithFormats(string dateString, string[] formats, out DateTime result)
        {
            return DateTime.TryParseExact(dateString, formats, 
                CultureInfo.InvariantCulture, DateTimeStyles.None, out result);
        }

        private static bool TryParseExcelSerialDate(string dateString, out DateTime result)
        {
            result = default;

            if (double.TryParse(dateString, out double serialDate))
            {
                // Excel serial dates start from 1900-01-01 (actually 1899-12-30 due to a bug)
                if (serialDate >= 1 && serialDate <= 2958465) // Valid Excel date range
                {
                    result = new DateTime(1899, 12, 30).AddDays(serialDate);
                    return true;
                }
            }

            return false;
        }

        private static string NormalizeDateString(string dateString)
        {
            // Remove extra whitespace
            dateString = Regex.Replace(dateString.Trim(), @"\s+", " ");

            // Standardize separators (convert all to /)
            dateString = dateString.Replace('.', '/').Replace('-', '/');

            // Remove timezone information for simpler parsing
            dateString = Regex.Replace(dateString, @"\s*\(.*?\)\s*$", "");
            dateString = Regex.Replace(dateString, @"\s*[A-Z]{3,4}\s*$", "");

            return dateString;
        }

        private static string[] GetFormatsForPreference(DateFormat format)
        {
            return format switch
            {
                DateFormat.UK => UkDateFormats,
                DateFormat.US => UsDateFormats,
                DateFormat.ISO => IsoDateFormats,
                _ => UkDateFormats
            };
        }
    }

    public enum DateFormat
    {
        UK,
        US,
        ISO,
        Unknown
    }
}