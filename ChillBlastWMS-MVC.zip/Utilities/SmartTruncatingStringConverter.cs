using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using System.Net;
using System.Text.RegularExpressions;

namespace ChillBlastWMS_MVC.Utilities
{
    public class SmartTruncatingStringConverter : ITypeConverter
    {
        private readonly int _maxLength;
        private readonly string _fieldName;

        public SmartTruncatingStringConverter(int maxLength, string fieldName = "")
        {
            _maxLength = maxLength;
            _fieldName = fieldName;
        }

        public object ConvertFromString(string text, IReaderRow row, MemberMapData memberMapData)
        {
            if (string.IsNullOrWhiteSpace(text))
                return string.Empty;

            text = text.Trim();

            // TIER 4: DATA QUALITY AUTO-FIXES (NORMALIZE)
            text = WebUtility.HtmlDecode(text);

            // Remove HTML tags but preserve content for non-Summary fields
            if (!string.Equals(_fieldName, "Summary", StringComparison.OrdinalIgnoreCase))
            {
                text = Regex.Replace(text, @"<[^>]+>", " ", RegexOptions.IgnoreCase);
                text = Regex.Replace(text, @"\s+", " ");
            }

            // Clean up and normalize
            text = text.Trim();

            // FIELD LENGTH VALIDATION & HANDLING
            if (text.Length <= _maxLength)
                return text;

            // Smart truncation logic - preserve meaningful parts
            var truncated = SmartTruncate(text, _maxLength);
            
            // Note: Truncation logging is handled at the service level
            // The truncation itself works regardless of logging capability

            return truncated;
        }

        public string ConvertToString(object value, IWriterRow row, MemberMapData memberMapData)
        {
            if (value == null)
                return string.Empty;

            return value.ToString() ?? string.Empty;
        }

        private string SmartTruncate(string text, int maxLength)
        {
            if (text.Length <= maxLength)
                return text;

            // Smart truncation strategies based on field type
            switch (_fieldName.ToLower())
            {
                case "name":
                    return TruncateProductName(text, maxLength);
                case "description":
                case "summary":
                    return TruncateDescription(text, maxLength);
                default:
                    return TruncateGeneric(text, maxLength);
            }
        }

        private string TruncateProductName(string text, int maxLength)
        {
            // For product names, try to preserve the most important parts
            // Strategy: Keep brand, model, and key specs
            
            // If it contains specifications in parentheses, try to remove less important ones first
            var parenthesesPattern = @"\([^)]*\)";
            var matches = Regex.Matches(text, parenthesesPattern);
            
            if (matches.Count > 0 && text.Length > maxLength)
            {
                // Remove parentheses content starting from the end
                var workingText = text;
                for (int i = matches.Count - 1; i >= 0 && workingText.Length > maxLength; i--)
                {
                    var match = matches[i];
                    // Only remove if it's not the first parentheses (might contain important model info)
                    if (i > 0)
                    {
                        workingText = workingText.Remove(match.Index, match.Length).Trim();
                        workingText = Regex.Replace(workingText, @"\s+", " "); // Clean up extra spaces
                    }
                }
                
                if (workingText.Length <= maxLength)
                    return workingText;
            }

            // If still too long, try to preserve brand and model, remove descriptive words
            var words = text.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (words.Length > 3)
            {
                // Keep first 2-3 words (usually brand and model) and last word (usually size/type)
                var preserved = new List<string> { words[0], words[1] };
                if (words.Length > 2)
                    preserved.Add(words[^1]); // Last word
                
                var result = string.Join(" ", preserved);
                if (result.Length <= maxLength)
                    return result;
            }

            // Fallback: simple truncation with ellipsis
            return TruncateGeneric(text, maxLength);
        }

        private string TruncateDescription(string text, int maxLength)
        {
            // For descriptions, try to truncate at sentence boundaries
            var sentences = text.Split('.', StringSplitOptions.RemoveEmptyEntries);
            if (sentences.Length > 1)
            {
                var result = "";
                foreach (var sentence in sentences)
                {
                    var testResult = result + sentence.Trim() + ". ";
                    if (testResult.Length > maxLength - 3) // Leave room for ellipsis
                        break;
                    result = testResult;
                }
                
                if (result.Length > 0)
                    return result.Trim() + "...";
            }

            // Fallback to word boundary truncation
            return TruncateAtWordBoundary(text, maxLength);
        }

        private string TruncateGeneric(string text, int maxLength)
        {
            return TruncateAtWordBoundary(text, maxLength);
        }

        private string TruncateAtWordBoundary(string text, int maxLength)
        {
            if (maxLength <= 3)
                return text.Substring(0, maxLength);

            if (text.Length <= maxLength)
                return text;

            // Try to truncate at word boundary
            var truncated = text.Substring(0, maxLength - 3);
            var lastSpace = truncated.LastIndexOf(' ');
            
            if (lastSpace > maxLength / 2) // Only use word boundary if it's not too far back
            {
                return truncated.Substring(0, lastSpace) + "...";
            }
            
            // Hard truncation with ellipsis
            return text.Substring(0, maxLength - 3) + "...";
        }
    }
}