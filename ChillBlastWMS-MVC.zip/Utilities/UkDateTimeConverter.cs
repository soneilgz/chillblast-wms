using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using System.Globalization;

namespace ChillBlastWMS_MVC.Utilities
{
    public class UkDateTimeConverter : ITypeConverter
    {
        private readonly string[] _formats = new[]
        {
            "dd/MM/yyyy HH:mm",
            "dd/MM/yyyy H:mm",
            "dd/MM/yyyy",
            "d/MM/yyyy HH:mm",
            "d/MM/yyyy H:mm",
            "d/MM/yyyy",
            "dd/M/yyyy HH:mm",
            "dd/M/yyyy H:mm",
            "dd/M/yyyy",
            "d/M/yyyy HH:mm",
            "d/M/yyyy H:mm",
            "d/M/yyyy",
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd HH:mm",
            "yyyy-MM-dd",
            "MM/dd/yyyy HH:mm",
            "MM/dd/yyyy H:mm",
            "MM/dd/yyyy"
        };

        public object ConvertFromString(string text, IReaderRow row, MemberMapData memberMapData)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                if (memberMapData.Member.MemberType() == typeof(DateTime?))
                    return null;
                return default(DateTime);
            }

            text = text.Trim();

            // Try each format
            foreach (var format in _formats)
            {
                if (DateTime.TryParseExact(text, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime result))
                {
                    return result;
                }
            }

            // If all specific formats fail, try general parsing
            if (DateTime.TryParse(text, CultureInfo.CreateSpecificCulture("en-GB"), DateTimeStyles.None, out DateTime generalResult))
            {
                return generalResult;
            }

            // Last resort - try invariant culture
            if (DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime invariantResult))
            {
                return invariantResult;
            }

            throw new TypeConverterException(this, memberMapData, text, row.Context, 
                $"Unable to convert '{text}' to DateTime. Supported formats: {string.Join(", ", _formats)}");
        }

        public string ConvertToString(object value, IWriterRow row, MemberMapData memberMapData)
        {
            if (value == null)
                return string.Empty;

            if (value is DateTime dateTime)
            {
                return dateTime.ToString("dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
            }

            return value.ToString() ?? string.Empty;
        }
    }
}