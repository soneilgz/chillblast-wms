using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using System.Globalization;
using System.Text.RegularExpressions;

namespace ChillBlastWMS_MVC.Utilities
{
    public class CurrencyDecimalConverter : ITypeConverter
    {
        private readonly string[] _currencySymbols = { "£", "$", "€", "¥", "₹", "₦", "₽", "¢", "¤" };

        public object ConvertFromString(string text, IReaderRow row, MemberMapData memberMapData)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                if (memberMapData.Member.MemberType() == typeof(decimal?))
                    return null;
                return 0m;
            }

            text = text.Trim();

            // Remove currency symbols
            foreach (var symbol in _currencySymbols)
            {
                text = text.Replace(symbol, "");
            }

            // Remove common currency codes
            text = Regex.Replace(text, @"\b(USD|GBP|EUR|JPY|INR|NGN|RUB)\b", "", RegexOptions.IgnoreCase);

            // Remove any remaining non-numeric characters except decimal points, commas, and minus signs
            text = Regex.Replace(text, @"[^\d\.\,\-]", "");

            // Handle different decimal separators
            // If there are multiple commas or periods, assume the last one is the decimal separator
            if (text.Contains(",") && text.Contains("."))
            {
                // European format like 1.234,56 or US format like 1,234.56
                int lastCommaIndex = text.LastIndexOf(',');
                int lastPeriodIndex = text.LastIndexOf('.');
                
                if (lastPeriodIndex > lastCommaIndex)
                {
                    // US format: 1,234.56 - remove commas
                    text = text.Replace(",", "");
                }
                else
                {
                    // European format: 1.234,56 - remove periods and replace comma with period
                    text = text.Replace(".", "").Replace(",", ".");
                }
            }
            else if (text.Contains(","))
            {
                // Could be either thousand separator or decimal separator
                // If there are digits after the last comma and they are 2 or 3 digits, it's likely decimal
                int lastCommaIndex = text.LastIndexOf(',');
                string afterLastComma = text.Substring(lastCommaIndex + 1);
                
                if (afterLastComma.Length <= 3 && afterLastComma.Length > 0)
                {
                    // Likely decimal separator
                    text = text.Replace(",", ".");
                }
                else
                {
                    // Likely thousand separator
                    text = text.Replace(",", "");
                }
            }

            text = text.Trim();

            if (string.IsNullOrEmpty(text))
            {
                if (memberMapData.Member.MemberType() == typeof(decimal?))
                    return null;
                return 0m;
            }

            // Try to parse as decimal
            if (decimal.TryParse(text, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out decimal result))
            {
                return result;
            }

            // Try with different cultures
            var cultures = new[] 
            { 
                CultureInfo.CreateSpecificCulture("en-US"),
                CultureInfo.CreateSpecificCulture("en-GB"),
                CultureInfo.CreateSpecificCulture("en-AU"),
                CultureInfo.CreateSpecificCulture("de-DE"),
                CultureInfo.CreateSpecificCulture("fr-FR")
            };

            foreach (var culture in cultures)
            {
                if (decimal.TryParse(text, NumberStyles.Currency | NumberStyles.Number, culture, out decimal cultureResult))
                {
                    return cultureResult;
                }
            }

            throw new TypeConverterException(this, memberMapData, text, row.Context, 
                $"Unable to convert '{text}' to decimal. Original value was: '{row.GetField(memberMapData.Index)}'");
        }

        public string ConvertToString(object value, IWriterRow row, MemberMapData memberMapData)
        {
            if (value == null)
                return string.Empty;

            if (value is decimal decimalValue)
            {
                return decimalValue.ToString("F2", CultureInfo.InvariantCulture);
            }

            return value.ToString() ?? string.Empty;
        }
    }
}