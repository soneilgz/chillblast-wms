using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using System.Globalization;
using System.Text.RegularExpressions;

namespace ChillBlastWMS_MVC.Utilities
{
    public class FlexibleIntegerConverter : ITypeConverter
    {
        public object ConvertFromString(string text, IReaderRow row, MemberMapData memberMapData)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                if (memberMapData.Member.MemberType() == typeof(int?))
                    return null;
                return 0; // Default to 0 for non-nullable int
            }

            text = text.Trim();

            // TIER 4: DATA QUALITY AUTO-FIXES (NORMALIZE)
            // ✅ Remove any non-numeric characters except minus sign
            text = Regex.Replace(text, @"[^\d\-]", "");

            if (string.IsNullOrEmpty(text))
            {
                if (memberMapData.Member.MemberType() == typeof(int?))
                    return null;
                return 0;
            }

            // Try to parse as integer
            if (int.TryParse(text, NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out int result))
            {
                return result;
            }

            // TIER 2: If this looks like a text value that shouldn't be parsed as int, 
            // it might indicate column misalignment - this should SKIP the row
            if (Regex.IsMatch(text.Replace(" ", ""), @"^[A-Za-z]+$"))
            {
                throw new TypeConverterException(this, memberMapData, text, row.Context, 
                    $"SKIP: Text value '{row.GetField(memberMapData.Index)}' found in integer field '{memberMapData.Member.Name}' - possible column misalignment");
            }

            throw new TypeConverterException(this, memberMapData, text, row.Context, 
                $"Unable to convert '{row.GetField(memberMapData.Index)}' to integer for field '{memberMapData.Member.Name}'");
        }

        public string ConvertToString(object value, IWriterRow row, MemberMapData memberMapData)
        {
            if (value == null)
                return string.Empty;

            if (value is int intValue)
            {
                return intValue.ToString(CultureInfo.InvariantCulture);
            }

            return value.ToString() ?? string.Empty;
        }
    }
}