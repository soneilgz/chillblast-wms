using System.Text.RegularExpressions;
using ChillBlastWMS_MVC.Models.Domain;
using ChillBlastWMS_MVC.Models.DTOs;

namespace ChillBlastWMS_MVC.Utilities
{
    public class DuplicateDetector
    {
        private readonly DuplicateDetectionOptions _options;

        public DuplicateDetector(DuplicateDetectionOptions? options = null)
        {
            _options = options ?? new DuplicateDetectionOptions();
        }

        public List<DuplicateGroup> DetectDuplicateSKUs(IEnumerable<ProductImportDto> products)
        {
            var duplicateGroups = new List<DuplicateGroup>();
            var productList = products.ToList();

            // Group by normalized SKU
            var skuGroups = productList
                .Select((p, index) => new { Product = p, Index = index })
                .GroupBy(x => NormalizeSKU(x.Product.SKU ?? string.Empty, _options.CaseSensitive))
                .Where(g => g.Count() > 1);

            foreach (var group in skuGroups)
            {
                var duplicateGroup = new DuplicateGroup
                {
                    Key = group.Key,
                    Type = DuplicateType.ExactSKU,
                    Count = group.Count(),
                    Items = group.Select(g => new DuplicateItem
                    {
                        RowIndex = g.Index,
                        SKU = g.Product.SKU ?? string.Empty,
                        Name = g.Product.Name ?? string.Empty,
                        Price = g.Product.Price,
                        Quantity = g.Product.Quantity
                    }).ToList()
                };

                duplicateGroup.Resolution = DetermineResolution(duplicateGroup.Items);
                duplicateGroups.Add(duplicateGroup);
            }

            // Detect near duplicates if enabled
            if (_options.DetectNearDuplicates)
            {
                var nearDuplicates = DetectNearDuplicateSKUs(productList);
                duplicateGroups.AddRange(nearDuplicates);
            }

            return duplicateGroups;
        }

        public List<DuplicateGroup> DetectNearDuplicateSKUs(IEnumerable<ProductImportDto> products)
        {
            var nearDuplicates = new List<DuplicateGroup>();
            var productList = products.ToList();

            for (int i = 0; i < productList.Count - 1; i++)
            {
                for (int j = i + 1; j < productList.Count; j++)
                {
                    var sku1 = productList[i].SKU ?? string.Empty;
                    var sku2 = productList[j].SKU ?? string.Empty;

                    if (string.IsNullOrWhiteSpace(sku1) || string.IsNullOrWhiteSpace(sku2))
                        continue;

                    var similarity = CalculateSimilarity(sku1, sku2);
                    
                    if (similarity >= _options.SimilarityThreshold)
                    {
                        // Check if this pair is already in a group
                        var existingGroup = nearDuplicates.FirstOrDefault(g => 
                            g.Items.Any(item => item.SKU == sku1 || item.SKU == sku2));

                        if (existingGroup != null)
                        {
                            // Add to existing group if not already there
                            if (!existingGroup.Items.Any(item => item.SKU == sku1))
                            {
                                existingGroup.Items.Add(new DuplicateItem
                                {
                                    RowIndex = i,
                                    SKU = sku1,
                                    Name = productList[i].Name ?? string.Empty,
                                    Price = productList[i].Price,
                                    Quantity = productList[i].Quantity
                                });
                            }
                            if (!existingGroup.Items.Any(item => item.SKU == sku2))
                            {
                                existingGroup.Items.Add(new DuplicateItem
                                {
                                    RowIndex = j,
                                    SKU = sku2,
                                    Name = productList[j].Name ?? string.Empty,
                                    Price = productList[j].Price,
                                    Quantity = productList[j].Quantity
                                });
                            }
                        }
                        else
                        {
                            // Create new group
                            nearDuplicates.Add(new DuplicateGroup
                            {
                                Key = $"{sku1}~{sku2}",
                                Type = DuplicateType.NearDuplicate,
                                Similarity = similarity,
                                Count = 2,
                                Items = new List<DuplicateItem>
                                {
                                    new DuplicateItem
                                    {
                                        RowIndex = i,
                                        SKU = sku1,
                                        Name = productList[i].Name ?? string.Empty,
                                        Price = productList[i].Price,
                                        Quantity = productList[i].Quantity
                                    },
                                    new DuplicateItem
                                    {
                                        RowIndex = j,
                                        SKU = sku2,
                                        Name = productList[j].Name ?? string.Empty,
                                        Price = productList[j].Price,
                                        Quantity = productList[j].Quantity
                                    }
                                }
                            });
                        }
                    }
                }
            }

            return nearDuplicates;
        }

        private string NormalizeSKU(string sku, bool caseSensitive = false)
        {
            if (string.IsNullOrWhiteSpace(sku))
                return string.Empty;

            // Remove whitespace
            sku = sku.Trim();

            // Remove common separators if configured
            if (_options.IgnoreSeparators)
            {
                sku = Regex.Replace(sku, @"[\-_\.\s]", "");
            }

            // Handle case sensitivity
            if (!caseSensitive)
            {
                sku = sku.ToUpperInvariant();
            }

            return sku;
        }

        private double CalculateSimilarity(string str1, string str2)
        {
            if (string.IsNullOrEmpty(str1) || string.IsNullOrEmpty(str2))
                return 0;

            if (str1.Equals(str2, StringComparison.OrdinalIgnoreCase))
                return 1.0;

            // Use Levenshtein distance for similarity
            var distance = LevenshteinDistance(str1.ToUpper(), str2.ToUpper());
            var maxLength = Math.Max(str1.Length, str2.Length);
            
            return 1.0 - (double)distance / maxLength;
        }

        private int LevenshteinDistance(string s1, string s2)
        {
            int[,] distance = new int[s1.Length + 1, s2.Length + 1];

            for (int i = 0; i <= s1.Length; i++)
                distance[i, 0] = i;

            for (int j = 0; j <= s2.Length; j++)
                distance[0, j] = j;

            for (int i = 1; i <= s1.Length; i++)
            {
                for (int j = 1; j <= s2.Length; j++)
                {
                    int cost = s1[i - 1] == s2[j - 1] ? 0 : 1;

                    distance[i, j] = Math.Min(
                        Math.Min(distance[i - 1, j] + 1, distance[i, j - 1] + 1),
                        distance[i - 1, j - 1] + cost);
                }
            }

            return distance[s1.Length, s2.Length];
        }

        private DuplicateResolution DetermineResolution(List<DuplicateItem> items)
        {
            // All have same price and quantity - likely intentional
            if (items.Select(i => new { i.Price, i.Quantity }).Distinct().Count() == 1)
            {
                return DuplicateResolution.KeepFirst;
            }

            // Different prices - might be variants
            if (items.Select(i => i.Price).Distinct().Count() > 1)
            {
                return DuplicateResolution.Manual;
            }

            // Different quantities - merge might be appropriate
            if (items.Select(i => i.Quantity).Distinct().Count() > 1)
            {
                return DuplicateResolution.MergeQuantities;
            }

            // Keep the most recent one
            if (items.All(i => i.CreatedDate.HasValue))
            {
                return DuplicateResolution.KeepNewest;
            }

            return DuplicateResolution.Manual;
        }
    }

    public class DuplicateGroup
    {
        public string Key { get; set; } = string.Empty;
        public DuplicateType Type { get; set; }
        public int Count { get; set; }
        public double? Similarity { get; set; }
        public List<DuplicateItem> Items { get; set; } = new List<DuplicateItem>();
        public DuplicateResolution Resolution { get; set; }
        public DuplicateSeverity Severity { get; set; }
    }

    public class DuplicateItem
    {
        public int? ProductId { get; set; }
        public int? RowIndex { get; set; }
        public string SKU { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public DateTime? CreatedDate { get; set; }
    }

    public enum DuplicateType
    {
        ExactSKU,
        NearDuplicate,
        SameName,
        SameBarcode
    }

    public enum DuplicateResolution
    {
        KeepFirst,
        KeepLast,
        KeepNewest,
        MergeQuantities,
        Manual
    }

    public enum DuplicateSeverity
    {
        Low,
        Medium,
        High,
        Critical
    }

    public class DuplicateDetectionOptions
    {
        public bool CaseSensitive { get; set; } = false;
        public bool IgnoreSeparators { get; set; } = true;
        public bool DetectNearDuplicates { get; set; } = true;
        public double SimilarityThreshold { get; set; } = 0.85;
        public bool CheckNameDuplicates { get; set; } = true;
        public bool IgnoreCommonWords { get; set; } = true;
    }
}