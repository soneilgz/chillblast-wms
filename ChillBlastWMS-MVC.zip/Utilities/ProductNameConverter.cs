using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;

namespace ChillBlastWMS_MVC.Utilities
{
    public class ProductNameConverter : SmartTruncatingStringConverter
    {
        public ProductNameConverter() : base(255, "Name")
        {
        }
    }

    public class SkuConverter : SmartTruncatingStringConverter  
    {
        public SkuConverter() : base(50, "SKU")
        {
        }
    }

    public class CategoryConverter : SmartTruncatingStringConverter
    {
        public CategoryConverter() : base(100, "Category")
        {
        }
    }

    public class ManufacturerConverter : SmartTruncatingStringConverter
    {
        public ManufacturerConverter() : base(100, "Manufacturer")
        {
        }
    }

    public class DescriptionConverter : SmartTruncatingStringConverter
    {
        public DescriptionConverter() : base(1000, "Description")
        {
        }
    }
}