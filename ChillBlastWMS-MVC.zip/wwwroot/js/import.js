// ChillBlast WMS - Import JavaScript Module
(function (window, document, $) {
    'use strict';

    // Import Module
    const ImportModule = {
        // Configuration
        config: {
            maxFileSize: 52428800, // 50MB
            allowedExtensions: ['.csv', '.xlsx', '.xls', '.json'],
            chunkSize: 1048576, // 1MB chunks for large files
            apiBaseUrl: '/api/import',
            progressUpdateInterval: 500,
            csrfToken: null
        },

        // State
        state: {
            currentFile: null,
            uploadProgress: 0,
            importId: null,
            isUploading: false,
            isPreviewing: false,
            progressTimer: null,
            validationErrors: [],
            columnMappings: {},
            importOptions: {
                skipErrors: false,
                updateExisting: true,
                validateOnly: false
            }
        },

        // Initialize module
        init: function() {
            this.config.csrfToken = $('input[name="__RequestVerificationToken"]').val();
            this.bindEvents();
            this.initializeUploadArea();
            this.loadImportHistory();
            console.log('Import module initialized');
        },

        // Bind events
        bindEvents: function() {
            const self = this;

            // File input change
            $('#fileInput').on('change', function(e) {
                self.handleFileSelect(e.target.files[0]);
            });

            // Drag and drop
            this.setupDragAndDrop();

            // Import type selection
            $('input[name="importType"]').on('change', function() {
                self.updateImportGuidelines($(this).val());
            });

            // Column mapping
            $(document).on('change', '.column-mapping', function() {
                self.updateColumnMapping($(this).data('source'), $(this).val());
            });

            // Import options
            $('.import-option').on('change', function() {
                self.updateImportOptions();
            });

            // Action buttons
            $('#validateBtn').on('click', function() {
                self.validateFile();
            });

            $('#previewBtn').on('click', function() {
                self.previewData();
            });

            $('#importBtn').on('click', function() {
                self.startImport();
            });

            $('#cancelImportBtn').on('click', function() {
                self.cancelImport();
            });

            // Template download
            $('#downloadTemplate').on('click', function() {
                self.downloadTemplate();
            });

            // Error handling
            $(document).on('click', '.fix-error', function() {
                self.fixError($(this).data('error-id'));
            });

            $(document).on('click', '.view-error-details', function() {
                self.viewErrorDetails($(this).data('error-id'));
            });

            // Progress monitoring
            $(document).on('click', '.monitor-import', function() {
                self.monitorImport($(this).data('import-id'));
            });
        },

        // Initialize upload area
        initializeUploadArea: function() {
            const uploadArea = $('#uploadArea');
            if (!uploadArea.length) return;

            // Add visual feedback
            uploadArea.addClass('upload-ready');
        },

        // Setup drag and drop
        setupDragAndDrop: function() {
            const self = this;
            const uploadArea = document.getElementById('uploadArea');
            
            if (!uploadArea) return;

            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                uploadArea.addEventListener(eventName, this.preventDefaults, false);
            });

            ['dragenter', 'dragover'].forEach(eventName => {
                uploadArea.addEventListener(eventName, () => {
                    uploadArea.classList.add('dragover');
                }, false);
            });

            ['dragleave', 'drop'].forEach(eventName => {
                uploadArea.addEventListener(eventName, () => {
                    uploadArea.classList.remove('dragover');
                }, false);
            });

            uploadArea.addEventListener('drop', function(e) {
                const dt = e.dataTransfer;
                const files = dt.files;
                
                if (files.length > 0) {
                    self.handleFileSelect(files[0]);
                }
            }, false);
        },

        // Prevent default drag behaviors
        preventDefaults: function(e) {
            e.preventDefault();
            e.stopPropagation();
        },

        // Handle file selection
        handleFileSelect: function(file) {
            if (!file) return;

            // Validate file
            const validation = this.validateFileSelection(file);
            if (!validation.valid) {
                this.showToast(validation.message, 'error');
                return;
            }

            // Store file
            this.state.currentFile = file;

            // Display file info
            this.displayFileInfo(file);

            // Enable action buttons
            $('#validateBtn, #previewBtn').prop('disabled', false);

            // Auto-detect import type
            this.detectImportType(file);

            // Parse file for preview
            this.parseFileForPreview(file);
        },

        // Validate file selection
        validateFileSelection: function(file) {
            // Check file extension
            const ext = '.' + file.name.split('.').pop().toLowerCase();
            if (!this.config.allowedExtensions.includes(ext)) {
                return {
                    valid: false,
                    message: `Invalid file type. Allowed types: ${this.config.allowedExtensions.join(', ')}`
                };
            }

            // Check file size
            if (file.size > this.config.maxFileSize) {
                return {
                    valid: false,
                    message: `File size exceeds ${this.formatFileSize(this.config.maxFileSize)} limit`
                };
            }

            return { valid: true };
        },

        // Display file information
        displayFileInfo: function(file) {
            $('#fileName').text(file.name);
            $('#fileSize').text(this.formatFileSize(file.size));
            $('#fileType').text(file.type || 'Unknown');
            $('#filePreview').show();
            $('#uploadArea').hide();

            // Show file icon based on type
            const icon = this.getFileIcon(file.name);
            $('#fileIcon').html(`<i class="${icon}"></i>`);
        },

        // Get file icon
        getFileIcon: function(fileName) {
            const ext = fileName.split('.').pop().toLowerCase();
            const icons = {
                'csv': 'bi bi-file-earmark-csv text-success',
                'xlsx': 'bi bi-file-earmark-excel text-success',
                'xls': 'bi bi-file-earmark-excel text-success',
                'json': 'bi bi-file-earmark-code text-info'
            };
            return icons[ext] || 'bi bi-file-earmark text-secondary';
        },

        // Detect import type from file
        detectImportType: function(file) {
            const fileName = file.name.toLowerCase();
            let importType = 'products'; // default

            if (fileName.includes('customer')) {
                importType = 'customers';
            } else if (fileName.includes('order')) {
                importType = 'orders';
            } else if (fileName.includes('inventory') || fileName.includes('stock')) {
                importType = 'inventory';
            } else if (fileName.includes('supplier')) {
                importType = 'suppliers';
            }

            $(`#type${importType.charAt(0).toUpperCase() + importType.slice(1)}`).prop('checked', true);
            this.updateImportGuidelines(importType);
        },

        // Parse file for preview
        parseFileForPreview: function(file) {
            const self = this;
            const reader = new FileReader();

            reader.onload = function(e) {
                const content = e.target.result;
                const ext = file.name.split('.').pop().toLowerCase();

                if (ext === 'csv') {
                    self.parseCSV(content);
                } else if (ext === 'json') {
                    self.parseJSON(content);
                } else if (ext === 'xlsx' || ext === 'xls') {
                    self.parseExcel(file);
                }
            };

            if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
                this.parseExcel(file);
            } else {
                reader.readAsText(file);
            }
        },

        // Parse CSV content
        parseCSV: function(content) {
            const lines = content.split('\n');
            const headers = lines[0].split(',').map(h => h.trim());
            const preview = [];

            for (let i = 1; i < Math.min(lines.length, 11); i++) {
                if (lines[i].trim()) {
                    const values = this.parseCSVLine(lines[i]);
                    const row = {};
                    headers.forEach((header, index) => {
                        row[header] = values[index] || '';
                    });
                    preview.push(row);
                }
            }

            this.displayPreview(headers, preview);
        },

        // Parse CSV line (handles quotes)
        parseCSVLine: function(line) {
            const result = [];
            let current = '';
            let inQuotes = false;

            for (let i = 0; i < line.length; i++) {
                const char = line[i];
                
                if (char === '"') {
                    inQuotes = !inQuotes;
                } else if (char === ',' && !inQuotes) {
                    result.push(current.trim());
                    current = '';
                } else {
                    current += char;
                }
            }
            
            result.push(current.trim());
            return result;
        },

        // Parse JSON content
        parseJSON: function(content) {
            try {
                const data = JSON.parse(content);
                const items = Array.isArray(data) ? data : [data];
                
                if (items.length > 0) {
                    const headers = Object.keys(items[0]);
                    const preview = items.slice(0, 10);
                    this.displayPreview(headers, preview);
                }
            } catch (e) {
                this.showToast('Invalid JSON format', 'error');
            }
        },

        // Parse Excel file
        parseExcel: function(file) {
            const self = this;
            const reader = new FileReader();

            reader.onload = function(e) {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
                const jsonData = XLSX.utils.sheet_to_json(firstSheet);

                if (jsonData.length > 0) {
                    const headers = Object.keys(jsonData[0]);
                    const preview = jsonData.slice(0, 10);
                    self.displayPreview(headers, preview);
                }
            };

            reader.readAsArrayBuffer(file);
        },

        // Display preview
        displayPreview: function(headers, data) {
            let html = '<table class="table table-sm table-hover">';
            
            // Headers
            html += '<thead class="table-light"><tr><th>#</th>';
            headers.forEach(header => {
                html += `<th>${this.escapeHtml(header)}</th>`;
            });
            html += '</tr></thead>';

            // Data rows
            html += '<tbody>';
            data.forEach((row, index) => {
                html += `<tr><td>${index + 1}</td>`;
                headers.forEach(header => {
                    const value = row[header] || '';
                    const cellClass = this.getCellClass(header, value);
                    html += `<td class="${cellClass}">${this.escapeHtml(value.toString())}</td>`;
                });
                html += '</tr>';
            });
            html += '</tbody></table>';

            $('#dataPreview').html(html);
            $('#previewSection').show();

            // Auto-map columns
            this.autoMapColumns(headers);
        },

        // Get cell class based on validation
        getCellClass: function(header, value) {
            // Check for potential issues
            if (value === '' || value === null || value === undefined) {
                return 'bg-warning bg-opacity-10';
            }
            
            // Check numeric fields
            if (header.toLowerCase().includes('price') || header.toLowerCase().includes('cost') || 
                header.toLowerCase().includes('quantity')) {
                if (isNaN(value)) {
                    return 'bg-danger bg-opacity-10';
                }
                if (parseFloat(value) < 0) {
                    return 'bg-warning bg-opacity-10';
                }
            }

            return '';
        },

        // Auto-map columns
        autoMapColumns: function(headers) {
            const importType = $('input[name="importType"]:checked').val();
            const mappings = this.getAutoMappings(importType);
            
            $('#columnMappings').empty();
            
            headers.forEach(header => {
                const mapping = this.findBestMapping(header, mappings);
                const html = this.createMappingRow(header, mapping, mappings);
                $('#columnMappings').append(html);
                
                if (mapping) {
                    this.state.columnMappings[header] = mapping;
                }
            });

            $('#mappingSection').show();
        },

        // Get auto-mapping suggestions
        getAutoMappings: function(importType) {
            const mappings = {
                'products': ['SKU', 'Name', 'Description', 'Category', 'Price', 'Cost', 'Quantity', 'ReorderPoint', 'Supplier', 'Location'],
                'customers': ['Name', 'Email', 'Phone', 'Company', 'Address', 'City', 'State', 'ZipCode', 'Country'],
                'orders': ['OrderNumber', 'CustomerID', 'OrderDate', 'Status', 'Total', 'ShippingAddress'],
                'inventory': ['SKU', 'Location', 'Quantity', 'Status', 'LastUpdated']
            };
            return mappings[importType] || mappings['products'];
        },

        // Find best mapping for a column
        findBestMapping: function(header, availableMappings) {
            const headerLower = header.toLowerCase().replace(/[^a-z0-9]/g, '');
            
            for (const mapping of availableMappings) {
                const mappingLower = mapping.toLowerCase().replace(/[^a-z0-9]/g, '');
                if (headerLower === mappingLower || headerLower.includes(mappingLower) || mappingLower.includes(headerLower)) {
                    return mapping;
                }
            }
            
            return null;
        },

        // Create mapping row HTML
        createMappingRow: function(sourceColumn, selectedMapping, availableMappings) {
            let html = `
                <div class="row mb-2">
                    <div class="col-md-5">
                        <input type="text" class="form-control form-control-sm" value="${sourceColumn}" readonly>
                    </div>
                    <div class="col-md-2 text-center">
                        <i class="bi bi-arrow-right"></i>
                    </div>
                    <div class="col-md-5">
                        <select class="form-select form-select-sm column-mapping" data-source="${sourceColumn}">
                            <option value="">-- Ignore --</option>`;
            
            availableMappings.forEach(mapping => {
                html += `<option value="${mapping}" ${selectedMapping === mapping ? 'selected' : ''}>${mapping}</option>`;
            });
            
            html += `</select>
                    </div>
                </div>`;
            
            return html;
        },

        // Update column mapping
        updateColumnMapping: function(source, target) {
            if (target) {
                this.state.columnMappings[source] = target;
            } else {
                delete this.state.columnMappings[source];
            }
        },

        // Update import options
        updateImportOptions: function() {
            this.state.importOptions = {
                skipErrors: $('#skipErrors').is(':checked'),
                updateExisting: $('#updateExisting').is(':checked'),
                validateOnly: $('#validateOnly').is(':checked'),
                sendNotification: $('#sendNotification').is(':checked')
            };
        },

        // Validate file
        validateFile: function() {
            const self = this;
            
            if (!this.state.currentFile) {
                this.showToast('Please select a file first', 'warning');
                return;
            }

            const formData = new FormData();
            formData.append('file', this.state.currentFile);
            formData.append('type', $('input[name="importType"]:checked').val());
            formData.append('mappings', JSON.stringify(this.state.columnMappings));
            formData.append('options', JSON.stringify(this.state.importOptions));

            this.showLoading('Validating file...');

            $.ajax({
                url: `${this.config.apiBaseUrl}/validate`,
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'RequestVerificationToken': this.config.csrfToken
                },
                xhr: function() {
                    const xhr = new window.XMLHttpRequest();
                    xhr.upload.addEventListener('progress', function(evt) {
                        if (evt.lengthComputable) {
                            const percentComplete = (evt.loaded / evt.total) * 100;
                            self.updateProgress(percentComplete, 'Uploading...');
                        }
                    }, false);
                    return xhr;
                },
                success: function(response) {
                    self.hideLoading();
                    self.displayValidationResults(response);
                },
                error: function(xhr) {
                    self.hideLoading();
                    self.handleError('Validation failed', xhr);
                }
            });
        },

        // Display validation results
        displayValidationResults: function(result) {
            this.state.validationErrors = result.errors || [];
            
            let html = '';
            
            if (result.isValid) {
                html = `
                    <div class="alert alert-success">
                        <i class="bi bi-check-circle"></i> Validation successful!
                        <br>Ready to import ${result.validRecords} records.
                    </div>`;
                $('#importBtn').prop('disabled', false);
            } else {
                html = `
                    <div class="alert alert-danger">
                        <i class="bi bi-x-circle"></i> Validation failed
                        <br>${result.errorCount} errors found
                    </div>`;
            }

            // Statistics
            html += `
                <div class="row text-center mb-3">
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body">
                                <h4>${result.totalRecords}</h4>
                                <small>Total Records</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="text-success">${result.validRecords}</h4>
                                <small>Valid</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="text-warning">${result.warningCount}</h4>
                                <small>Warnings</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="text-danger">${result.errorCount}</h4>
                                <small>Errors</small>
                            </div>
                        </div>
                    </div>
                </div>`;

            // Errors list
            if (result.errors && result.errors.length > 0) {
                html += '<h6>Errors:</h6><div class="error-list">';
                result.errors.slice(0, 10).forEach(error => {
                    html += this.createErrorItem(error);
                });
                if (result.errors.length > 10) {
                    html += `<p class="text-muted">... and ${result.errors.length - 10} more errors</p>`;
                }
                html += '</div>';
            }

            // Warnings list
            if (result.warnings && result.warnings.length > 0) {
                html += '<h6 class="mt-3">Warnings:</h6><div class="warning-list">';
                result.warnings.slice(0, 5).forEach(warning => {
                    html += `
                        <div class="alert alert-warning py-2 mb-2">
                            <i class="bi bi-exclamation-triangle"></i> 
                            Row ${warning.row}: ${warning.message}
                        </div>`;
                });
                html += '</div>';
            }

            $('#validationResults').html(html).show();
        },

        // Create error item HTML
        createErrorItem: function(error) {
            return `
                <div class="alert alert-danger py-2 mb-2" data-error-id="${error.id}">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <i class="bi bi-x-circle"></i> 
                            Row ${error.row}: ${error.message}
                            ${error.field ? `<br><small>Field: ${error.field}</small>` : ''}
                            ${error.value ? `<br><small>Value: ${error.value}</small>` : ''}
                        </div>
                        <div class="btn-group btn-group-sm">
                            ${error.fixable ? `
                                <button class="btn btn-sm btn-warning fix-error" data-error-id="${error.id}">
                                    <i class="bi bi-wrench"></i> Fix
                                </button>` : ''
                            }
                            <button class="btn btn-sm btn-info view-error-details" data-error-id="${error.id}">
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>`;
        },

        // Fix error
        fixError: function(errorId) {
            const self = this;
            const error = this.state.validationErrors.find(e => e.id === errorId);
            
            if (!error || !error.fixable) return;

            $.ajax({
                url: `${this.config.apiBaseUrl}/fix-error`,
                method: 'POST',
                data: JSON.stringify({ errorId: errorId, error: error }),
                contentType: 'application/json',
                headers: {
                    'RequestVerificationToken': this.config.csrfToken
                },
                success: function(response) {
                    self.showToast('Error fixed', 'success');
                    // Remove error from list
                    $(`.alert[data-error-id="${errorId}"]`).fadeOut();
                    self.state.validationErrors = self.state.validationErrors.filter(e => e.id !== errorId);
                },
                error: function(xhr) {
                    self.handleError('Failed to fix error', xhr);
                }
            });
        },

        // View error details
        viewErrorDetails: function(errorId) {
            const error = this.state.validationErrors.find(e => e.id === errorId);
            if (!error) return;

            const modal = this.createModal('Error Details', `
                <table class="table table-sm">
                    <tr><th>Row:</th><td>${error.row}</td></tr>
                    <tr><th>Field:</th><td>${error.field || 'N/A'}</td></tr>
                    <tr><th>Value:</th><td><code>${error.value || 'N/A'}</code></td></tr>
                    <tr><th>Message:</th><td>${error.message}</td></tr>
                    <tr><th>Type:</th><td><span class="badge bg-${error.severity === 'critical' ? 'danger' : 'warning'}">${error.severity}</span></td></tr>
                </table>
                ${error.suggestion ? `
                    <div class="alert alert-info">
                        <i class="bi bi-lightbulb"></i> <strong>Suggestion:</strong> ${error.suggestion}
                    </div>` : ''}
            `);
            
            modal.show();
        },

        // Preview data
        previewData: function() {
            if (!this.state.currentFile) {
                this.showToast('Please select a file first', 'warning');
                return;
            }

            // Navigate to preview page with session data
            const sessionId = this.uploadFileForPreview();
        },

        // Upload file for preview
        uploadFileForPreview: function() {
            const self = this;
            const formData = new FormData();
            
            formData.append('file', this.state.currentFile);
            formData.append('type', $('input[name="importType"]:checked').val());
            formData.append('mappings', JSON.stringify(this.state.columnMappings));
            formData.append('options', JSON.stringify(this.state.importOptions));

            this.showLoading('Preparing preview...');

            $.ajax({
                url: `${this.config.apiBaseUrl}/upload-for-preview`,
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'RequestVerificationToken': this.config.csrfToken
                },
                success: function(response) {
                    self.hideLoading();
                    if (response.success) {
                        window.location.href = `/Import/Preview?sessionId=${response.sessionId}`;
                    } else {
                        self.showToast(response.message, 'error');
                    }
                },
                error: function(xhr) {
                    self.hideLoading();
                    self.handleError('Failed to prepare preview', xhr);
                }
            });
        },

        // Start import
        startImport: function() {
            const self = this;
            
            if (!this.state.currentFile) {
                this.showToast('Please select a file first', 'warning');
                return;
            }

            if (!confirm('Start importing data? This process cannot be undone.')) {
                return;
            }

            const formData = new FormData();
            formData.append('file', this.state.currentFile);
            formData.append('type', $('input[name="importType"]:checked').val());
            formData.append('mappings', JSON.stringify(this.state.columnMappings));
            formData.append('options', JSON.stringify(this.state.importOptions));

            // Show progress modal
            this.showProgressModal();

            $.ajax({
                url: `${this.config.apiBaseUrl}/start`,
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'RequestVerificationToken': this.config.csrfToken
                },
                xhr: function() {
                    const xhr = new window.XMLHttpRequest();
                    xhr.upload.addEventListener('progress', function(evt) {
                        if (evt.lengthComputable) {
                            const percentComplete = (evt.loaded / evt.total) * 100;
                            self.updateProgress(percentComplete, 'Uploading file...');
                        }
                    }, false);
                    return xhr;
                },
                success: function(response) {
                    if (response.success) {
                        self.state.importId = response.importId;
                        self.monitorImportProgress();
                    } else {
                        self.hideProgressModal();
                        self.showToast(response.message, 'error');
                    }
                },
                error: function(xhr) {
                    self.hideProgressModal();
                    self.handleError('Failed to start import', xhr);
                }
            });
        },

        // Show progress modal
        showProgressModal: function() {
            const html = `
                <div class="modal fade" id="importProgressModal" tabindex="-1" data-bs-backdrop="static">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Import Progress</h5>
                            </div>
                            <div class="modal-body">
                                <div class="text-center mb-3">
                                    <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;"></div>
                                    <h5 class="mt-3" id="progressStatus">Starting import...</h5>
                                </div>
                                <div class="progress mb-3" style="height: 30px;">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated" 
                                         id="importProgressBar" 
                                         style="width: 0%">0%</div>
                                </div>
                                <div class="row text-center" id="progressStats">
                                    <div class="col-md-3">
                                        <h4 id="processedCount">0</h4>
                                        <small>Processed</small>
                                    </div>
                                    <div class="col-md-3">
                                        <h4 class="text-success" id="successCount">0</h4>
                                        <small>Success</small>
                                    </div>
                                    <div class="col-md-3">
                                        <h4 class="text-warning" id="skippedCount">0</h4>
                                        <small>Skipped</small>
                                    </div>
                                    <div class="col-md-3">
                                        <h4 class="text-danger" id="errorCount">0</h4>
                                        <small>Errors</small>
                                    </div>
                                </div>
                                <div class="mt-3" id="progressLog" style="max-height: 200px; overflow-y: auto;">
                                    <!-- Log entries will be added here -->
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" onclick="ImportModule.cancelImport()">
                                    Cancel Import
                                </button>
                            </div>
                        </div>
                    </div>
                </div>`;

            $('body').append(html);
            $('#importProgressModal').modal('show');
        },

        // Hide progress modal
        hideProgressModal: function() {
            $('#importProgressModal').modal('hide');
            setTimeout(() => {
                $('#importProgressModal').remove();
            }, 500);
        },

        // Monitor import progress
        monitorImportProgress: function() {
            const self = this;
            
            this.state.progressTimer = setInterval(() => {
                $.ajax({
                    url: `${this.config.apiBaseUrl}/progress/${self.state.importId}`,
                    method: 'GET',
                    success: function(data) {
                        self.updateImportProgress(data);
                        
                        if (data.status === 'Completed' || data.status === 'Failed' || data.status === 'Cancelled') {
                            clearInterval(self.state.progressTimer);
                            self.handleImportComplete(data);
                        }
                    },
                    error: function() {
                        // Continue monitoring even if one request fails
                    }
                });
            }, this.config.progressUpdateInterval);
        },

        // Update import progress
        updateImportProgress: function(data) {
            const percentage = data.progressPercentage || 0;
            
            $('#importProgressBar')
                .css('width', percentage + '%')
                .text(percentage + '%');
            
            $('#progressStatus').text(data.currentOperation || 'Processing...');
            $('#processedCount').text(data.processedRecords || 0);
            $('#successCount').text(data.successCount || 0);
            $('#skippedCount').text(data.skippedCount || 0);
            $('#errorCount').text(data.errorCount || 0);

            // Add log entry if new
            if (data.latestLog) {
                this.addProgressLog(data.latestLog);
            }
        },

        // Add progress log entry
        addProgressLog: function(log) {
            const html = `
                <div class="log-entry small ${log.type}">
                    <span class="text-muted">${new Date(log.timestamp).toLocaleTimeString()}</span>
                    ${log.message}
                </div>`;
            
            $('#progressLog').prepend(html);
            
            // Keep only last 20 entries
            const entries = $('#progressLog .log-entry');
            if (entries.length > 20) {
                entries.last().remove();
            }
        },

        // Handle import complete
        handleImportComplete: function(data) {
            this.hideProgressModal();
            
            if (data.status === 'Completed') {
                this.showToast(`Import completed successfully! ${data.successCount} records imported.`, 'success');
                
                // Redirect to results
                setTimeout(() => {
                    window.location.href = `/Import/Results/${this.state.importId}`;
                }, 1500);
            } else if (data.status === 'Failed') {
                this.showToast(`Import failed. ${data.errorCount} errors encountered.`, 'error');
                this.showImportErrors(data.errors);
            } else if (data.status === 'Cancelled') {
                this.showToast('Import cancelled', 'warning');
            }
        },

        // Show import errors
        showImportErrors: function(errors) {
            if (!errors || errors.length === 0) return;

            let html = '<h6>Import Errors:</h6><div class="error-list" style="max-height: 400px; overflow-y: auto;">';
            
            errors.forEach(error => {
                html += `
                    <div class="alert alert-danger py-2 mb-2">
                        <strong>Row ${error.row}:</strong> ${error.message}
                        ${error.field ? `<br>Field: ${error.field}` : ''}
                    </div>`;
            });
            
            html += '</div>';
            
            const modal = this.createModal('Import Errors', html);
            modal.show();
        },

        // Cancel import
        cancelImport: function() {
            const self = this;
            
            if (!this.state.importId) return;
            
            if (!confirm('Are you sure you want to cancel the import?')) {
                return;
            }

            $.ajax({
                url: `${this.config.apiBaseUrl}/cancel/${this.state.importId}`,
                method: 'POST',
                headers: {
                    'RequestVerificationToken': this.config.csrfToken
                },
                success: function() {
                    clearInterval(self.state.progressTimer);
                    self.hideProgressModal();
                    self.showToast('Import cancelled', 'warning');
                },
                error: function(xhr) {
                    self.handleError('Failed to cancel import', xhr);
                }
            });
        },

        // Monitor existing import
        monitorImport: function(importId) {
            window.location.href = `/Import/Progress/${importId}`;
        },

        // Load import history
        loadImportHistory: function() {
            const self = this;
            
            $.ajax({
                url: `${this.config.apiBaseUrl}/history`,
                method: 'GET',
                data: {
                    page: 1,
                    pageSize: 10
                },
                success: function(response) {
                    self.renderImportHistory(response.imports);
                }
            });
        },

        // Render import history
        renderImportHistory: function(imports) {
            if (!imports || imports.length === 0) {
                $('#importHistory').html('<p class="text-muted text-center">No import history</p>');
                return;
            }

            let html = '<div class="list-group">';
            
            imports.forEach(item => {
                const statusClass = item.status === 'Completed' ? 'success' : 
                                   item.status === 'Failed' ? 'danger' : 
                                   item.status === 'Processing' ? 'info' : 'warning';
                
                html += `
                    <div class="list-group-item">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h6 class="mb-1">${item.fileName}</h6>
                                <p class="mb-1 small">
                                    <span class="badge bg-${statusClass}">${item.status}</span>
                                    ${item.recordCount} records • ${item.importType}
                                </p>
                                <small class="text-muted">${new Date(item.createdAt).toLocaleString()}</small>
                            </div>
                            <div class="btn-group btn-group-sm">
                                ${item.status === 'Processing' ? `
                                    <button class="btn btn-info monitor-import" data-import-id="${item.id}">
                                        <i class="bi bi-eye"></i> Monitor
                                    </button>` : `
                                    <a href="/Import/Results/${item.id}" class="btn btn-primary">
                                        <i class="bi bi-file-text"></i> View
                                    </a>`
                                }
                            </div>
                        </div>
                    </div>`;
            });
            
            html += '</div>';
            $('#importHistory').html(html);
        },

        // Download template
        downloadTemplate: function() {
            const importType = $('input[name="importType"]:checked').val();
            window.location.href = `/Import/DownloadTemplate?type=${importType}`;
        },

        // Update import guidelines
        updateImportGuidelines: function(type) {
            const guidelines = {
                'products': {
                    required: ['SKU', 'Name', 'Price', 'Quantity'],
                    optional: ['Description', 'Category', 'Cost', 'Supplier', 'Location'],
                    tips: [
                        'SKU must be unique',
                        'Price and Cost should be positive numbers',
                        'Quantity must be a whole number'
                    ]
                },
                'customers': {
                    required: ['Name', 'Email'],
                    optional: ['Phone', 'Company', 'Address', 'City', 'State', 'Country'],
                    tips: [
                        'Email must be unique and valid',
                        'Phone numbers will be standardized automatically'
                    ]
                },
                'orders': {
                    required: ['OrderNumber', 'CustomerID', 'OrderDate', 'Total'],
                    optional: ['Status', 'ShippingAddress', 'TrackingNumber'],
                    tips: [
                        'Order numbers must be unique',
                        'Dates should be in YYYY-MM-DD format',
                        'Customer ID must exist in the system'
                    ]
                },
                'inventory': {
                    required: ['SKU', 'Location', 'Quantity'],
                    optional: ['Status', 'Notes'],
                    tips: [
                        'SKU must exist in products',
                        'Location must be valid warehouse location',
                        'Quantity adjustments will be logged'
                    ]
                }
            };

            const guide = guidelines[type] || guidelines['products'];
            
            let html = `
                <h6>${type.charAt(0).toUpperCase() + type.slice(1)} Import Guidelines</h6>
                <p class="small"><strong>Required Fields:</strong></p>
                <ul class="small">`;
            
            guide.required.forEach(field => {
                html += `<li>${field}</li>`;
            });
            
            html += `</ul>
                <p class="small"><strong>Optional Fields:</strong></p>
                <ul class="small">`;
            
            guide.optional.forEach(field => {
                html += `<li>${field}</li>`;
            });
            
            html += `</ul>
                <p class="small"><strong>Tips:</strong></p>
                <ul class="small">`;
            
            guide.tips.forEach(tip => {
                html += `<li>${tip}</li>`;
            });
            
            html += '</ul>';
            
            $('#importGuidelines').html(html);
        },

        // Utility functions
        formatFileSize: function(bytes) {
            const sizes = ['B', 'KB', 'MB', 'GB'];
            if (bytes === 0) return '0 B';
            const i = Math.floor(Math.log(bytes) / Math.log(1024));
            return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
        },

        escapeHtml: function(text) {
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, m => map[m]);
        },

        updateProgress: function(percentage, status) {
            this.state.uploadProgress = percentage;
            $('#uploadProgress').css('width', percentage + '%').text(Math.round(percentage) + '%');
            if (status) {
                $('#uploadStatus').text(status);
            }
        },

        showLoading: function(message = 'Loading...') {
            const html = `
                <div class="loading-overlay" id="importLoadingOverlay">
                    <div class="loading-content">
                        <div class="spinner-border text-primary mb-3" style="width: 3rem; height: 3rem;"></div>
                        <h5>${message}</h5>
                    </div>
                </div>`;
            
            $('body').append(html);
        },

        hideLoading: function() {
            $('#importLoadingOverlay').remove();
        },

        showToast: function(message, type = 'info') {
            if (window.showToast) {
                window.showToast(message, type);
            } else {
                console.log(`${type}: ${message}`);
            }
        },

        handleError: function(message, xhr) {
            console.error(message, xhr);
            
            let errorMessage = message;
            if (xhr && xhr.responseJSON && xhr.responseJSON.message) {
                errorMessage = xhr.responseJSON.message;
            }

            this.showToast(errorMessage, 'error');
        },

        createModal: function(title, body) {
            const modalId = 'importModal' + Date.now();
            const modalHtml = `
                <div class="modal fade" id="${modalId}" tabindex="-1">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">${title}</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                ${body}
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>`;

            $('body').append(modalHtml);
            const modal = new bootstrap.Modal(document.getElementById(modalId));

            $(`#${modalId}`).on('hidden.bs.modal', function() {
                $(this).remove();
            });

            return modal;
        }
    };

    // Initialize when DOM is ready
    $(document).ready(function() {
        if ($('#uploadArea').length > 0 || $('#importHistory').length > 0) {
            ImportModule.init();
        }
    });

    // Expose module to global scope
    window.ImportModule = ImportModule;

})(window, document, jQuery);