// ChillBlast WMS - Common JavaScript Module
(function (window, document, $) {
    'use strict';

    // Common Module
    const CommonModule = {
        // Configuration
        config: {
            toastDuration: 5000,
            confirmTimeout: 10000,
            loadingDelay: 300,
            csrfToken: null,
            dateFormat: 'YYYY-MM-DD',
            timeFormat: 'HH:mm:ss',
            currencySymbol: '$',
            apiTimeout: 30000
        },

        // State
        state: {
            activeModals: [],
            activeToasts: [],
            loadingCount: 0,
            confirmations: new Map()
        },

        // Initialize module
        init: function() {
            this.config.csrfToken = $('input[name="__RequestVerificationToken"]').val() || 
                                   $('meta[name="csrf-token"]').attr('content');
            this.setupAjaxDefaults();
            this.bindGlobalEvents();
            this.initializeComponents();
            this.setupErrorHandling();
            console.log('Common module initialized');
        },

        // Setup AJAX defaults
        setupAjaxDefaults: function() {
            const self = this;

            // Set default AJAX settings
            $.ajaxSetup({
                timeout: this.config.apiTimeout,
                headers: {
                    'RequestVerificationToken': this.config.csrfToken
                },
                beforeSend: function(xhr, settings) {
                    // Add CSRF token to all non-GET requests
                    if (settings.type !== 'GET' && self.config.csrfToken) {
                        xhr.setRequestHeader('RequestVerificationToken', self.config.csrfToken);
                    }
                },
                error: function(xhr, status, error) {
                    // Global error handler
                    if (status === 'timeout') {
                        self.showToast('Request timed out. Please try again.', 'error');
                    } else if (xhr.status === 401) {
                        self.showToast('Session expired. Redirecting to login...', 'warning');
                        setTimeout(() => {
                            window.location.href = '/Account/Login?returnUrl=' + encodeURIComponent(window.location.pathname);
                        }, 2000);
                    } else if (xhr.status === 403) {
                        self.showToast('You do not have permission to perform this action.', 'error');
                    } else if (xhr.status === 500) {
                        self.showToast('Server error occurred. Please contact support if the issue persists.', 'error');
                    }
                }
            });

            // Global AJAX loading indicator
            $(document).ajaxStart(function() {
                self.state.loadingCount++;
                if (self.state.loadingCount === 1) {
                    setTimeout(() => {
                        if (self.state.loadingCount > 0) {
                            self.showGlobalLoading();
                        }
                    }, self.config.loadingDelay);
                }
            });

            $(document).ajaxStop(function() {
                self.state.loadingCount--;
                if (self.state.loadingCount === 0) {
                    self.hideGlobalLoading();
                }
            });
        },

        // Bind global events
        bindGlobalEvents: function() {
            const self = this;

            // Confirmation dialogs
            $(document).on('click', '[data-confirm]', function(e) {
                e.preventDefault();
                const message = $(this).data('confirm');
                const action = $(this).data('action') || $(this).attr('href');
                self.showConfirm(message, () => {
                    if (action) {
                        window.location.href = action;
                    }
                });
            });

            // Auto-submit forms
            $(document).on('change', '.auto-submit', function() {
                $(this).closest('form').submit();
            });

            // AJAX forms
            $(document).on('submit', '.ajax-form', function(e) {
                e.preventDefault();
                self.submitAjaxForm($(this));
            });

            // Tooltips
            $(document).on('mouseenter', '[data-bs-toggle="tooltip"]', function() {
                if (!$(this).data('bs.tooltip')) {
                    new bootstrap.Tooltip(this);
                }
            });

            // Copy to clipboard
            $(document).on('click', '[data-copy]', function() {
                const text = $(this).data('copy');
                self.copyToClipboard(text);
            });

            // Print buttons
            $(document).on('click', '[data-print]', function() {
                const selector = $(this).data('print');
                self.printElement(selector);
            });

            // Back to top button
            $(window).scroll(function() {
                if ($(this).scrollTop() > 100) {
                    $('#backToTop').fadeIn();
                } else {
                    $('#backToTop').fadeOut();
                }
            });

            $('#backToTop').click(function() {
                $('html, body').animate({ scrollTop: 0 }, 600);
                return false;
            });

            // Keyboard shortcuts
            $(document).on('keydown', function(e) {
                self.handleGlobalKeyboardShortcuts(e);
            });

            // Form validation
            this.setupFormValidation();

            // Auto-save drafts
            this.setupAutoSave();
        },

        // Initialize components
        initializeComponents: function() {
            // Initialize all tooltips
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });

            // Initialize all popovers
            const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
            popoverTriggerList.map(function (popoverTriggerEl) {
                return new bootstrap.Popover(popoverTriggerEl);
            });

            // Initialize select2
            if ($.fn.select2) {
                $('.select2').select2({
                    theme: 'bootstrap-5',
                    width: '100%'
                });
            }

            // Initialize date pickers
            if ($.fn.datepicker) {
                $('.datepicker').datepicker({
                    format: 'yyyy-mm-dd',
                    autoclose: true,
                    todayHighlight: true
                });
            }

            // Initialize time pickers
            if ($.fn.timepicker) {
                $('.timepicker').timepicker({
                    showMeridian: false,
                    defaultTime: false
                });
            }

            // Initialize input masks
            this.initializeInputMasks();

            // Initialize lazy loading
            this.initializeLazyLoading();

            // Add back to top button if not exists
            if (!$('#backToTop').length) {
                $('body').append('<button id="backToTop" class="btn btn-primary btn-sm" title="Back to top"><i class="bi bi-arrow-up"></i></button>');
            }
        },

        // Toast notifications
        showToast: function(message, type = 'info', title = null, duration = null) {
            const toastId = 'toast-' + Date.now();
            const icon = this.getToastIcon(type);
            const bgClass = this.getToastBgClass(type);
            
            const toastHtml = `
                <div id="${toastId}" class="toast align-items-center text-white ${bgClass} border-0" role="alert" aria-live="assertive" aria-atomic="true">
                    <div class="d-flex">
                        <div class="toast-body">
                            <i class="${icon} me-2"></i>
                            ${title ? `<strong>${title}:</strong> ` : ''}
                            ${message}
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                    </div>
                </div>`;

            // Create or get toast container
            let container = $('#toastContainer');
            if (!container.length) {
                container = $('<div id="toastContainer" class="toast-container position-fixed bottom-0 end-0 p-3"></div>');
                $('body').append(container);
            }

            // Add toast to container
            container.append(toastHtml);

            // Initialize and show toast
            const toastElement = document.getElementById(toastId);
            const toast = new bootstrap.Toast(toastElement, {
                delay: duration || this.config.toastDuration,
                autohide: true
            });

            toast.show();

            // Track active toast
            this.state.activeToasts.push(toastId);

            // Remove from DOM after hidden
            toastElement.addEventListener('hidden.bs.toast', () => {
                toastElement.remove();
                this.state.activeToasts = this.state.activeToasts.filter(id => id !== toastId);
            });

            return toast;
        },

        getToastIcon: function(type) {
            const icons = {
                'success': 'bi bi-check-circle-fill',
                'error': 'bi bi-x-circle-fill',
                'warning': 'bi bi-exclamation-triangle-fill',
                'info': 'bi bi-info-circle-fill'
            };
            return icons[type] || icons.info;
        },

        getToastBgClass: function(type) {
            const classes = {
                'success': 'bg-success',
                'error': 'bg-danger',
                'warning': 'bg-warning',
                'info': 'bg-info'
            };
            return classes[type] || classes.info;
        },

        // Loading spinners
        showLoading: function(message = 'Loading...', overlay = true) {
            const loadingId = 'loading-' + Date.now();
            
            const loadingHtml = `
                <div id="${loadingId}" class="loading-container ${overlay ? 'loading-overlay' : ''}">
                    <div class="loading-content">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <div class="loading-text mt-3">${message}</div>
                    </div>
                </div>`;

            if (overlay) {
                $('body').append(loadingHtml);
            } else {
                return loadingHtml;
            }

            return loadingId;
        },

        hideLoading: function(loadingId = null) {
            if (loadingId) {
                $(`#${loadingId}`).fadeOut(300, function() {
                    $(this).remove();
                });
            } else {
                $('.loading-overlay').fadeOut(300, function() {
                    $(this).remove();
                });
            }
        },

        showGlobalLoading: function() {
            if (!$('#globalLoadingIndicator').length) {
                const html = `
                    <div id="globalLoadingIndicator" class="position-fixed top-0 start-50 translate-middle-x mt-3" style="z-index: 9999;">
                        <div class="bg-primary text-white px-3 py-2 rounded-pill shadow">
                            <span class="spinner-border spinner-border-sm me-2"></span>
                            Loading...
                        </div>
                    </div>`;
                $('body').append(html);
                $('#globalLoadingIndicator').hide().fadeIn(200);
            }
        },

        hideGlobalLoading: function() {
            $('#globalLoadingIndicator').fadeOut(200, function() {
                $(this).remove();
            });
        },

        // Confirmation dialogs
        showConfirm: function(message, onConfirm, onCancel = null, options = {}) {
            const confirmId = 'confirm-' + Date.now();
            const defaults = {
                title: 'Confirm Action',
                confirmText: 'Confirm',
                cancelText: 'Cancel',
                confirmClass: 'btn-primary',
                cancelClass: 'btn-secondary',
                requireTyping: false,
                typingText: null
            };
            
            const settings = { ...defaults, ...options };
            
            let bodyHtml = `<p>${message}</p>`;
            
            if (settings.requireTyping) {
                bodyHtml += `
                    <div class="mt-3">
                        <label class="form-label">Type "<strong>${settings.typingText}</strong>" to confirm:</label>
                        <input type="text" class="form-control" id="${confirmId}-typing" autocomplete="off">
                    </div>`;
            }

            const modalHtml = `
                <div class="modal fade" id="${confirmId}" tabindex="-1" data-bs-backdrop="static">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">${settings.title}</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                ${bodyHtml}
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn ${settings.cancelClass}" data-bs-dismiss="modal">
                                    ${settings.cancelText}
                                </button>
                                <button type="button" class="btn ${settings.confirmClass}" id="${confirmId}-confirm">
                                    ${settings.confirmText}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>`;

            $('body').append(modalHtml);
            
            const modalElement = document.getElementById(confirmId);
            const modal = new bootstrap.Modal(modalElement);
            
            // Handle confirm button
            $(`#${confirmId}-confirm`).on('click', function() {
                if (settings.requireTyping) {
                    const typedText = $(`#${confirmId}-typing`).val();
                    if (typedText !== settings.typingText) {
                        CommonModule.showToast('Please type the exact text to confirm', 'error');
                        return;
                    }
                }
                
                modal.hide();
                if (onConfirm) {
                    onConfirm();
                }
            });

            // Handle cancel
            modalElement.addEventListener('hidden.bs.modal', function() {
                if (onCancel && !$(this).data('confirmed')) {
                    onCancel();
                }
                $(this).remove();
            });

            modal.show();
            
            // Focus on typing input if required
            if (settings.requireTyping) {
                modalElement.addEventListener('shown.bs.modal', function() {
                    $(`#${confirmId}-typing`).focus();
                });
            }

            return modal;
        },

        // Alert dialog
        showAlert: function(message, type = 'info', title = null) {
            const alertId = 'alert-' + Date.now();
            const icon = this.getAlertIcon(type);
            const alertClass = this.getAlertClass(type);
            
            const modalHtml = `
                <div class="modal fade" id="${alertId}" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header ${alertClass}">
                                <h5 class="modal-title">
                                    <i class="${icon} me-2"></i>
                                    ${title || this.getAlertTitle(type)}
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                ${message}
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>`;

            $('body').append(modalHtml);
            
            const modalElement = document.getElementById(alertId);
            const modal = new bootstrap.Modal(modalElement);
            
            modalElement.addEventListener('hidden.bs.modal', function() {
                $(this).remove();
            });

            modal.show();
            return modal;
        },

        getAlertIcon: function(type) {
            const icons = {
                'success': 'bi bi-check-circle-fill',
                'error': 'bi bi-x-circle-fill',
                'warning': 'bi bi-exclamation-triangle-fill',
                'info': 'bi bi-info-circle-fill'
            };
            return icons[type] || icons.info;
        },

        getAlertClass: function(type) {
            const classes = {
                'success': 'bg-success text-white',
                'error': 'bg-danger text-white',
                'warning': 'bg-warning',
                'info': 'bg-info text-white'
            };
            return classes[type] || '';
        },

        getAlertTitle: function(type) {
            const titles = {
                'success': 'Success',
                'error': 'Error',
                'warning': 'Warning',
                'info': 'Information'
            };
            return titles[type] || 'Alert';
        },

        // AJAX form submission
        submitAjaxForm: function(form, options = {}) {
            const self = this;
            const defaults = {
                showLoading: true,
                showSuccess: true,
                resetOnSuccess: false,
                redirectOnSuccess: null,
                onSuccess: null,
                onError: null
            };
            
            const settings = { ...defaults, ...options };
            
            // Validate form
            if (!form[0].checkValidity()) {
                form[0].reportValidity();
                return;
            }

            const url = form.attr('action') || window.location.href;
            const method = form.attr('method') || 'POST';
            const isMultipart = form.attr('enctype') === 'multipart/form-data';
            
            let data;
            if (isMultipart) {
                data = new FormData(form[0]);
            } else {
                data = form.serialize();
            }

            if (settings.showLoading) {
                this.showLoading('Processing...');
            }

            $.ajax({
                url: url,
                method: method,
                data: data,
                processData: !isMultipart,
                contentType: isMultipart ? false : 'application/x-www-form-urlencoded',
                success: function(response) {
                    if (settings.showSuccess) {
                        self.showToast(response.message || 'Operation completed successfully', 'success');
                    }
                    
                    if (settings.resetOnSuccess) {
                        form[0].reset();
                    }
                    
                    if (settings.redirectOnSuccess) {
                        setTimeout(() => {
                            window.location.href = settings.redirectOnSuccess;
                        }, 1000);
                    }
                    
                    if (settings.onSuccess) {
                        settings.onSuccess(response);
                    }
                },
                error: function(xhr) {
                    let errorMessage = 'An error occurred';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message;
                    } else if (xhr.responseJSON && xhr.responseJSON.errors) {
                        errorMessage = self.formatValidationErrors(xhr.responseJSON.errors);
                    }
                    
                    self.showToast(errorMessage, 'error');
                    
                    if (settings.onError) {
                        settings.onError(xhr);
                    }
                },
                complete: function() {
                    if (settings.showLoading) {
                        self.hideLoading();
                    }
                }
            });
        },

        formatValidationErrors: function(errors) {
            if (typeof errors === 'string') {
                return errors;
            }
            
            let message = 'Validation errors:<br>';
            if (Array.isArray(errors)) {
                errors.forEach(error => {
                    message += `• ${error}<br>`;
                });
            } else {
                Object.keys(errors).forEach(key => {
                    const fieldErrors = errors[key];
                    if (Array.isArray(fieldErrors)) {
                        fieldErrors.forEach(error => {
                            message += `• ${key}: ${error}<br>`;
                        });
                    } else {
                        message += `• ${key}: ${fieldErrors}<br>`;
                    }
                });
            }
            return message;
        },

        // Form validation
        setupFormValidation: function() {
            // Bootstrap validation
            const forms = document.querySelectorAll('.needs-validation');
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });

            // Custom validation rules
            this.addCustomValidationRules();
        },

        addCustomValidationRules: function() {
            // Email validation
            $(document).on('blur', 'input[type="email"]', function() {
                const email = $(this).val();
                const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
                $(this).toggleClass('is-invalid', !isValid && email !== '');
            });

            // Phone validation
            $(document).on('blur', 'input[type="tel"]', function() {
                const phone = $(this).val();
                const isValid = /^[\d\s\-\+\(\)]+$/.test(phone);
                $(this).toggleClass('is-invalid', !isValid && phone !== '');
            });

            // Password strength
            $(document).on('input', 'input[type="password"].password-strength', function() {
                const password = $(this).val();
                const strength = CommonModule.calculatePasswordStrength(password);
                CommonModule.updatePasswordStrengthIndicator($(this), strength);
            });
        },

        calculatePasswordStrength: function(password) {
            let strength = 0;
            if (password.length >= 8) strength++;
            if (password.length >= 12) strength++;
            if (/[a-z]/.test(password)) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^a-zA-Z0-9]/.test(password)) strength++;
            return strength;
        },

        updatePasswordStrengthIndicator: function(input, strength) {
            let indicator = input.siblings('.password-strength-indicator');
            if (!indicator.length) {
                indicator = $('<div class="password-strength-indicator mt-1"></div>');
                input.after(indicator);
            }

            const strengthLevels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong', 'Very Strong'];
            const strengthColors = ['danger', 'danger', 'warning', 'warning', 'success', 'success'];
            
            indicator.html(`
                <div class="progress" style="height: 5px;">
                    <div class="progress-bar bg-${strengthColors[strength]}" style="width: ${(strength / 6) * 100}%"></div>
                </div>
                <small class="text-${strengthColors[strength]}">${strengthLevels[strength]}</small>
            `);
        },

        // Auto-save functionality
        setupAutoSave: function() {
            const self = this;
            
            $(document).on('input change', '.auto-save', function() {
                const form = $(this).closest('form');
                const formId = form.attr('id') || 'form-' + Date.now();
                
                clearTimeout(form.data('saveTimeout'));
                
                const timeout = setTimeout(() => {
                    self.autoSaveForm(form);
                }, 2000);
                
                form.data('saveTimeout', timeout);
            });
        },

        autoSaveForm: function(form) {
            const formData = form.serializeArray();
            const formId = form.attr('id');
            
            // Save to localStorage
            localStorage.setItem(`draft-${formId}`, JSON.stringify(formData));
            
            // Show saved indicator
            this.showToast('Draft saved', 'info', null, 1000);
        },

        loadDraft: function(formId) {
            const draft = localStorage.getItem(`draft-${formId}`);
            if (draft) {
                const formData = JSON.parse(draft);
                const form = $(`#${formId}`);
                
                formData.forEach(field => {
                    const input = form.find(`[name="${field.name}"]`);
                    if (input.length) {
                        input.val(field.value);
                    }
                });
                
                this.showToast('Draft loaded', 'info');
            }
        },

        // Utility functions
        copyToClipboard: function(text) {
            const self = this;
            
            if (navigator.clipboard) {
                navigator.clipboard.writeText(text).then(() => {
                    self.showToast('Copied to clipboard', 'success', null, 2000);
                }).catch(() => {
                    self.fallbackCopyToClipboard(text);
                });
            } else {
                this.fallbackCopyToClipboard(text);
            }
        },

        fallbackCopyToClipboard: function(text) {
            const textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.opacity = '0';
            document.body.appendChild(textArea);
            textArea.select();
            
            try {
                document.execCommand('copy');
                this.showToast('Copied to clipboard', 'success', null, 2000);
            } catch (err) {
                this.showToast('Failed to copy', 'error');
            }
            
            document.body.removeChild(textArea);
        },

        printElement: function(selector) {
            const element = $(selector);
            if (!element.length) return;

            const printWindow = window.open('', '', 'height=600,width=800');
            printWindow.document.write('<html><head><title>Print</title>');
            
            // Copy stylesheets
            $('link[rel="stylesheet"]').each(function() {
                printWindow.document.write('<link rel="stylesheet" href="' + $(this).attr('href') + '">');
            });
            
            printWindow.document.write('</head><body>');
            printWindow.document.write(element.html());
            printWindow.document.write('</body></html>');
            
            printWindow.document.close();
            printWindow.focus();
            
            setTimeout(() => {
                printWindow.print();
                printWindow.close();
            }, 500);
        },

        formatCurrency: function(amount, symbol = null) {
            symbol = symbol || this.config.currencySymbol;
            return symbol + parseFloat(amount).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        },

        formatNumber: function(number, decimals = 0) {
            return parseFloat(number).toFixed(decimals).replace(/\d(?=(\d{3})+\.)/g, '$&,');
        },

        formatDate: function(date, format = null) {
            format = format || this.config.dateFormat;
            const d = new Date(date);
            
            if (isNaN(d.getTime())) {
                return '';
            }
            
            const year = d.getFullYear();
            const month = String(d.getMonth() + 1).padStart(2, '0');
            const day = String(d.getDate()).padStart(2, '0');
            const hours = String(d.getHours()).padStart(2, '0');
            const minutes = String(d.getMinutes()).padStart(2, '0');
            const seconds = String(d.getSeconds()).padStart(2, '0');
            
            return format
                .replace('YYYY', year)
                .replace('MM', month)
                .replace('DD', day)
                .replace('HH', hours)
                .replace('mm', minutes)
                .replace('ss', seconds);
        },

        formatFileSize: function(bytes) {
            const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
            if (bytes === 0) return '0 B';
            const i = Math.floor(Math.log(bytes) / Math.log(1024));
            return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
        },

        debounce: function(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        },

        throttle: function(func, limit) {
            let inThrottle;
            return function(...args) {
                if (!inThrottle) {
                    func.apply(this, args);
                    inThrottle = true;
                    setTimeout(() => inThrottle = false, limit);
                }
            };
        },

        // Input masks
        initializeInputMasks: function() {
            // Phone mask
            $('.phone-mask').on('input', function() {
                let value = $(this).val().replace(/\D/g, '');
                if (value.length >= 6) {
                    value = value.slice(0, 3) + '-' + value.slice(3, 6) + '-' + value.slice(6, 10);
                } else if (value.length >= 3) {
                    value = value.slice(0, 3) + '-' + value.slice(3);
                }
                $(this).val(value);
            });

            // Currency mask
            $('.currency-mask').on('input', function() {
                let value = $(this).val().replace(/[^0-9.]/g, '');
                const parts = value.split('.');
                parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                if (parts[1]) {
                    parts[1] = parts[1].slice(0, 2);
                }
                $(this).val('$' + parts.join('.'));
            });

            // Number only
            $('.number-only').on('input', function() {
                $(this).val($(this).val().replace(/\D/g, ''));
            });
        },

        // Lazy loading
        initializeLazyLoading: function() {
            if ('IntersectionObserver' in window) {
                const imageObserver = new IntersectionObserver((entries, observer) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            const img = entry.target;
                            img.src = img.dataset.src;
                            img.classList.remove('lazy');
                            observer.unobserve(img);
                        }
                    });
                });

                document.querySelectorAll('img.lazy').forEach(img => {
                    imageObserver.observe(img);
                });
            } else {
                // Fallback for older browsers
                const lazyImages = document.querySelectorAll('img.lazy');
                lazyImages.forEach(img => {
                    img.src = img.dataset.src;
                    img.classList.remove('lazy');
                });
            }
        },

        // Keyboard shortcuts
        handleGlobalKeyboardShortcuts: function(e) {
            // Ctrl/Cmd + S - Save
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                e.preventDefault();
                const activeForm = $('form:visible').first();
                if (activeForm.length) {
                    activeForm.submit();
                }
            }

            // Escape - Close modals
            if (e.key === 'Escape') {
                $('.modal.show').modal('hide');
            }

            // Alt + N - New item
            if (e.altKey && e.key === 'n') {
                e.preventDefault();
                const newButton = $('[data-action="new"], .btn-new, #btnNew').first();
                if (newButton.length) {
                    newButton.click();
                }
            }
        },

        // Error handling
        setupErrorHandling: function() {
            window.addEventListener('error', (e) => {
                console.error('Global error:', e.error);
                // Log to server if needed
            });

            window.addEventListener('unhandledrejection', (e) => {
                console.error('Unhandled promise rejection:', e.reason);
                // Log to server if needed
            });
        },

        // Session management
        checkSession: function() {
            $.ajax({
                url: '/api/session/check',
                method: 'GET',
                success: function(response) {
                    if (!response.isValid) {
                        CommonModule.showToast('Session expired. Please login again.', 'warning');
                        setTimeout(() => {
                            window.location.href = '/Account/Login';
                        }, 2000);
                    }
                }
            });
        },

        extendSession: function() {
            $.ajax({
                url: '/api/session/extend',
                method: 'POST',
                success: function() {
                    console.log('Session extended');
                }
            });
        },

        // Initialize session checker
        initializeSessionChecker: function() {
            // Check session every 5 minutes
            setInterval(() => {
                this.checkSession();
            }, 300000);

            // Extend session on user activity
            let activityTimeout;
            ['click', 'scroll', 'keypress'].forEach(event => {
                document.addEventListener(event, () => {
                    clearTimeout(activityTimeout);
                    activityTimeout = setTimeout(() => {
                        this.extendSession();
                    }, 60000); // Extend after 1 minute of activity
                });
            });
        }
    };

    // jQuery extensions
    $.fn.serializeObject = function() {
        const o = {};
        const a = this.serializeArray();
        $.each(a, function() {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };

    // Initialize when DOM is ready
    $(document).ready(function() {
        CommonModule.init();
    });

    // Expose to global scope
    window.CommonModule = CommonModule;
    window.showToast = CommonModule.showToast.bind(CommonModule);
    window.showConfirm = CommonModule.showConfirm.bind(CommonModule);
    window.showAlert = CommonModule.showAlert.bind(CommonModule);
    window.showLoading = CommonModule.showLoading.bind(CommonModule);
    window.hideLoading = CommonModule.hideLoading.bind(CommonModule);

})(window, document, jQuery);