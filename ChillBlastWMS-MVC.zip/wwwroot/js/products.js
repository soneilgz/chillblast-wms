// ChillBlast WMS - Products JavaScript Module
(function (window, document, $) {
    'use strict';

    // Products Module
    const ProductsModule = {
        // Configuration
        config: {
            searchDelay: 300,
            minSearchLength: 2,
            pageSize: 25,
            enableRealTimeSearch: true,
            enableBulkOperations: true,
            apiBaseUrl: '/api/products',
            csrfToken: null
        },

        // State
        state: {
            selectedProducts: new Set(),
            searchTimer: null,
            currentFilter: {},
            isLoading: false,
            currentPage: 1,
            totalPages: 1,
            sortBy: 'name',
            sortOrder: 'asc'
        },

        // Initialize module
        init: function() {
            this.config.csrfToken = $('input[name="__RequestVerificationToken"]').val();
            this.bindEvents();
            this.initializeComponents();
            this.loadProducts();
            console.log('Products module initialized');
        },

        // Bind events
        bindEvents: function() {
            const self = this;

            // Real-time search
            $('#productSearch').on('input', function() {
                self.handleSearch($(this).val());
            });

            // Advanced search form
            $('#advancedSearchForm').on('submit', function(e) {
                e.preventDefault();
                self.performAdvancedSearch();
            });

            // Bulk select all
            $('#selectAll').on('change', function() {
                self.toggleSelectAll($(this).prop('checked'));
            });

            // Individual product selection
            $(document).on('change', '.product-select', function() {
                self.toggleProductSelection($(this).val(), $(this).prop('checked'));
            });

            // Bulk operations
            $('#bulkDelete').on('click', function() {
                self.bulkDelete();
            });

            $('#bulkExport').on('click', function() {
                self.bulkExport();
            });

            $('#bulkUpdatePrice').on('click', function() {
                self.showBulkPriceUpdate();
            });

            $('#bulkUpdateStock').on('click', function() {
                self.showBulkStockUpdate();
            });

            // Sort controls
            $('.sortable').on('click', function() {
                self.handleSort($(this).data('sort'));
            });

            // Quick actions
            $(document).on('click', '.quick-edit', function() {
                self.quickEdit($(this).data('id'));
            });

            $(document).on('click', '.quick-view', function() {
                self.quickView($(this).data('id'));
            });

            $(document).on('click', '.adjust-stock', function() {
                self.showStockAdjustment($(this).data('id'));
            });

            // Filter controls
            $('.filter-control').on('change', function() {
                self.applyFilters();
            });

            // Page size
            $('#pageSize').on('change', function() {
                self.config.pageSize = parseInt($(this).val());
                self.loadProducts();
            });

            // Pagination
            $(document).on('click', '.pagination-link', function(e) {
                e.preventDefault();
                self.loadPage($(this).data('page'));
            });

            // AJAX forms
            $(document).on('submit', '.ajax-form', function(e) {
                e.preventDefault();
                self.submitAjaxForm($(this));
            });

            // Keyboard shortcuts
            $(document).on('keydown', function(e) {
                self.handleKeyboardShortcuts(e);
            });
        },

        // Initialize components
        initializeComponents: function() {
            // Initialize tooltips
            $('[data-bs-toggle="tooltip"]').tooltip();

            // Initialize select2 for dropdowns
            $('.select2').select2({
                theme: 'bootstrap-5',
                width: '100%'
            });

            // Initialize date pickers
            $('.datepicker').datepicker({
                format: 'yyyy-mm-dd',
                autoclose: true
            });

            // Initialize price sliders
            if ($('#priceSlider').length) {
                this.initializePriceSlider();
            }
        },

        // Real-time search handling
        handleSearch: function(query) {
            const self = this;

            // Clear previous timer
            clearTimeout(this.state.searchTimer);

            // Check minimum length
            if (query.length < this.config.minSearchLength && query.length > 0) {
                return;
            }

            // Show loading indicator
            this.showSearchLoading();

            // Debounce search
            this.state.searchTimer = setTimeout(function() {
                self.performSearch(query);
            }, this.config.searchDelay);
        },

        // Perform search
        performSearch: function(query) {
            const self = this;

            $.ajax({
                url: `${this.config.apiBaseUrl}/search`,
                method: 'GET',
                data: {
                    q: query,
                    page: this.state.currentPage,
                    pageSize: this.config.pageSize,
                    sortBy: this.state.sortBy,
                    sortOrder: this.state.sortOrder
                },
                success: function(response) {
                    self.renderSearchResults(response);
                    self.updateSearchSuggestions(response.suggestions);
                },
                error: function(xhr) {
                    self.handleError('Search failed', xhr);
                },
                complete: function() {
                    self.hideSearchLoading();
                }
            });
        },

        // Advanced search
        performAdvancedSearch: function() {
            const self = this;
            const formData = $('#advancedSearchForm').serializeObject();

            this.showLoading();

            $.ajax({
                url: `${this.config.apiBaseUrl}/advanced-search`,
                method: 'POST',
                data: JSON.stringify(formData),
                contentType: 'application/json',
                headers: {
                    'RequestVerificationToken': this.config.csrfToken
                },
                success: function(response) {
                    self.renderProducts(response.products);
                    self.updatePagination(response.pagination);
                    self.showToast('Search completed', 'success');
                },
                error: function(xhr) {
                    self.handleError('Advanced search failed', xhr);
                },
                complete: function() {
                    self.hideLoading();
                }
            });
        },

        // Load products
        loadProducts: function(filters = {}) {
            const self = this;

            this.showLoading();

            $.ajax({
                url: `${this.config.apiBaseUrl}`,
                method: 'GET',
                data: {
                    ...this.state.currentFilter,
                    ...filters,
                    page: this.state.currentPage,
                    pageSize: this.config.pageSize,
                    sortBy: this.state.sortBy,
                    sortOrder: this.state.sortOrder
                },
                success: function(response) {
                    self.renderProducts(response.products);
                    self.updatePagination(response.pagination);
                    self.updateStatistics(response.statistics);
                },
                error: function(xhr) {
                    self.handleError('Failed to load products', xhr);
                },
                complete: function() {
                    self.hideLoading();
                }
            });
        },

        // Render products
        renderProducts: function(products) {
            const container = $('#productsContainer');
            
            if (!products || products.length === 0) {
                container.html(this.getEmptyStateHtml());
                return;
            }

            let html = '';
            products.forEach(product => {
                html += this.getProductCardHtml(product);
            });

            container.html(html);
            this.initializeProductCards();
        },

        // Get product card HTML
        getProductCardHtml: function(product) {
            const margin = product.price > 0 ? ((product.price - product.cost) / product.price * 100) : 0;
            const marginClass = margin < 0 ? 'text-danger' : margin < 15 ? 'text-warning' : margin < 30 ? 'text-info' : 'text-success';
            const stockClass = product.quantity === 0 ? 'danger' : product.quantity <= product.reorderPoint ? 'warning' : 'success';

            return `
                <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                    <div class="card product-card h-100" data-product-id="${product.id}">
                        ${this.config.enableBulkOperations ? `
                            <div class="card-select">
                                <input type="checkbox" class="form-check-input product-select" value="${product.id}">
                            </div>
                        ` : ''}
                        <div class="card-img-wrapper">
                            ${product.imageUrl ? 
                                `<img src="${product.imageUrl}" class="card-img-top" alt="${product.name}">` :
                                `<div class="card-img-placeholder">
                                    <i class="bi bi-image"></i>
                                </div>`
                            }
                            <div class="card-badges">
                                ${product.isNew ? '<span class="badge bg-primary">New</span>' : ''}
                                ${product.quantity === 0 ? '<span class="badge bg-danger">Out of Stock</span>' : ''}
                                ${product.quantity <= product.reorderPoint && product.quantity > 0 ? '<span class="badge bg-warning">Low Stock</span>' : ''}
                            </div>
                            <div class="card-overlay">
                                <button class="btn btn-sm btn-light quick-view" data-id="${product.id}">
                                    <i class="bi bi-eye"></i> Quick View
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <span class="badge bg-secondary mb-2">${product.sku}</span>
                            <h6 class="card-title">
                                <a href="/Products/Details/${product.id}" class="text-decoration-none">
                                    ${product.name}
                                </a>
                            </h6>
                            <p class="card-text small text-muted">${product.category || 'Uncategorized'}</p>
                            <div class="pricing mb-2">
                                <div class="d-flex justify-content-between">
                                    <span class="h5 mb-0 text-success">$${product.price.toFixed(2)}</span>
                                    <span class="badge ${marginClass}">${margin.toFixed(1)}%</span>
                                </div>
                                <small class="text-muted">Cost: $${product.cost.toFixed(2)}</small>
                            </div>
                            <div class="stock-info">
                                <div class="d-flex justify-content-between mb-1">
                                    <small>Stock Level</small>
                                    <span class="badge bg-${stockClass}">${product.quantity} units</span>
                                </div>
                                <div class="progress" style="height: 5px;">
                                    <div class="progress-bar bg-${stockClass}" 
                                         style="width: ${Math.min((product.quantity / (product.reorderPoint * 3)) * 100, 100)}%">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent">
                            <div class="btn-group btn-group-sm w-100">
                                <button class="btn btn-outline-primary quick-edit" data-id="${product.id}">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <button class="btn btn-outline-warning adjust-stock" data-id="${product.id}">
                                    <i class="bi bi-box-seam"></i>
                                </button>
                                <button class="btn btn-outline-info" onclick="ProductsModule.viewAnalytics(${product.id})">
                                    <i class="bi bi-graph-up"></i>
                                </button>
                                <button class="btn btn-outline-danger" onclick="ProductsModule.deleteProduct(${product.id})">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        },

        // Get empty state HTML
        getEmptyStateHtml: function() {
            return `
                <div class="col-12">
                    <div class="text-center py-5">
                        <i class="bi bi-inbox" style="font-size: 4rem; color: #dee2e6;"></i>
                        <h4 class="mt-3">No products found</h4>
                        <p class="text-muted">Try adjusting your filters or search criteria</p>
                        <button class="btn btn-primary" onclick="ProductsModule.clearFilters()">
                            Clear Filters
                        </button>
                    </div>
                </div>
            `;
        },

        // Initialize product cards
        initializeProductCards: function() {
            // Re-initialize tooltips
            $('.product-card [data-bs-toggle="tooltip"]').tooltip();

            // Lazy load images
            this.lazyLoadImages();
        },

        // Bulk operations
        toggleSelectAll: function(checked) {
            $('.product-select').prop('checked', checked);
            
            if (checked) {
                $('.product-select').each((i, el) => {
                    this.state.selectedProducts.add($(el).val());
                });
            } else {
                this.state.selectedProducts.clear();
            }

            this.updateBulkOperationsUI();
        },

        toggleProductSelection: function(productId, checked) {
            if (checked) {
                this.state.selectedProducts.add(productId);
            } else {
                this.state.selectedProducts.delete(productId);
            }

            this.updateBulkOperationsUI();
        },

        updateBulkOperationsUI: function() {
            const count = this.state.selectedProducts.size;
            
            if (count > 0) {
                $('#bulkOperations').show();
                $('#selectedCount').text(count);
                $('.bulk-action').prop('disabled', false);
            } else {
                $('#bulkOperations').hide();
                $('.bulk-action').prop('disabled', true);
            }

            // Update select all checkbox
            const totalProducts = $('.product-select').length;
            $('#selectAll').prop('checked', count === totalProducts && count > 0);
            $('#selectAll').prop('indeterminate', count > 0 && count < totalProducts);
        },

        bulkDelete: function() {
            const self = this;
            const count = this.state.selectedProducts.size;

            if (count === 0) return;

            if (!confirm(`Are you sure you want to delete ${count} product(s)? This action cannot be undone.`)) {
                return;
            }

            this.showLoading();

            $.ajax({
                url: `${this.config.apiBaseUrl}/bulk-delete`,
                method: 'POST',
                data: JSON.stringify(Array.from(this.state.selectedProducts)),
                contentType: 'application/json',
                headers: {
                    'RequestVerificationToken': this.config.csrfToken
                },
                success: function(response) {
                    self.showToast(`${response.deletedCount} products deleted successfully`, 'success');
                    self.state.selectedProducts.clear();
                    self.loadProducts();
                },
                error: function(xhr) {
                    self.handleError('Bulk delete failed', xhr);
                },
                complete: function() {
                    self.hideLoading();
                }
            });
        },

        bulkExport: function() {
            const productIds = Array.from(this.state.selectedProducts);
            
            if (productIds.length === 0) {
                this.showToast('No products selected', 'warning');
                return;
            }

            // Create form and submit
            const form = $('<form>', {
                method: 'POST',
                action: '/Products/Export'
            });

            form.append($('<input>', {
                type: 'hidden',
                name: 'productIds',
                value: JSON.stringify(productIds)
            }));

            form.append($('<input>', {
                type: 'hidden',
                name: '__RequestVerificationToken',
                value: this.config.csrfToken
            }));

            $('body').append(form);
            form.submit();
            form.remove();

            this.showToast('Export started', 'info');
        },

        showBulkPriceUpdate: function() {
            const self = this;
            const modal = this.createModal('Bulk Price Update', `
                <form id="bulkPriceForm">
                    <div class="mb-3">
                        <label class="form-label">Update Type</label>
                        <select class="form-select" name="updateType" required>
                            <option value="percentage">Percentage Change</option>
                            <option value="fixed">Fixed Amount</option>
                            <option value="set">Set Price</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Value</label>
                        <input type="number" class="form-control" name="value" step="0.01" required>
                        <small class="text-muted">Enter percentage for % change, amount for fixed, or new price for set</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Apply To</label>
                        <select class="form-select" name="applyTo">
                            <option value="price">Selling Price</option>
                            <option value="cost">Cost Price</option>
                            <option value="both">Both</option>
                        </select>
                    </div>
                </form>
            `, [
                {
                    text: 'Cancel',
                    class: 'btn-secondary',
                    dismiss: true
                },
                {
                    text: 'Update Prices',
                    class: 'btn-primary',
                    click: function() {
                        self.executeBulkPriceUpdate();
                    }
                }
            ]);

            modal.show();
        },

        executeBulkPriceUpdate: function() {
            const self = this;
            const formData = $('#bulkPriceForm').serializeObject();
            formData.productIds = Array.from(this.state.selectedProducts);

            $.ajax({
                url: `${this.config.apiBaseUrl}/bulk-update-price`,
                method: 'POST',
                data: JSON.stringify(formData),
                contentType: 'application/json',
                headers: {
                    'RequestVerificationToken': this.config.csrfToken
                },
                success: function(response) {
                    self.showToast(`${response.updatedCount} products updated successfully`, 'success');
                    self.loadProducts();
                    $('.modal').modal('hide');
                },
                error: function(xhr) {
                    self.handleError('Price update failed', xhr);
                }
            });
        },

        showBulkStockUpdate: function() {
            const self = this;
            const modal = this.createModal('Bulk Stock Update', `
                <form id="bulkStockForm">
                    <div class="mb-3">
                        <label class="form-label">Adjustment Type</label>
                        <select class="form-select" name="adjustmentType" required>
                            <option value="add">Add Stock</option>
                            <option value="subtract">Remove Stock</option>
                            <option value="set">Set Stock Level</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Quantity</label>
                        <input type="number" class="form-control" name="quantity" min="0" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Reason</label>
                        <select class="form-select" name="reason" required>
                            <option value="restock">Restock</option>
                            <option value="adjustment">Inventory Adjustment</option>
                            <option value="damage">Damaged Goods</option>
                            <option value="return">Customer Return</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notes</label>
                        <textarea class="form-control" name="notes" rows="2"></textarea>
                    </div>
                </form>
            `, [
                {
                    text: 'Cancel',
                    class: 'btn-secondary',
                    dismiss: true
                },
                {
                    text: 'Update Stock',
                    class: 'btn-primary',
                    click: function() {
                        self.executeBulkStockUpdate();
                    }
                }
            ]);

            modal.show();
        },

        executeBulkStockUpdate: function() {
            const self = this;
            const formData = $('#bulkStockForm').serializeObject();
            formData.productIds = Array.from(this.state.selectedProducts);

            $.ajax({
                url: `${this.config.apiBaseUrl}/bulk-update-stock`,
                method: 'POST',
                data: JSON.stringify(formData),
                contentType: 'application/json',
                headers: {
                    'RequestVerificationToken': this.config.csrfToken
                },
                success: function(response) {
                    self.showToast(`${response.updatedCount} products updated successfully`, 'success');
                    self.loadProducts();
                    $('.modal').modal('hide');
                },
                error: function(xhr) {
                    self.handleError('Stock update failed', xhr);
                }
            });
        },

        // Quick operations
        quickEdit: function(productId) {
            const self = this;

            $.ajax({
                url: `${this.config.apiBaseUrl}/${productId}/quick-edit`,
                method: 'GET',
                success: function(product) {
                    self.showQuickEditModal(product);
                },
                error: function(xhr) {
                    self.handleError('Failed to load product', xhr);
                }
            });
        },

        showQuickEditModal: function(product) {
            const self = this;
            const modal = this.createModal('Quick Edit - ' + product.name, `
                <form id="quickEditForm" data-product-id="${product.id}">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" value="${product.name}" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">SKU</label>
                            <input type="text" class="form-control" name="sku" value="${product.sku}" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Price</label>
                            <input type="number" class="form-control" name="price" value="${product.price}" step="0.01" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Cost</label>
                            <input type="number" class="form-control" name="cost" value="${product.cost}" step="0.01" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Quantity</label>
                            <input type="number" class="form-control" name="quantity" value="${product.quantity}" min="0" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Reorder Point</label>
                            <input type="number" class="form-control" name="reorderPoint" value="${product.reorderPoint}" min="0">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Category</label>
                        <input type="text" class="form-control" name="category" value="${product.category || ''}">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" rows="3">${product.description || ''}</textarea>
                    </div>
                </form>
            `, [
                {
                    text: 'Cancel',
                    class: 'btn-secondary',
                    dismiss: true
                },
                {
                    text: 'Save Changes',
                    class: 'btn-primary',
                    click: function() {
                        self.saveQuickEdit();
                    }
                }
            ]);

            modal.show();
        },

        saveQuickEdit: function() {
            const self = this;
            const form = $('#quickEditForm');
            const productId = form.data('product-id');
            const formData = form.serializeObject();

            $.ajax({
                url: `${this.config.apiBaseUrl}/${productId}/quick-edit`,
                method: 'POST',
                data: JSON.stringify(formData),
                contentType: 'application/json',
                headers: {
                    'RequestVerificationToken': this.config.csrfToken
                },
                success: function(response) {
                    self.showToast('Product updated successfully', 'success');
                    self.loadProducts();
                    $('.modal').modal('hide');
                },
                error: function(xhr) {
                    self.handleError('Failed to update product', xhr);
                }
            });
        },

        quickView: function(productId) {
            const self = this;

            $.ajax({
                url: `${this.config.apiBaseUrl}/${productId}`,
                method: 'GET',
                success: function(product) {
                    self.showQuickViewModal(product);
                },
                error: function(xhr) {
                    self.handleError('Failed to load product', xhr);
                }
            });
        },

        showQuickViewModal: function(product) {
            const margin = product.price > 0 ? ((product.price - product.cost) / product.price * 100) : 0;
            const modal = this.createModal(product.name, `
                <div class="row">
                    <div class="col-md-4">
                        ${product.imageUrl ? 
                            `<img src="${product.imageUrl}" class="img-fluid" alt="${product.name}">` :
                            `<div class="text-center p-5 bg-light">
                                <i class="bi bi-image" style="font-size: 4rem;"></i>
                            </div>`
                        }
                    </div>
                    <div class="col-md-8">
                        <p class="mb-2"><strong>SKU:</strong> ${product.sku}</p>
                        <p class="mb-2"><strong>Category:</strong> ${product.category || 'N/A'}</p>
                        <p class="mb-2"><strong>Price:</strong> $${product.price.toFixed(2)}</p>
                        <p class="mb-2"><strong>Cost:</strong> $${product.cost.toFixed(2)}</p>
                        <p class="mb-2"><strong>Margin:</strong> ${margin.toFixed(1)}%</p>
                        <p class="mb-2"><strong>Stock:</strong> ${product.quantity} units</p>
                        <p class="mb-2"><strong>Reorder Point:</strong> ${product.reorderPoint}</p>
                        ${product.description ? `<p class="mb-2"><strong>Description:</strong> ${product.description}</p>` : ''}
                    </div>
                </div>
                <hr>
                <div class="d-flex justify-content-between">
                    <a href="/Products/Details/${product.id}" class="btn btn-primary">View Full Details</a>
                    <button class="btn btn-warning" onclick="ProductsModule.showStockAdjustment(${product.id})">
                        Adjust Stock
                    </button>
                </div>
            `, [
                {
                    text: 'Close',
                    class: 'btn-secondary',
                    dismiss: true
                }
            ]);

            modal.show();
        },

        showStockAdjustment: function(productId) {
            const self = this;

            $.ajax({
                url: `${this.config.apiBaseUrl}/${productId}`,
                method: 'GET',
                success: function(product) {
                    self.showStockAdjustmentModal(product);
                },
                error: function(xhr) {
                    self.handleError('Failed to load product', xhr);
                }
            });
        },

        showStockAdjustmentModal: function(product) {
            const self = this;
            const modal = this.createModal('Stock Adjustment - ' + product.name, `
                <form id="stockAdjustmentForm" data-product-id="${product.id}">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Current Stock</label>
                            <input type="number" class="form-control" value="${product.quantity}" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">New Stock Level</label>
                            <input type="number" class="form-control" name="newQuantity" value="${product.quantity}" min="0" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Reason</label>
                        <select class="form-select" name="reason" required>
                            <option value="">Select reason...</option>
                            <option value="Physical Count">Physical Count</option>
                            <option value="Damaged Goods">Damaged Goods</option>
                            <option value="Returns">Returns</option>
                            <option value="Theft/Loss">Theft/Loss</option>
                            <option value="Data Correction">Data Correction</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notes</label>
                        <textarea class="form-control" name="notes" rows="2"></textarea>
                    </div>
                </form>
            `, [
                {
                    text: 'Cancel',
                    class: 'btn-secondary',
                    dismiss: true
                },
                {
                    text: 'Update Stock',
                    class: 'btn-warning',
                    click: function() {
                        self.adjustStock();
                    }
                }
            ]);

            modal.show();
        },

        adjustStock: function() {
            const self = this;
            const form = $('#stockAdjustmentForm');
            const productId = form.data('product-id');
            const formData = form.serializeObject();

            $.ajax({
                url: `${this.config.apiBaseUrl}/${productId}/adjust-stock`,
                method: 'POST',
                data: JSON.stringify(formData),
                contentType: 'application/json',
                headers: {
                    'RequestVerificationToken': this.config.csrfToken
                },
                success: function(response) {
                    self.showToast('Stock adjusted successfully', 'success');
                    self.loadProducts();
                    $('.modal').modal('hide');
                },
                error: function(xhr) {
                    self.handleError('Stock adjustment failed', xhr);
                }
            });
        },

        // Sorting
        handleSort: function(field) {
            if (this.state.sortBy === field) {
                this.state.sortOrder = this.state.sortOrder === 'asc' ? 'desc' : 'asc';
            } else {
                this.state.sortBy = field;
                this.state.sortOrder = 'asc';
            }

            this.updateSortUI();
            this.loadProducts();
        },

        updateSortUI: function() {
            $('.sortable').removeClass('sort-asc sort-desc');
            $(`.sortable[data-sort="${this.state.sortBy}"]`).addClass(`sort-${this.state.sortOrder}`);
        },

        // Filters
        applyFilters: function() {
            const filters = {};

            $('.filter-control').each(function() {
                const value = $(this).val();
                if (value) {
                    filters[$(this).attr('name')] = value;
                }
            });

            this.state.currentFilter = filters;
            this.state.currentPage = 1;
            this.loadProducts();
        },

        clearFilters: function() {
            $('.filter-control').val('').trigger('change');
            this.state.currentFilter = {};
            this.state.currentPage = 1;
            this.loadProducts();
        },

        // Pagination
        loadPage: function(page) {
            this.state.currentPage = page;
            this.loadProducts();
        },

        updatePagination: function(pagination) {
            this.state.currentPage = pagination.currentPage;
            this.state.totalPages = pagination.totalPages;

            const html = this.generatePaginationHtml(pagination);
            $('#paginationContainer').html(html);
        },

        generatePaginationHtml: function(pagination) {
            if (pagination.totalPages <= 1) return '';

            let html = '<nav><ul class="pagination">';

            // Previous button
            html += `<li class="page-item ${pagination.currentPage === 1 ? 'disabled' : ''}">
                        <a class="page-link pagination-link" href="#" data-page="${pagination.currentPage - 1}">Previous</a>
                     </li>`;

            // Page numbers
            for (let i = 1; i <= pagination.totalPages; i++) {
                if (i === 1 || i === pagination.totalPages || (i >= pagination.currentPage - 2 && i <= pagination.currentPage + 2)) {
                    html += `<li class="page-item ${i === pagination.currentPage ? 'active' : ''}">
                                <a class="page-link pagination-link" href="#" data-page="${i}">${i}</a>
                             </li>`;
                } else if (i === pagination.currentPage - 3 || i === pagination.currentPage + 3) {
                    html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
                }
            }

            // Next button
            html += `<li class="page-item ${pagination.currentPage === pagination.totalPages ? 'disabled' : ''}">
                        <a class="page-link pagination-link" href="#" data-page="${pagination.currentPage + 1}">Next</a>
                     </li>`;

            html += '</ul></nav>';
            return html;
        },

        // Statistics
        updateStatistics: function(stats) {
            if (!stats) return;

            $('#totalProducts').text(stats.totalProducts || 0);
            $('#totalValue').text('$' + (stats.totalValue || 0).toFixed(2));
            $('#lowStockCount').text(stats.lowStockCount || 0);
            $('#outOfStockCount').text(stats.outOfStockCount || 0);
        },

        // AJAX form submission
        submitAjaxForm: function(form) {
            const self = this;
            const url = form.attr('action');
            const method = form.attr('method') || 'POST';
            const formData = new FormData(form[0]);

            // Add CSRF token
            formData.append('__RequestVerificationToken', this.config.csrfToken);

            $.ajax({
                url: url,
                method: method,
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        self.showToast(response.message || 'Operation completed successfully', 'success');
                        if (response.redirect) {
                            window.location.href = response.redirect;
                        } else {
                            self.loadProducts();
                        }
                    } else {
                        self.showToast(response.message || 'Operation failed', 'error');
                    }
                },
                error: function(xhr) {
                    self.handleError('Form submission failed', xhr);
                }
            });
        },

        // Delete product
        deleteProduct: function(productId) {
            const self = this;

            if (!confirm('Are you sure you want to delete this product? This action cannot be undone.')) {
                return;
            }

            $.ajax({
                url: `${this.config.apiBaseUrl}/${productId}`,
                method: 'DELETE',
                headers: {
                    'RequestVerificationToken': this.config.csrfToken
                },
                success: function() {
                    self.showToast('Product deleted successfully', 'success');
                    self.loadProducts();
                },
                error: function(xhr) {
                    self.handleError('Delete failed', xhr);
                }
            });
        },

        // View analytics
        viewAnalytics: function(productId) {
            window.location.href = `/Products/Analytics/${productId}`;
        },

        // Keyboard shortcuts
        handleKeyboardShortcuts: function(e) {
            // Ctrl/Cmd + F - Focus search
            if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                e.preventDefault();
                $('#productSearch').focus();
            }

            // Ctrl/Cmd + A - Select all (when in products view)
            if ((e.ctrlKey || e.metaKey) && e.key === 'a' && $(e.target).closest('#productsContainer').length) {
                e.preventDefault();
                $('#selectAll').prop('checked', true).trigger('change');
            }

            // Escape - Clear selection
            if (e.key === 'Escape') {
                this.state.selectedProducts.clear();
                $('.product-select').prop('checked', false);
                this.updateBulkOperationsUI();
            }
        },

        // Utility functions
        showLoading: function() {
            this.state.isLoading = true;
            $('#loadingOverlay').show();
        },

        hideLoading: function() {
            this.state.isLoading = false;
            $('#loadingOverlay').hide();
        },

        showSearchLoading: function() {
            $('#searchSpinner').show();
        },

        hideSearchLoading: function() {
            $('#searchSpinner').hide();
        },

        showToast: function(message, type = 'info') {
            if (window.showToast) {
                window.showToast(message, type);
            } else {
                console.log(`${type}: ${message}`);
            }
        },

        handleError: function(message, xhr) {
            console.error(message, xhr);
            
            let errorMessage = message;
            if (xhr && xhr.responseJSON && xhr.responseJSON.message) {
                errorMessage = xhr.responseJSON.message;
            } else if (xhr && xhr.status === 401) {
                errorMessage = 'Session expired. Please login again.';
                setTimeout(() => {
                    window.location.href = '/Account/Login';
                }, 2000);
            }

            this.showToast(errorMessage, 'error');
        },

        createModal: function(title, body, buttons) {
            const modalId = 'dynamicModal' + Date.now();
            let buttonsHtml = '';

            if (buttons && buttons.length > 0) {
                buttons.forEach(btn => {
                    buttonsHtml += `<button type="button" class="btn ${btn.class}" 
                                            ${btn.dismiss ? 'data-bs-dismiss="modal"' : ''}
                                            ${btn.click ? `onclick="${btn.click.toString()}"` : ''}>
                                        ${btn.text}
                                    </button>`;
                });
            }

            const modalHtml = `
                <div class="modal fade" id="${modalId}" tabindex="-1">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">${title}</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                ${body}
                            </div>
                            <div class="modal-footer">
                                ${buttonsHtml}
                            </div>
                        </div>
                    </div>
                </div>
            `;

            $('body').append(modalHtml);
            const modal = new bootstrap.Modal(document.getElementById(modalId));

            // Clean up after modal is hidden
            $(`#${modalId}`).on('hidden.bs.modal', function() {
                $(this).remove();
            });

            return modal;
        },

        lazyLoadImages: function() {
            const images = document.querySelectorAll('img[data-src]');
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                        observer.unobserve(img);
                    }
                });
            });

            images.forEach(img => imageObserver.observe(img));
        },

        initializePriceSlider: function() {
            const slider = document.getElementById('priceSlider');
            if (!slider) return;

            noUiSlider.create(slider, {
                start: [0, 1000],
                connect: true,
                range: {
                    'min': 0,
                    'max': 5000
                },
                format: {
                    to: function(value) {
                        return '$' + Math.round(value);
                    },
                    from: function(value) {
                        return Number(value.replace('$', ''));
                    }
                }
            });

            slider.noUiSlider.on('change', (values) => {
                $('#minPrice').val(values[0].replace('$', ''));
                $('#maxPrice').val(values[1].replace('$', ''));
                this.applyFilters();
            });
        },

        updateSearchSuggestions: function(suggestions) {
            if (!suggestions || suggestions.length === 0) {
                $('#searchSuggestions').hide();
                return;
            }

            let html = '';
            suggestions.forEach(suggestion => {
                html += `<a href="#" class="dropdown-item" onclick="ProductsModule.selectSuggestion('${suggestion}'); return false;">
                            ${suggestion}
                         </a>`;
            });

            $('#searchSuggestions').html(html).show();
        },

        selectSuggestion: function(suggestion) {
            $('#productSearch').val(suggestion);
            $('#searchSuggestions').hide();
            this.performSearch(suggestion);
        }
    };

    // jQuery extension for serializing form to object
    $.fn.serializeObject = function() {
        const o = {};
        const a = this.serializeArray();
        $.each(a, function() {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };

    // Initialize when DOM is ready
    $(document).ready(function() {
        if ($('#productsContainer').length > 0) {
            ProductsModule.init();
        }
    });

    // Expose module to global scope
    window.ProductsModule = ProductsModule;

})(window, document, jQuery);